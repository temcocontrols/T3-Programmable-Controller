
#ifndef	__DISPLAY_H__

#define	__DISPLAY_H__



void vStartDisplayTask(unsigned char uxPriority);

#endif
