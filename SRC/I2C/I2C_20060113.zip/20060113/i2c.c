/*
 *********************************************************************************
 *     Copyright (c) 2005	ASIX Electronic Corporation      All rights reserved.
 *
 *     This is unpublished proprietary source code of ASIX Electronic Corporation
 *
 *     The copyright notice above does not evidence any actual or intended
 *     publication of such source code.
 *********************************************************************************
 */
/*================================================================================
 * Module Name : i2c.c
 * Purpose     : This module handles the I2C serial interface driver.
 * Author      : Robin Lee
 * Date        : 2005-03-31
 * Notes       :
 * $Log: i2c.c,v $
 * Revision 1.16  2005/11/24 12:51:30  robin6633
 * initiate values of use.
 *
 * Revision 1.15  2005/11/01 13:15:43  robin6633
 * Fixed global values initial.
 *
 * Revision 1.14  2005/09/28 09:37:29  robin6633
 * Change the last byte received interrupt condition.
 *
 * Revision 1.13  2005/09/28 09:08:36  robin6633
 * no message
 *
 * Revision 1.12  2005/09/27 09:14:12  robin6633
 * Fixed the last byte received of master receiver.
 *
 * Revision 1.11  2005/09/09 05:21:06  robin6633
 * Arbitration Lost.
 *
 * Revision 1.10  2005/08/31 01:57:40  robin6633
 * Fixed the infinite loop if a NACK occur.
 *
 * Revision 1.9  2005/08/17 06:48:11  robin6633
 * no message
 *
 * Revision 1.8  2005/08/11 08:59:42  borbin
 * no message
 *
 * Revision 1.7  2005/07/28 02:04:33  robin6633
 * Re-order the burst read/write command address byte of slave mode.
 *
 * Revision 1.6  2005/07/26 05:47:06  robin6633
 * Fixed the bug of hardware START condition immediately followed by a STOP.
 *
 * Revision 1.5  2005/07/21 01:00:47  robin6633
 * Added I2C slave function.
 *
 * Revision 1.4  2005/07/11 07:23:30  robin6633
 * interrupt mode flag fixed
 *
 * Revision 1.3  2005/07/01 12:40:21  robin6633
 * Add at24c01a service function
 *
 * Revision 1.2  2005/06/14 02:50:12  arthur
 * changed interrupt.h include
 *
 * Revision 1.1.1.1  2005/06/06 05:55:57  robin6633
 * no message
 *
 *================================================================================
 */

/* INCLUDE FILE DECLARATIONS */
#include	<stdio.h>
#include	"reg80390.h"
#include	"types.h"
#include	"i2c.h"
#if I2C_SLAVE_ENABLE
#include	"console_debug.h"	
#endif


/* STATIC VARIABLE DECLARATIONS */
static U8_T		i2cctrl = 0;
static U8_T		i2cendcond = 0;
static U8_T		i2cactf = 0;	// indicate the condition of a transfer
static U16_T	i2cdatalen = 0;	// The I2cPktLen includes address and data
static U16_T	i2cdatalencnt = 0;	// Packet's counter of transferring 
static U8_T		i2cpktdir = 0;	// Packet's direction
static I2C_BUF 	*pti2ctxbuf = 0;
static I2C_BUF 	*pti2crxbuf = 0;
static U8_T		i2cstate = 0;	// I2C master state flag
static U8_T		slvrxpkt[SLV_MAX_PKT_NUM];
static U8_T		slvtxpkt[SLV_MAX_PKT_NUM];


/* LOCAL SUBPROGRAM DECLARATIONS */
static void I2C_MstStatus(U8_T i2cstatus);
static void I2C_SlvStatus(U8_T i2cstatus);
static void I2C_MasterXmit(U8_T wrdata, U8_T mstcmd);
static void I2C_MasterRcvr(U8_T *rddata, U8_T mstcmd);
static void I2C_SlaveXmit(U8_T wrdata, U8_T slvcmd);
static void I2C_SlaveRcvr(U8_T *rddata, U8_T slvcmd);

#if I2C_SLAVE_ENABLE
static void I2C_SlvRxProcess(void);
#endif


/* LOCAL SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * static void I2C_MstStatus(U8_T i2cstatus)
 * Purpose : Checks the interrupt status of I2C master mode.
 * Params  : i2cstatus - master status when interrupt occured.
 * Returns : none
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void I2C_MstStatus(U8_T i2cstatus)
{
	if (i2cpktdir == I2C_MST_XMIT)
	{
		/* Check the current byte ack */
		if ((!(i2cstatus & I2C_NO_ACK)) && (i2cstatus & I2C_INTR_FLAG)
		&& (!(i2cstatus & I2C_TIP)) && (i2cstatus & I2C_BUS_BUSY))
		{
			if (!I2C_FlagChk(I2C_BUSY))
			{
				I2C_FlagEnb(I2C_RESTART);
			}
			else
			{
				if ((i2cctrl & I2C_10BIT) && (i2cactf & I2C_START_COND))
				{
					I2C_MasterXmit((U8_T)(pti2ctxbuf->I2caddr.Tenbitaddr & 0x00FF), I2C_MASTER_GO | I2C_CMD_WRITE);
				}
				else
				{
					if (i2cdatalencnt < (i2cdatalen-1))
					{
						/* transmit the first data byte */
						I2C_MasterXmit(pti2ctxbuf->I2cdata[i2cdatalencnt], I2C_MASTER_GO | I2C_CMD_WRITE);
						i2cdatalencnt ++;
					}
					else if (i2cdatalencnt == (i2cdatalen-1))
					{
						/* transmit the last data byte */
						if (i2cendcond & I2C_STOP_COND)
						{
							I2C_MasterXmit(pti2ctxbuf->I2cdata[i2cdatalencnt], I2C_MASTER_GO | I2C_CMD_WRITE | I2C_STOP_COND);
							i2cdatalencnt = 0;
						}
						else
						{
							I2C_MasterXmit(pti2ctxbuf->I2cdata[i2cdatalencnt], I2C_MASTER_GO | I2C_CMD_WRITE);
							i2cdatalencnt = 0;
							EA = 0;
							I2C_FlagClr(I2C_BUSY);
							EA = 1;
						}
					}
				}
			}
		/*	if (i2cactf & I2C_STOP_COND)
			{
				i2cdatalencnt = 0;
				EA = 0;
				I2C_FlagClr(I2C_BUSY);
				EA = 1;
			}*/
		}
		else if (i2cstatus & I2C_NO_ACK)
		{
			i2cdatalencnt = 0;
			if (i2cactf & I2C_START_COND)
			{
				/* transmit the STOP condition */
				I2C_MasterXmit(0, I2C_MASTER_GO | I2C_STOP_COND);
				i2cdatalencnt = 0;
				EA = 0;
				I2C_FlagClr(I2C_BUSY);
				I2C_FlagEnb(I2C_NACK);
				EA = 1;
			}
			else
			{
				i2cdatalencnt = 0;
				EA = 0;
				I2C_FlagClr(I2C_BUSY);
				EA = 1;
			}
		}
		else if (i2cstatus & I2C_ARB_LOST)
		{
			I2C_MasterXmit(0, I2C_MASTER_GO | I2C_STOP_COND);
			i2cdatalencnt = 0;
			EA = 0;
			I2C_FlagClr(I2C_BUSY);
			I2C_FlagEnb(I2C_NACK);
			printf("I2C arbitration lost\n\r");
			EA = 1;
		}
		else if (i2cstatus & I2C_TIP)
		{
			i2cdatalencnt = 0;
			if (i2cactf & I2C_START_COND)
			{
				I2C_FlagClr(I2C_BUSY);
				/* transmit the STOP condition */
				I2C_MasterXmit(0, I2C_MASTER_GO | I2C_STOP_COND);
			}
			else
			{
				/* transmit the STOP condition or repeat START condition */
				I2C_PktBuf(pti2ctxbuf);
			}
		}
		else if ((!(i2cstatus & I2C_NO_ACK)) && (!(i2cstatus & I2C_TIP)) && (!(i2cstatus & I2C_BUS_BUSY)))
		{
			if (i2cactf & I2C_STOP_COND)
			{
				i2cdatalencnt = 0;
				EA = 0;
				I2C_FlagClr(I2C_BUSY);
				EA = 1;
			}
		}
	}
	else if (i2cpktdir == I2C_MST_RCVR)
	{
		/* Check the current byte ack */
		if ((!(i2cstatus & I2C_NO_ACK)) && (i2cstatus & I2C_INTR_FLAG)
		&& (!(i2cstatus & I2C_TIP)) && (i2cstatus & I2C_BUS_BUSY))
		{
			if (i2cactf & I2C_START_COND)
			{
				if (i2cdatalencnt == (i2cdatalen - 1))
					I2C_MasterRcvr(&(pti2crxbuf->I2cdata[0]), I2C_MASTER_GO | I2C_CMD_READ | I2C_STOP_COND);
				else
					I2C_MasterRcvr(&(pti2crxbuf->I2cdata[0]), I2C_MASTER_GO | I2C_CMD_READ);
			}
			else if (i2cactf & I2C_STOP_COND)
			{
				I2C_FlagClr(I2C_BUSY);
				I2C_MasterRcvr(&(pti2crxbuf->I2cdata[i2cdatalencnt]), 0);
			}
			else
			{
				if (i2cdatalencnt < (i2cdatalen - 1))
				{
					/* reveive the next byte */
					I2C_MasterRcvr(&(pti2crxbuf->I2cdata[i2cdatalencnt]), I2C_MASTER_GO | I2C_CMD_READ);
				}
				else if (i2cdatalencnt == (i2cdatalen - 1))
				{
					/* receive the last byte */
					I2C_MasterRcvr((U8_T *)(&(pti2crxbuf->I2cdata[i2cdatalencnt])), I2C_MASTER_GO | I2C_CMD_READ | I2C_STOP_COND);
				}
			}
		}
		else if (i2cstatus & I2C_NO_ACK)
		{
			i2cdatalencnt = 0;
			if (i2cactf & I2C_START_COND)
			{
				I2C_MasterXmit(0, I2C_MASTER_GO | I2C_STOP_COND);
				i2cdatalencnt = 0;
				EA = 0;
				I2C_FlagClr(I2C_BUSY);
				I2C_FlagEnb(I2C_NACK);
				EA = 1;
			}
			else
			{
				i2cdatalencnt = 0;
				EA = 0;
				I2C_FlagClr(I2C_BUSY);
				EA = 1;
			}
		}
		else
		{
			if (i2cactf & I2C_STOP_COND)
			{
				I2C_FlagClr(I2C_BUSY);
				I2C_MasterRcvr(&(pti2crxbuf->I2cdata[i2cdatalencnt]), 0);
			}
		}
	}
}

/*
 *--------------------------------------------------------------------------------
 * static void I2C_SlvStatus(U8_T i2cstatus)
 * Purpose : Handles the interrupt status of I2C slave mode.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void I2C_SlvStatus(U8_T i2cstatus)
{
	U8_T	devaddr;

	if (i2cstatus & I2C_SLV_STOP)
	{
		if (!(i2cstatus & I2C_SLV_START))
		{
			if (i2cpktdir == I2C_SLV_RCVR)
			{
				i2cdatalen = i2cdatalencnt;
				#if I2C_SLAVE_ENABLE
				I2C_SlvRxProcess();
				#endif
			}
			i2cdatalencnt = 0;
			I2C_SlaveRcvr(&slvrxpkt[i2cdatalencnt], I2C_SLAVE_GO);
		}
	}
	if (i2cstatus & I2C_SLV_NACK)
	{
		I2C_SlaveRcvr(&devaddr, I2C_RLS);
	}
	else
	{
		if (i2cstatus & I2C_SLV_WR)
		{
			if (i2cstatus & I2C_SLV_START)
			{
				I2C_SlaveRcvr(&devaddr, I2C_SLAVE_GO);
				i2cpktdir = I2C_SLV_RCVR;
				i2cdatalencnt = 0;
			}
			else if (i2cstatus & I2C_SLV_STOP)
			{
				I2C_SlaveRcvr(&slvrxpkt[i2cdatalencnt], I2C_SLAVE_GO);
				i2cdatalen = i2cdatalencnt;
				#if I2C_SLAVE_ENABLE
				I2C_SlvRxProcess();
				#endif
				i2cdatalencnt = 0;
			}
			else if (i2cstatus & I2C_SLV_RESTART)
			{
				I2C_SlaveRcvr(&devaddr, I2C_SLAVE_GO);
				i2cpktdir = I2C_SLV_RCVR;
				i2cdatalencnt = 0;
			}
			else
			{
				I2C_SlaveRcvr(&slvrxpkt[i2cdatalencnt], I2C_SLAVE_GO);
				i2cdatalencnt ++;
			}
		}
		else if (i2cstatus & I2C_SLV_RD)
		{
			if (i2cstatus & I2C_SLV_STOP)
			{
				I2C_SlaveRcvr(&devaddr, I2C_SLAVE_GO);
				i2cdatalencnt = 0;
			}
			else if (i2cstatus & I2C_SLV_START)
			{
				i2cpktdir = I2C_SLV_XMIT;
				i2cdatalencnt = 0;
				#if I2C_SLAVE_ENABLE
				I2C_SlvRxProcess();
				#endif
				I2C_SlaveXmit(slvtxpkt[i2cdatalencnt], I2C_SLAVE_GO);
				i2cdatalencnt ++;
			}
			else if (i2cstatus & I2C_SLV_RESTART)
			{
				i2cpktdir = I2C_SLV_XMIT;
				i2cdatalencnt = 0;
				#if I2C_SLAVE_ENABLE
				I2C_SlvRxProcess();
				#endif
				I2C_SlaveXmit(slvtxpkt[i2cdatalencnt], I2C_SLAVE_GO);
				i2cdatalencnt ++;
			}
			else
			{
				if (slvrxpkt[0] == I2C_SLV_BRDM)
				{
					#if I2C_SLAVE_ENABLE
					I2C_SlvRxProcess();
					#endif
				}
				I2C_SlaveXmit(slvtxpkt[i2cdatalencnt], I2C_SLAVE_GO);
				i2cdatalencnt ++;
			}
		}
	}
}

#if I2C_SLAVE_ENABLE
/*
 *--------------------------------------------------------------------------------
 * static void I2C_SlvRxProcess(U8_T SlvRxState)
 * Purpose : Handling transmit and command of I2C master mode.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void I2C_SlvRxProcess(void)
{
	U8_T	slvcmd;
	U8_T	sfraddr;
	U8_T	cmdindreg, realreg, reallen;
	U32_T	memaddr, memdata;
	U16_T	i;

	slvcmd = slvrxpkt[0];
	if ((slvcmd & 0xF0) == I2C_SLV_SWSFR)
	{
		reallen = (slvcmd & 0x0F) + 1;
		sfraddr = slvrxpkt[1];
		for (i = 0 ; i < reallen ; i ++)
		{
			CLI_SfrWr((U32_T)sfraddr, (U32_T)slvrxpkt[i + 2]);
		}
	}
	else if ((slvcmd & 0xF0) == I2C_SLV_SRSFR)
	{
		reallen = (slvcmd & 0x0F) + 1;
		sfraddr = slvrxpkt[1];
		for (i = 0 ; i < reallen ; i ++)
		{
			CLI_SfrRd((U32_T)sfraddr, &memdata);
			slvtxpkt[i] = (U8_T)memdata;
		}
	}
	else if ((slvcmd & 0xF0) == I2C_SLV_IWSFR)
	{
		cmdindreg = slvrxpkt[1];
		realreg = slvrxpkt[2];
		reallen = (slvcmd & 0x0F) + 1;
		if (cmdindreg == SFR_I2CCIR)
		{
			CLI_I2cWr((U32_T)realreg, &slvrxpkt[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_SPICIR)
		{
			CLI_SpiWr((U32_T)realreg, &slvrxpkt[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_OWCIR)
		{
			CLI_OwWr((U32_T)realreg, &slvrxpkt[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_CANCIR)
		{
			CLI_CanWr((U32_T)realreg, &slvrxpkt[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_TCIR)
		{
			CLI_ToeWr((U32_T)realreg, &slvrxpkt[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_MCIR)
		{
			CLI_MacWr((U32_T)realreg, &slvrxpkt[3], (U8_T)reallen);
		}
	}
	else if ((slvcmd & 0xF0) == I2C_SLV_IRSFR)
	{
		cmdindreg = slvrxpkt[1];
		realreg = slvrxpkt[2];
		reallen = (slvcmd & 0x0F) + 1;
		if (cmdindreg == SFR_I2CCIR)
		{
			CLI_I2cRd((U32_T)realreg, &slvtxpkt[i2cdatalencnt], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_SPICIR)
		{
			CLI_SpiRd((U32_T)realreg, &slvtxpkt[i2cdatalencnt], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_OWCIR)
		{
			CLI_OwRd((U32_T)realreg, &slvtxpkt[i2cdatalencnt], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_CANCIR)
		{
			CLI_CanRd((U32_T)realreg, &slvtxpkt[i2cdatalencnt], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_TCIR)
		{
			CLI_ToeRd((U32_T)realreg, &slvtxpkt[i2cdatalencnt], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_MCIR)
		{
			CLI_MacRd((U32_T)realreg, &slvtxpkt[i2cdatalencnt], (U8_T)reallen);
		}
	}
	else if (slvcmd == I2C_SLV_BWDM)
	{
		memaddr = ((U32_T)slvrxpkt[3] << 16) | ((U32_T)slvrxpkt[2] << 8) | ((U32_T)slvrxpkt[1]);
		for (i = 4 ; i < i2cdatalen ; i ++)
		{
			CLI_ExtMemWr((U32_T)memaddr, (U32_T)slvrxpkt[i]);
			memaddr ++;
		}
	}
	else if (slvcmd == I2C_SLV_BRDM)
	{
		if (i2cdatalencnt == 0)
		{
			memaddr = ((U32_T)slvrxpkt[3] << 16) | ((U32_T)slvrxpkt[2] << 8) | ((U32_T)slvrxpkt[1]);
		}
		CLI_ExtMemRd((U32_T)memaddr, &memdata);
		slvtxpkt[i2cdatalencnt] = (U8_T)memdata;
		memaddr ++;
	}
}
#endif

/*
 *--------------------------------------------------------------------------------
 * static void I2C_MasterXmit(U8_T wrdata, U8_T mstcmd)
 * Purpose : Handling transmit and command of I2C master mode.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void I2C_MasterXmit(U8_T wrdata, U8_T mstcmd)
{
	/* Record the globe flag of command condition */
	i2cactf = mstcmd;
	/* First the master flipper sends the slave address to access */
	I2C_Cmd(SI_WR, I2CTR, &wrdata);
	/* Order command to I2CCR */
	I2C_Cmd(SI_WR, I2CCR, &mstcmd);
}

/*
 *--------------------------------------------------------------------------------
 * static void I2C_MasterRcvr(U8_T *rddata, U8_T mstcmd)
 * Purpose : Handling receive and command of I2C master mode after first address
 *           byte transmitted.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void I2C_MasterRcvr(U8_T *rddata, U8_T mstcmd)
{
	/* Record the globe flag of command condition */
	i2cactf = mstcmd;
	/* After ACK, read data from I2CRR */
	I2C_Cmd(SI_RD, I2CRR, rddata);
	/* Then, reply ACK to slave */
	I2C_Cmd(SI_WR, I2CCR, &mstcmd);

	i2cdatalencnt ++;
}

/*
 *--------------------------------------------------------------------------------
 * static void I2C_SlaveXmit(U8_T wrdata, U8_T slvcmd)
 * Purpose : Handling transmit and command of I2C slave mode.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void I2C_SlaveXmit(U8_T wrdata, U8_T slvcmd)
{
	/* Record the globe flag of command condition */
	i2cactf = slvcmd;
	/* transmit the data byte */
	I2C_Cmd(SI_WR, I2CTR, &wrdata);
	/* Order command to I2CCR */
	I2C_Cmd(SI_WR, I2CCR, &slvcmd);
}

/*
 *--------------------------------------------------------------------------------
 * static void I2C_SlaveRcvr(U8_T *rddata, U8_T slvcmd)
 * Purpose : Handling receive and command of I2C slave mode after first address 
 *           byte transmitted.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void I2C_SlaveRcvr(U8_T *rddata, U8_T slvcmd)
{
	/* Record the globe flag of command condition */
	i2cactf = slvcmd;
	/* After ACK, read data from I2CRR */
	I2C_Cmd(SI_RD, I2CRR, rddata);
	/* Then, reply ACK to slave */
	I2C_Cmd(SI_WR, I2CCR, &slvcmd);
}


/* EXPORTED SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * void I2C_Setup(U8_T ctrlcmd, U16_T preclk, U16_T axidaddr)
 * Purpose : Setup the operation mode of I2C.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void I2C_Setup(U8_T ctrlcmd, U16_T preclk, U16_T axidaddr)
{
	U16_T	i;
	/* Values initial */
	i2cctrl = 0;
	i2cendcond = 0;
	i2cactf = 0;
	i2cdatalen = 0;
	i2cdatalencnt = 0;
	i2cpktdir = 0;
	pti2ctxbuf = NULL;
	pti2crxbuf = NULL;
	i2cstate = 0;
	for (i=0 ; i<SLV_MAX_PKT_NUM ; i++)
	{
		slvrxpkt[i] = 0;
		slvtxpkt[i] = 0;
	}

	/* Pre-scale Clock */
	I2CDR = (U8_T)(0x00FF & preclk);
	I2CDR = (U8_T)((0xFF00 & preclk) >> 8);
	I2CCIR = I2CCPR;
	/* Flipper device address for slave mode */
	I2CDR = (U8_T)(axidaddr & 0x00FF);
	I2CDR = (U8_T)((axidaddr & 0xFF00) >> 8);
	I2CCIR = I2CSDAR;
	/* Setup I2C mode */
	I2C_Cmd(SI_WR, I2CCTL, &ctrlcmd);
}

/*
 *--------------------------------------------------------------------------------
 * void I2C_Func(void)
 * Purpose : Handling serial interface I2C interrupt function.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void I2C_Func(void)
{
	U8_T	i2cstatus;

	I2C_Cmd(SI_RD, I2CCTL, &i2cctrl);

	if (i2cctrl & I2C_MASTER_MODE)
	{
		EA = 0;
		I2C_Cmd(SI_RD, I2CMSR, &i2cstatus);
		EA = 1;

		if (i2cctrl & I2C_MST_IE)
		{
			if (i2cstatus & I2C_INTR_FLAG)
			{
				I2C_MstStatus(i2cstatus);
			}
		}
		else
		{
			if (!(i2cstatus & I2C_TIP))
			{
				I2C_MstStatus(i2cstatus);
			}
		}
	}
	else
	{
		EA = 0;
		I2C_Cmd(SI_RD, I2CSSR, &i2cstatus);
		EA = 1;
		if (i2cctrl & I2C_SLV_IE)
		{
			if (i2cstatus & I2C_SLV_TXR_OK)
			{
				I2C_SlvStatus(i2cstatus);
			}
		}
		else
		{
			if (i2cstatus & I2C_SLV_TXR_OK)
			{
				I2C_SlvStatus(i2cstatus);
			}
		}
	}
}

/*
 *--------------------------------------------------------------------------------
 * void I2C_PktBuf(I2C_BUF *pti2cbuf)
 * Purpose : Packeting a packet between firmware and software.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void I2C_PktBuf(I2C_BUF *pti2cbuf)
{
	U8_T	firstaddr;

	I2C_Cmd(SI_RD, I2CCTL, &i2cctrl); 
	if (i2cctrl & I2C_MASTER_MODE) // I2C Master Mode
	{
		i2cdatalencnt = 0;
		i2cendcond = pti2cbuf->I2cend;
		i2cpktdir = pti2cbuf->I2cdir;
		i2cdatalen = pti2cbuf->Datalen;
				
			if (i2cctrl & I2C_10BIT)
			{
				firstaddr = ((U8_T)((pti2cbuf->I2caddr.Tenbitaddr & 0x0300) >> 7) | 0xF0);
				if (i2cpktdir & I2C_XMIT)
				{
					pti2ctxbuf = pti2cbuf;
					I2C_MasterXmit(firstaddr & ~BIT0, I2C_MASTER_GO | I2C_CMD_WRITE | I2C_START_COND);
				}
				else
				{
					pti2crxbuf = pti2cbuf;
					I2C_MasterXmit(firstaddr | BIT0, I2C_MASTER_GO | I2C_CMD_WRITE | I2C_START_COND);
				}
			}
			else
			{
				firstaddr = pti2cbuf->I2caddr.Sevenbitaddr << 1;
				if (i2cpktdir & I2C_XMIT)
				{
					pti2ctxbuf = pti2cbuf;
					I2C_MasterXmit(firstaddr & ~BIT0, I2C_MASTER_GO | I2C_CMD_WRITE | I2C_START_COND);
				}
				else
				{
					pti2crxbuf = pti2cbuf;
					I2C_MasterXmit(firstaddr | BIT0, I2C_MASTER_GO | I2C_CMD_WRITE | I2C_START_COND);
				}
			}
	}
	else // I2C Slave Mode
	{
		if (pti2cbuf->I2cdir & I2C_XMIT)
		{
			/* Get the slave data to transmit */
			//pti2ctxbuf->ptI2c = ??;
			pti2cbuf->Datalen = i2cdatalen;
		}
		else
		{
			/* packet the received data to upper layer */
			pti2cbuf->Datalen = i2cdatalen;
		}
	}
}

/*
 *--------------------------------------------------------------------------------
 * BOOL I2C_FlagChk(U8_T chkbit)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL I2C_FlagChk(U8_T chkbit)
{
	if (i2cstate & chkbit)
		return TRUE;
	else
		return FALSE;
}

/*
 *--------------------------------------------------------------------------------
 * void I2C_FlagEnb(U8_T enbbit)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void I2C_FlagEnb(U8_T enbbit)
{
	i2cstate = i2cstate | enbbit;
}

/*
 *--------------------------------------------------------------------------------
 * void I2C_FlagClr(U8_T clrbit)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void I2C_FlagClr(U8_T clrbit)
{
	i2cstate = i2cstate & ~clrbit;
}

/*
 *--------------------------------------------------------------------------------
 * void I2C_Cmd(U8_T cmdtype, U8_T i2ccmdindex, U8_T *i2cData)
 * Purpose : Accessing the I2C interface indirectly through I2C's SFR.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void I2C_Cmd(U8_T cmdtype, U8_T i2ccmdindex, U8_T *i2cdata)
{
	if (cmdtype == SI_WR)
	{
		I2CDR = *i2cdata;
		I2CCIR = i2ccmdindex;
	}
	else if (cmdtype == SI_RD)
	{
		I2CCIR = i2ccmdindex;
		*i2cdata = I2CDR;
	}
}

/*
 *--------------------------------------------------------------------------------
 * void I2C_Post(void)
 * Purpose : Packeting a packet between firmware and software.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void I2C_Post(void)
{
}


/* End of i2c.c */
