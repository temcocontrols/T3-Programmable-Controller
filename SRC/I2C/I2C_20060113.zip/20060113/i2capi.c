/*
 *********************************************************************************
 *     Copyright (c) 2005	ASIX Electronic Corporation      All rights reserved.
 *
 *     This is unpublished proprietary source code of ASIX Electronic Corporation
 *
 *     The copyright notice above does not evidence any actual or intended
 *     publication of such source code.
 *********************************************************************************
 */
/*================================================================================
 * Module Name : i2capi.c
 * Purpose     :
 * Author      : Robin Lee
 * Date        : 
 * Notes       :
 * $Log$
 *================================================================================
 */

/* INCLUDE FILE DECLARATIONS */
#include	<stdio.h>
#include	"reg80390.h"
#include	"types.h"
#include	"buffer.h"
#include	"i2c.h"
#include	"i2capi.h"


/* STATIC VARIABLE DECLARATIONS */


/* LOCAL SUBPROGRAM DECLARATIONS */


/* LOCAL SUBPROGRAM BODIES */


/* EXPORTED SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * BOOL ByteWrite(U16_T addrofdev, U16_T addrofmem,
 *                U8_T bytedata, U8_T endcond)
 * Purpose : i2c master send a packet for write one data to a device
 * Params  : addrofdev : id address of a device
 *           addrofmem : address for accessing in a device
 *           bytedata  : data for writing
 *           endcond   : packet condition after transmitting
 * Returns : TRUE : this accessing is successful
 *           FALSE: this accessing is failed
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL ByteWrite(U16_T addrofdev, U16_T addrofmem, U8_T bytedata, U8_T endcond)
{
	I2C_BUF		*pttxpkt = NULL;
	U8_T		addrmode = 0;

	/* Get buffer of this packet */
	pttxpkt = (I2C_BUF *)GetPktBuf();
	/* The end condition after transfer complete */
	pttxpkt->I2cend = endcond;
	/* Indicate the packet's direction to master transmit */
	pttxpkt->I2cdir = I2C_MST_XMIT;
	/* Data length exclude device address */
	pttxpkt->Datalen = 0x02;

	/* Device Address with 10-bit or 7-bit */
	I2C_Cmd(SI_RD, I2CCTL, &addrmode);
	if (addrmode & I2C_10BIT)
	{
		pttxpkt->I2caddr.Tenbitaddr = (U16_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	else
	{
		pttxpkt->I2caddr.Sevenbitaddr = (U8_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	/* Register word Address */
	pttxpkt->I2cdata[0] = (U8_T)(addrofmem & 0x00FF);
	/* Access Data */
	pttxpkt->I2cdata[1] = bytedata;

	/* To send packet and i2c bus will be busy for this transfer */
	I2C_FlagEnb(I2C_BUSY);
	I2C_PktBuf(pttxpkt);
	/* Waiting for transfer completely */
	while (I2C_FlagChk(I2C_BUSY)) {}
	/* If the packet does not have any ACK echoed, this transfer fail */
	if (I2C_FlagChk(I2C_NACK))
	{
		I2C_FlagClr(I2C_NACK);
		return FALSE;
	}

	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL PageWrite(U16_T addrofdev, U16_T addrofmem, U8_T*ptpagedata
 *                U16_T writelen, U8_T endcond)
 * Purpose : i2c master send a packet for writing more data to a device
 * Params  : addrofdev : id address of a device
 *           addrofmem : address for accessing in a device
 *           ptpagedata: data string for writing
 *           writelen  : data length for transmitting include addrofmem and data string
 *           endcond   : packet condition after transmitting
 * Returns : TRUE : this accessing is successful
 *           FALSE: this accessing is failed
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL PageWrite(U16_T addrofdev, U16_T addrofmem, U8_T *ptpagedata, U16_T writelen, U8_T endcond)
{
	
	I2C_BUF XDATA	*pttxpkt = NULL;
	U16_T			i;
	U8_T XDATA		addrmode = 0;
	
	/* Get buffer of this packet */
	pttxpkt = (I2C_BUF *)GetPktBuf();
	/* The end condition after transfer complete */
	pttxpkt->I2cend = endcond;
	/* Indicate the packet's direction to master transmit */
	pttxpkt->I2cdir = I2C_MST_XMIT;
	/* Data length exclude device address */
	pttxpkt->Datalen = writelen + 1;
	/* Device Address with 10-bit or 7-bit */
	I2C_Cmd(SI_RD, I2CCTL, &addrmode);
	if (addrmode & I2C_10BIT)
	{
		pttxpkt->I2caddr.Tenbitaddr = (U16_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	else
	{
		pttxpkt->I2caddr.Sevenbitaddr = (U8_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	/* Register word Address */
	pttxpkt->I2cdata[0] = (U8_T)(addrofmem & 0x00FF);
	/* Access Data */
	for (i = 0 ; i < writelen ; i ++)
	{
		pttxpkt->I2cdata[i + 1] = *(ptpagedata + i);
	}
	/* To send packet and i2c bus will be busy for this transfer */
	I2C_FlagEnb(I2C_BUSY);
	I2C_PktBuf(pttxpkt);
	/* Waiting for transfer completely */
	while (I2C_FlagChk(I2C_BUSY)) {}
	/* If the packet does not have any ACK echoed, this transfer fail */
	if (I2C_FlagChk(I2C_NACK))
	{
		I2C_FlagClr(I2C_NACK);
		return FALSE;
	}

	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL RdmRead(U16_T addrofdev, U16_T addrofmem ,I2C_BUF *ptpkttemp, U16_T readlen, U8_T endcond)
 * Purpose : i2c master send a packet for reading data from a device
 * Params  : addrofdev : id address of a device
 *           addrofmem : address for accessing in a device
 *           ptpkttemp : read data buffer pointer
 *           readlen   : data length for reading
 *           endcond   : packet condition after transfer
 * Returns : TRUE : this accessing is successful
 *           FALSE: this accessing is failed
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL RdmRead(U16_T addrofdev, U16_T addrofmem ,I2C_BUF *ptpkttemp, U16_T readlen, U8_T endcond)
{
	I2C_BUF		*ptrxpkt = NULL;
	U16_T		i;
	U8_T		addrmode = 0;

	/* Get buffer of this packet */
	ptrxpkt = (I2C_BUF *)GetPktBuf();
	/* The end condition after transfer complete */
	ptrxpkt->I2cend = I2C_STOP_COND;
	/* Indicate the packet's direction to master receive */
	ptrxpkt->I2cdir = I2C_MST_RCVR;
	/* Data length exclude device address */
	ptrxpkt->Datalen = readlen;
	/* Device Address with 10-bit or 7-bit */
	I2C_Cmd(SI_RD, I2CCTL, &addrmode);
	if (addrmode & I2C_10BIT)
	{
		ptrxpkt->I2caddr.Tenbitaddr = (U16_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	else
	{
		ptrxpkt->I2caddr.Sevenbitaddr = (U8_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	/* Send a dummy packet to indicate the internal address of devices */
	if (endcond & I2C_STOP_COND)
	{
		if (DummyWrite(addrofdev, addrofmem, I2C_STOP_COND))
		{
			/* To send packet and i2c bus will be busy for this transfer */
			I2C_FlagEnb(I2C_BUSY);
			I2C_PktBuf(ptrxpkt);
			/* Waiting for transfer completely */
			while (I2C_FlagChk(I2C_BUSY)) {}
			/* If the packet does not have any ACK echoed, this transfer fail */
			if (I2C_FlagChk(I2C_NACK))
			{
				I2C_FlagClr(I2C_NACK);
				return FALSE;
			}
			/* Get data received in this transfer */
			for (i=0 ; i<=readlen ; i++)
			{
				ptpkttemp->I2cdata[i] = ptrxpkt->I2cdata[i+1];
			}
			return TRUE;
		}
		else
			return FALSE;
	}
	else
	{
		if (DummyWrite(addrofdev, addrofmem, endcond))
		{
			/* To check the packet has a restart condition for next access */
			while (!I2C_FlagChk(I2C_RESTART)) {}
			/* To send packet and i2c bus will be busy for this transfer */
			I2C_FlagClr(I2C_RESTART);
			I2C_FlagEnb(I2C_BUSY);
			I2C_PktBuf(ptrxpkt);
			/* Waiting for transfer completely */
			while (I2C_FlagChk(I2C_BUSY)) {}
			/* If the packet does not have any ACK echoed, this transfer fail */
			if (I2C_FlagChk(I2C_NACK))
			{
				I2C_FlagClr(I2C_NACK);
				return FALSE;
			}
			/* Get data received in this transfer */
			for (i=0 ; i<=readlen ; i++)
			{
				ptpkttemp->I2cdata[i] = ptrxpkt->I2cdata[i];
			}
			return TRUE;
		}
		else
			return FALSE;
	}
}

/*
 *--------------------------------------------------------------------------------
 * BOOL DummyWrite(U16_T addrofdev, U16_T addrofmem, U8_T endcond)
 * Purpose : i2c master send a dummy packet for accessing a device
 * Params  : addrofdev : id address of a device
 *           addrofmem : address for accessing in a device
 *           endcond   : packet condition after transmitting
 * Returns : TRUE : this accessing is successful
 *           FALSE: this accessing is failed
 * Note    : this function only transmit the address of accessing,
 *           it does not have any data
 *--------------------------------------------------------------------------------
 */
BOOL DummyWrite(U16_T addrofdev, U16_T addrofmem, U8_T endcond)
{
	I2C_BUF		*pttxpkt = NULL;
	U8_T		addrmode = 0;

	/* Get buffer of this packet */
	pttxpkt = (I2C_BUF *)GetPktBuf();
	/* The end condition after transfer complete */
	pttxpkt->I2cend = endcond;
	/* Indicate the packet's direction to master transmit */
	pttxpkt->I2cdir = I2C_MST_XMIT;
	/* Data length exclude device address */
	pttxpkt->Datalen = 0x01;
	/* Device Address with 10-bit or 7-bit */
	I2C_Cmd(SI_RD, I2CCTL, &addrmode);
	if (addrmode & I2C_10BIT)
	{
		pttxpkt->I2caddr.Tenbitaddr = (U16_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	else
	{
		pttxpkt->I2caddr.Sevenbitaddr = (U8_T)(addrofdev | ((addrofmem & 0x0700) >> 8));
	}
	/* Register word Address */
	pttxpkt->I2cdata[0] = (U8_T)(addrofmem & 0x00FF);
	/* No Access Data */
	/* To send packet and i2c bus will be busy for this transfer */
	I2C_FlagEnb(I2C_BUSY);
	I2C_FlagClr(I2C_RESTART);
	I2C_PktBuf(pttxpkt);
	/* Waiting for transfer completely */
	while (I2C_FlagChk(I2C_BUSY)) {}
	/* If the packet does not have any ACK echoed, this transfer fail */
	if (I2C_FlagChk(I2C_NACK))
	{
		I2C_FlagClr(I2C_NACK);
		return FALSE;
	}

	return TRUE;
}


/* End of i2capi.c */
