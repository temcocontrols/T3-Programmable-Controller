/*
 *********************************************************************************
 *     Copyright (c) 2005	ASIX Electronic Corporation      All rights reserved.
 *
 *     This is unpublished proprietary source code of ASIX Electronic Corporation
 *
 *     The copyright notice above does not evidence any actual or intended
 *     publication of such source code.
 *********************************************************************************
 */
/*================================================================================
 * Module Name : i2capi.h
 * Purpose     : 
 * Author      : Robin Lee
 * Date        :
 * Notes       :
 * $Log$
 *================================================================================
 */
#ifndef I2CAPI_H
#define I2CAPI_H

/* INCLUDE FILE DECLARATIONS */


/* NAMING CONSTANT DECLARATIONS */


/* MACRO DECLARATIONS */


/* TYPE DECLARATIONS */


/* GLOBAL VARIABLES */


/* EXPORTED SUBPROGRAM SPECIFICATIONS */
BOOL	ByteWrite(U16_T addrofdev, U16_T addrofmem, U8_T bytedata, U8_T endcond);
BOOL	PageWrite(U16_T addrofdev, U16_T addrofmem, U8_T *ptpagedata, U16_T writelen, U8_T endcond);
BOOL	RdmRead(U16_T addrofdev, U16_T addrofmem ,I2C_BUF *ptrxpkt, U16_T readlen, U8_T endcond);
BOOL	DummyWrite(U16_T addrofdev, U16_T addrofmem, U8_T endcond);


#endif /* End of I2CAPI_H */
