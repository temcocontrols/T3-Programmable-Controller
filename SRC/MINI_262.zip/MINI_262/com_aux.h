//void set_baudrate( int port );
void reset_tx_port( S16_T port );
void init_communication_structures( void );
void activate_com1( void );
void activate_com2( void );
void deactivate_com1( void );
void deactivate_com2( void );
/*		int inkey(char* adr, int num, int max, int port);*/
S16_T outputd(S8_T* adr, S16_T num, S16_T port);
void init_active_panels( void );
//int find_remote_point( Point_Net *point );
void reset_active_panels( S16_T n, 	Protocol_parameters *ps );


