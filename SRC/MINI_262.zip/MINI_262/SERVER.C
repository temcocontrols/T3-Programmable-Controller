#include "main.h"

#ifdef BACNET


#define DIG1	100
#define DIG		1
#define AUTO	0
#define MAN		1
#define PROGR	0
#define OPERATOR	1

#define ANALOGDATA         1
#define DIGITALDATA        2
#define DIGITALBUFSIZE     3
#define ANALOGBUFSIZE      4
#define ANALOG_TIMES_SIZE  5
#define DIGITAL_TIMES_SIZE 6

void TSM_ReadMonitor( TSMTable *PTRtable);
void TSM_UpdateMonitor( TSMTable *PTRtable);

extern bit f_test;

STR_flag_flash 	far bac_flash;
/*STR_Flash_CODE*/
U16_T flash_Code_len[MAX_PRGS];
bit flag_write_mass = 0;
extern U8_T count_5s;

void pdeslength(void)
{
  Byte type, number;
  type = 1;
  number = 0;
	panel_net_info.desc_length = search_point( &type, &number, NULL, LENGTH );
  station_list[Station_NUM-1].des_length = panel_net_info.desc_length;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: infodatacommand
 * Purpose: 
 * Params:
 * Returns:
 * Note: this function is called back in server_data()
 * ----------------------------------------------------------------------------
 */
void infodatacommand(TSMTable *PTRtable )
{
	Point point;
	S8_T *PTR;

	if( PTRtable->command < 100 )
	{
		PTR = PTRtable->asdu;
	
		point.point_type = 1;
		point.number = 0;
		panel_net_info.desc_length = search_point( &point.point_type,&point.number, NULL, LENGTH );
        station_list[Station_NUM-1].des_length = panel_net_info.desc_length;

		*PTR++ = sizeof( Panel_Net_Info );
		memcpy( PTR, (S8_T*) &panel_net_info, sizeof( Panel_Net_Info ));
		PTRtable->length = 1+sizeof( Panel_Net_Info );
		PTR += sizeof( Panel_Net_Info );
		
		*PTR++ = TABLE_BANK_LENGTH;
		memcpy( PTR, (S8_T*) table_bank, TABLE_BANK_LENGTH);
		PTRtable->length += 1+TABLE_BANK_LENGTH;
		PTR += TABLE_BANK_LENGTH;
		
		*PTR++ = 13;
		memcpy( PTR, (S8_T*)default_panel, 13);
		PTRtable->length += 14; // 1 + 13
		PTR += 13;
		
		*PTR++ = MAX_UNITS;
		memcpy( PTR, (S8_T *)units, sizeof( Units_element ) * MAX_UNITS);
		PTRtable->length += 1+sizeof( Units_element ) * MAX_UNITS;
		PTR += sizeof( Units_element ) * MAX_UNITS;
		
		*PTR++ = 1;
		*PTR = ind_alarms;
		PTRtable->length += 2;

		PTRtable->dat = PTRtable->asdu;
	}
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: write_received_frame
 * Purpose:  write the received frame
 * Params:
 * Returns:
 * Note:   according to PTRtable->special,decide whether write the received frame
 * ----------------------------------------------------------------------------
 */
void write_received_frame( TSMTable *PTRtable )
{
	Str_program_point *pprg;
	S16_T i,j,space;
	Str_points_ptr ptr;
	U8_T temp1,temp2;
	TSMTable *PTR; 

 
	PTR = Server_TSM_table;

/* if(PTRtable->length_asdu)*/
	if(PTRtable->command==100+PROGRAM)
	{
	//	memcpy( PTRtable->dat, PTRtable->asdu, PTRtable->length_asdu);
		pprg = PTRtable->asdu;
		for(i=0;i<PTRtable->length_asdu/PTRtable->entitysize;i++,pprg++)
		{
			space = pprg->bytes;
			*(((Str_program_point *)PTRtable->dat)+i) = *pprg;
			(((Str_program_point *)PTRtable->dat)+i)->bytes = space;
		}
	}
	else
	{		
		memcpy( PTRtable->dat, PTRtable->asdu, PTRtable->length_asdu);
		
/* the following code is added by chelsea, for store data to flash */
		if(PTRtable->command == 120)
		{
						
		}
		else if(PTRtable->command < 119) /* info[18] */
		{
			ptr.pinf = &info[PTRtable->command - 101];
				
			memcpy(&ptr.pinf->address[ptr.pinf->size * PTRtable->entitysize * (PTRtable->noseq-1)], PTRtable->dat, PTRtable->length_asdu);
			bac_flash.table = PTRtable->command - 101;
			//flash.index = 10 * (PTRtable->noseq-1);	
			bac_flash.index = (PTRtable->length_asdu / PTRtable->entitysize) * (PTRtable->noseq-1);
			bac_flash.len = PTRtable->length_asdu;
			memcpy(bac_flash.dat, PTRtable->asdu, PTRtable->length_asdu);
			bac_flash.flag = 1;				

		}
	}	
	PTRtable->dat += PTRtable->length_asdu; 
	PTRtable->last_length += PTRtable->length_asdu;
	PTRtable->length += PTRtable->length_asdu;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: server_data
 * Purpose:  
 * Params:
 * Returns:
 * Note:   it is used in applayer.c
 * ----------------------------------------------------------------------------
 */


void server_data( TSMTable *PTRtable )
{
	Bank_Type tbank;
	Byte no_points, command, temp;
	Point point;
	Str_points_ptr ptr;
	Str_points_ptr ptr2;
	U16_T bank, space;
	
	int i,loop;
	long l, time;
	char *source_ptr;
	U16_T temp1;
//	U8_T t1;

	if( system_flags.busy && system_flags_2.busy && !system_flags_3c.busy )

    if( PTRtable->command >= 100 )
	  	return;

	

	if( !PTRtable->special )
	{
		temp = 0;
		no_points = 0;
		PTRtable->para_length = 0;
		PTRtable->add_para = 0;
		PTRtable->length = 0;
	}
	else
		temp = 1;
	bank = *(U16_T*)( PTRtable->arg );
	tbank = *(Bank_Type *)( PTRtable->arg );
	command = PTRtable->command;
/*	if(command == 120) 
	{
		memcpy( work_buffer, (char*)&flash_write_status, 2 );
		memcpy( work_buffer+2, (char*)&FlashCRC, 2 );
		PTRtable->dat = work_buffer;
		PTRtable->length = 4;
	}
*/
	if( command >= 100 )
	{  /* command == 150 put data of minipanel to PC */
	  	if( command == 150 && (PTRtable->arg[0]==70 || ICON_NAME_TABLE_COMMAND) )
	  	{
	     	;
		}
	    else
	    {

			system_flags.PRG_changed = 1;
			system_flags_2.PRG_changed = 1;
			system_flags_3c.PRG_changed = 0;

	    }
	}
	
	command %= 50;
	if( !command ) command += 50;
	switch( command )
	{
		case OUTPUT:
		case INPUT:
		case VARIABLE:
		case WEEKLY_ROUTINE:
		case ANNUAL_ROUTINE:
		case PROGRAM:
		case TABLES:
		case CONTROL_GROUP:
		case TOTALIZER:
		case ARRAYS:
		case UNITS:
		{
			ptr.pinf = &info[command-1];
			PTRtable->entitysize = ptr.pinf->size;
			if( tbank.bank_type )
			{
				 PTRtable->length = ptr.pinf->size * tbank.no_points;
				 PTRtable->dat = ptr.pinf->address + tbank.position * ptr.pinf->size;
				 no_points = tbank.no_points;
			}
			else
			{
				 no_points = ptr.pinf->max_points;
				 PTRtable->length = ptr.pinf->size * no_points;				 
				 PTRtable->dat = ptr.pinf->address;				 
			}	

        	if(command==ANNUAL_ROUTINE)
          		misc_flags.check_ar=1;

			break;
		}
		case CONTROLLER:
		{
			#if 1
			if( PTRtable->command < 100 )
			{
				ptr.pcon = controllers;
				for( i=0; i<MAX_CONS; i++, ptr.pcon++ )
				{
					get_point_value( (Point*)&ptr.pcon->input, &ptr.pcon->input_value );
					get_point_value( (Point*)&ptr.pcon->setpoint, &ptr.pcon->setpoint_value );
				}
			}
			PTRtable->entitysize = sizeof(Str_controller_point);
			PTRtable->length = MAX_CONS*sizeof(Str_controller_point);
			PTRtable->dat = controllers;
			no_points = MAX_CONS;
			#endif
			break;
		}

		case ANALOG_MONITOR:
		{
		#if 1
		//	if(bank % 256 == 0)		bank /= 256;    // should shift bank  changed by chesea
			if( !PTRtable->special )
			{
				PTRtable->entitysize = sizeof(Str_monitor_point);
				if( tbank.bank_type )
				{
					PTRtable->length = sizeof(Str_monitor_point) * tbank.no_points;
					PTRtable->dat = (char *)monitors + tbank.position * sizeof(Str_monitor_point);
					no_points = tbank.no_points;
				}
				else
				{
					no_points = MAX_MONITORS;

				PTRtable->length = sizeof(Str_monitor_point) * no_points;


					PTRtable->dat = (char *)monitors;
				}
				if( PTRtable->command > 100 )
					PTRtable->special = 1;
			}
			else
			{
				if( PTRtable->timeout <= 0 )
				{
					PTRtable->special = 0;
				}
				else
				{
					if( PTRtable->special == 2 )
							ptr.pmon = NULL;
					PTRtable->special++;
					PTRtable->entities_per_frame = PTRtable->length_asdu / sizeof(Str_monitor_point);
					ptr.pmon = (Str_monitor_point*)PTRtable->dat;
					ptr2.pmon = (Str_monitor_point*)PTRtable->asdu;
					for( bank=0; bank<PTRtable->entities_per_frame; bank++, ptr.pmon++, ptr2.pmon++ )
					{
						command = 0;
						/* compare the old definition with the new one except for the label */
						if( memcmp( ptr.pmon->inputs, ptr2.pmon->inputs, ( sizeof(Str_monitor_point) - 9 ) ) )
						{
						/* compare sample rate */
							if( memcmp( (void*)&ptr.pmon->second_interval_time,
										(void*)&ptr2.pmon->second_interval_time, 3 ) )



							{ /* different sample rate */
								if( GetByteBit(ptr2.pmon->flag1,mon_an_inputs,4)/*ptr2.pmon->an_inputs*/ )
									command |= 0x01;  /* need a new analog block */
								/* compare number of digital points */
								if( ( GetByteBit(ptr.pmon->flag1,mon_num_inputs,4)/*ptr.pmon->num_inputs*/ - GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr.pmon->an_inputs*/ ) 
									!= ( GetByteBit(ptr2.pmon->flag1,mon_num_inputs,4)/*ptr2.pmon->num_inputs*/ - GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr2.pmon->an_inputs*/ ) )
									command |= 0x02;  /* need a new digital block */
								else
								{
									/* compare digital points' definition */
									if( memcmp( (void*)(ptr.pmon->inputs + GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr.pmon->an_inputs*/),
											(void*)(ptr2.pmon->inputs + GetByteBit(ptr2.pmon->flag1,mon_an_inputs,4)/*ptr2.pmon->an_inputs*/),
										( GetByteBit(ptr.pmon->flag1,mon_num_inputs,4)/*ptr.pmon->num_inputs*/ - GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr.pmon->an_inputs*/ ) * sizeof( Point_Net ) ) )
										command |= 0x02;  /* need a new digital block */
								}
							}
							else /* same sample rate */
							{
								/* compare number of analog points */
								if( GetByteBit(ptr.pmon->flag1,mon_an_inputs,4) /*ptr.pmon->an_inputs*/ == GetByteBit(ptr2.pmon->flag1,mon_an_inputs,4)/*ptr2.pmon->an_inputs*/ )
								{
									/* compare analog points' definition */
									if( memcmp( (void*)(ptr.pmon->inputs),
												(void*)(ptr2.pmon->inputs),
										( GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr.pmon->an_inputs*/ ) * sizeof( Point_Net ) ) )
										command |= 0x01;  /* need a new analog block */
								}
								else
								{
									command |= 0x01;  /* need a new analog block */
								}
								/* compare number of digital points */
								if( ( GetByteBit(ptr.pmon->flag1,mon_num_inputs,4)/*ptr.pmon->num_inputs*/ - GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr.pmon->an_inputs*/ ) !=
										( GetByteBit(ptr2.pmon->flag1,mon_num_inputs,4)/*ptr2.pmon->num_inputs*/ - GetByteBit(ptr2.pmon->flag1,mon_an_inputs,4)/*ptr2.pmon->an_inputs*/ ) )
								{
									command |= 0x02;  /* need a new digital block */
								}
								else
								{
									/* compare digital points' definition */
									if( memcmp( (void*)(ptr.pmon->inputs + GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr.pmon->an_inputs*/),
											(void*)(ptr2.pmon->inputs + GetByteBit(ptr2.pmon->flag1,mon_an_inputs,4)/*ptr2.pmon->an_inputs*/),
										( GetByteBit(ptr.pmon->flag1,mon_num_inputs,4)/*ptr.pmon->num_inputs*/ - GetByteBit(ptr.pmon->flag1,mon_an_inputs,4)/*ptr.pmon->an_inputs*/ ) *
											sizeof( Point_Net ) ) )
										command |= 0x02;  /* need a new digital block */
								}
							}
						}

						if(bank == 3)
						{
							bank = bank;
						}

						no_points = ( ptr.pmon - monitors );/* / sizeof(Str_monitor_point);*/

						if( command & 0x01 ) /* get a new analog block */
						{
							get_new_analog_block( no_points, 1, ptr2.pmon );
						}
						if( command & 0x02 ) /* get a new digital block */
						{
							get_new_digital_block( no_points, 1, ptr2.pmon );
						}
					}
					write_received_frame( PTRtable );
					if( PTRtable->length == PTRtable->total_length )
					{
							PTRtable->special = 0;
					}
				}
			}
		//	bank = bank * 256;  // shift bank at the beginning
			#endif
			break;
		}

		case USERS:
		{
			#if 1
			 PTRtable->length = sizeof(Password_struct);
			 PTRtable->dat = &passwords;
			 break;
			 #endif
		}


		case 13:  /* ALARM */
		{
		#if 1
			if( !PTRtable->special  )
			{
				PTRtable->entitysize = sizeof(Alarm_point);

				ptr.palrm = alarms;
				for( i=0; i<MAX_ALARMS; i++, ptr.palrm++ )
					SetByteBit(&ptr.palrm->flag4,0,alarm_change_flag,2);/*ptr.palrm->change_flag = 0;*/


				if( tbank.bank_type )
				{
					no_points = tbank.no_points;
					PTRtable->dat = (char*)alarms + tbank.position * sizeof(Alarm_point);
					PTRtable->length = tbank.no_points * sizeof(Alarm_point);
				}
				else
				{
					no_points = MAX_ALARMS;
					PTRtable->length = sizeof(Alarm_point) * no_points;
					PTRtable->dat = (char*)alarms;
				}

				if( PTRtable->command > 100 )
					PTRtable->special = 1;
			}
			else
			{
				if( PTRtable->timeout <= 0 )
				{
					PTRtable->special = 0;
				}
				else
				{
					if( PTRtable->accepted_length >= PTRtable->total_length )
					{
						PTRtable->last_length += PTRtable->length_asdu;
						PTRtable->length += PTRtable->length_asdu;
						update_alarm_tbl( (Alarm_point *)PTRtable->asdu, PTRtable->length / sizeof(Alarm_point) );

						if( PTRtable->length == PTRtable->total_length )
						{
							PTRtable->special = 0;
						}
					}
				}
			}
			#endif
			break;
		}
		case 16:  /* PROGRAM CODE */
		{
		 /* program code */
		 #if 1
//if(bank % 256 == 0)		bank /= 256;    // should shift bank  changed by chesea
			bank = mGetPointWord2(bank);
			ptr.pprg = &programs[bank];
			if( PTRtable->special )
			{
				if( PTRtable->timeout <= 0 )
				{
/*
          if( ( PTRtable->special ) == 1 )
					{
						if( ptr.pprg->bytes )
							ptr.pprg->on_off = PTRtable->prg_code_flag;
					}
					else
*/
					{
/*
						ptr.pprg->on_off = 0;
						code_length -= ptr.pprg->bytes;
						ptr.pprg->bytes = 0;
						ptr.pprg->errcode = 0;
						program_address[bank] = NULL;
*/
/*						ptr.pprg->on_off = PTRtable->prg_code_flag;*/
					}
					PTRtable->special = 0;
					PTRtable->prg_code_flag = 0;
				}
				else
				{
					if( PTRtable->accepted_length >= PTRtable->total_length )
					{
/*
						if( PTRtable->special == 1 )
						{
							set_semaphore( &use_virtual );
							if( ptr.pprg->bytes )
							{
								source_ptr = program_address[bank] + ptr.pprg->bytes;
								space = code_length - ( source_ptr - code );
								memmove( program_address[bank], source_ptr, space );
								for( i=0; i<MAX_PRGS; i++ )
									if( programs[i].bytes && ( program_address[bank] <
																											program_address[i]  ) )
										program_address[i] -= ptr.pprg->bytes;
								code_length -= ptr.pprg->bytes;
							}
							PTRtable->data = code + code_length;
							program_address[bank] = PTRtable->data;
							ptr.pprg->bytes = 0;
							ptr.pprg->errcode = 0;
							clear_semaphore( &use_virtual );
						}
*/
						PTRtable->special++;
						write_received_frame( PTRtable );

						if( PTRtable->length == PTRtable->total_length )
						{
					//temp1 = mGetPointWord2(ptr.pprg->bytes);//ptr.pprg->bytes / 256;
							if( mGetPointWord2(ptr.pprg->bytes))
							{
								#if 0
								source_ptr = program_address[bank] + temp1 /*ptr.pprg->bytes*/;
								space = code_length + PTRtable->total_length - ( source_ptr - _code );
								memmove( program_address[bank], source_ptr, space );

								/* put CODE to flash_code struct,then store it into flash   -- add by chelsea */

							/*	flash_Code.index = bank;
								flash_Code.len = space;
								memcpy(flash_Code.dat,program_address[bank],space);*/
								for( i=0; i<MAX_PRGS; i++ )
									if( ( programs[i].bytes / 256) && ( program_address[bank] < program_address[i]  ) )  // shift programs[i].bytes by chelsea
										program_address[i] -= temp1 /*ptr.pprg->bytes*/;
								code_length -= temp1 /*ptr.pprg->bytes*/;
								#endif
								

							}
							program_address[bank] = &_code[bank];
							flash_Code_len[bank] = PTRtable->length;

							update_local_list( program_address[bank], PTRtable ); 
							if( PTRtable->length <= 11 )
								/*temp1 */ptr.pprg->bytes = 0;
							else
								/*temp1 */ptr.pprg->bytes = PTRtable->length;

							/* recount code lenght once update program code */
							code_length = 0;
							for(loop = 0;loop < MAX_PRGS;loop++)
							{							
								code_length += flash_Code_len[loop];
							}

							ptr.pprg->bytes = mGetPointWord2(ptr.pprg->bytes);
							PTRtable->special = 0;
							PTRtable->prg_code_flag = 0;
						}
					}
					else
					{
/*						ptr.pprg->on_off = PTRtable->prg_code_flag;*/
						PTRtable->special = 0;
						PTRtable->prg_code_flag = 0;
					}
				}
			}
			else
			{
				if( PTRtable->command > 100 ) /* write comm */
				{
					PTRtable->special = 1;
					space = PROGRAMS_POOL_SIZE - code_length;
//					PTRtable->prg_code_flag = ptr.pprg->on_off;  tested by chelsea
/*					ptr.pprg->on_off = 0;*/
/*					PTRtable->length = space + ptr.pprg->bytes;*/
					PTRtable->length = space;
					PTRtable->dat = &_code[bank];// + code_length;
					flash_Code_len[bank] = PTRtable->length;
				}
				else
				{
				//	temp1 = ptr.pprg->bytes / 256;
					PTRtable->length = mGetPointWord2(ptr.pprg->bytes);//temp1;
					PTRtable->dat = program_address[bank];
					space = PROGRAMS_POOL_SIZE;
					PTRtable->para.string[0] = 0x00;
 					PTRtable->para.string[1] = 0x28;

					//memcpy( PTRtable->para.string, &space, 2 );
					space = code_length;
					PTRtable->para.string[2] = space;
					PTRtable->para.string[3] = 0x00;
					//memcpy( PTRtable->para.string+2, (void *)&space, 2 );
					PTRtable->add_para = 1;
					PTRtable->para_length = 4;
					PTRtable->special = 0;
					PTRtable->prg_code_flag = 0;
				}
			}
		//	bank = bank * 256;  // shift bank at the beginning
			#endif
			break;
		}
		case 17:  /* WEEKLY_ROUTINES_DATA */
		
			#if 1
			if( !PTRtable->special  )
			{
				PTRtable->entitysize = MAX_SCHEDULES_PER_WEEK * sizeof( Wr_one_day );
				if( tbank.bank_type)
				{
					PTRtable->dat = (char *)wr_times + tbank.position * PTRtable->entitysize;
					PTRtable->length = tbank.no_points * PTRtable->entitysize;
					no_points = tbank.no_points;
				}
				else
				{
					PTRtable->dat = (char *)wr_times + (mGetPointWord2(bank)) * PTRtable->entitysize;
					PTRtable->length = PTRtable->entitysize;
					no_points = MAX_WR;
				}
				if( PTRtable->command > 100 )
					PTRtable->special = 1;
      
			else
			{
				if( PTRtable->timeout <= 0 )
				{
					PTRtable->special = 0;
					check_weekly_routines();
				}
				else
				{
					if( PTRtable->accepted_length >= PTRtable->total_length )
					{
						write_received_frame( PTRtable );
						if( PTRtable->length == PTRtable->total_length )
						{
							check_weekly_routines();
							PTRtable->special = 0;
						}
					}
				}
			}
			#endif
			break;
		}
		case 18:  /* ANNUAL_ROUTINES_DATA */
		{
			#if 1
			if( !PTRtable->special  )
			{
				PTRtable->entitysize = AR_DATES_SIZE;
				if( tbank.bank_type )
				{
					 PTRtable->dat = (char *)ar_dates + tbank.position * PTRtable->entitysize;
					 PTRtable->length = tbank.no_points * PTRtable->entitysize;
					 no_points = tbank.no_points;
				}
				else
				{
					 PTRtable->dat = (char *)ar_dates +  (mGetPointWord2(bank)) * PTRtable->entitysize;
					 PTRtable->length = PTRtable->entitysize;
					 no_points = MAX_AR;
				}
				if( PTRtable->command > 100 )
					PTRtable->special = 1;
			}
			else
			{
				if( PTRtable->timeout <= 0 )
				{
					PTRtable->special = 0;
				}
				else
				{
					if( PTRtable->accepted_length >= PTRtable->total_length )
					{
						write_received_frame( PTRtable );
						if( PTRtable->length == PTRtable->total_length )
						{
              				misc_flags.check_ar=1;
						//	check_annual_routines();
							PTRtable->special = 0;
						}
					}
				}
			}
			#endif
			break;
		}
		case 19:
		{
			/*	Control Groups	*/
			#if 1
			PTRtable->entitysize = sizeof( Str_grp_element );

			//if(bank % 256 == 0)		bank /= 256;    // should shift bank  changed by chesea	
			bank = mGetPointWord2(bank);
			ptr.pgaux = &aux_groups[ bank];

			if( PTRtable->command > 100 ) /* write comm */
			{
				if( PTRtable->special )
				{
					if( PTRtable->timeout <= 0 )
					{
						if( PTRtable->special != 1 )
						{
							if( !PTRtable->keep_old_group )
							{
								ptr.pgaux->no_elements = 0;
								ptr.pgaux->address = NULL;
							}
							PTRtable->keep_old_group = 0;
						}
						PTRtable->special = 0;
					}
					else
					{
						if( PTRtable->accepted_length >= PTRtable->total_length )
						{
							if((PTRtable->special++) == 1 )
							{
								if( ptr.pgaux->no_elements )
								{
									if((MAX_ELEMENTS - total_elements ) < PTRtable->total_length / sizeof(Str_grp_element))
									{ /* if the available group space is less then the size it will
									     be written then move the groups located after the
											 current one on top of it - we lose the current group
											 the new data will be added at the end of the
											 data_group buffer */
                    					PTRtable->keep_old_group = 0;
										/* Update the remote points list */
										ptr2.pgrel = ptr.pgaux->address;
										for( i = 0; i < ptr.pgaux->no_elements; i++, ptr2.pgrel++ )
										{
											if( GetWordBit(ptr2.pgrel->flag5Int,grp_location,2))	/* ptr2.pgrel->location */
												delete_remote_point( &ptr2.pgrel->point, -1 );
										}
										/* move the groups located after the current one over it */
										source_ptr = (char*)( ptr.pgaux->address ) + ptr.pgaux->no_elements * sizeof( Str_grp_element );
										space = (((char*)group_data) + group_data_length ) - source_ptr;

										move_groups( (char*)ptr.pgaux->address, source_ptr,	space, ptr.pgaux->no_elements, ptr.pgaux->address );
/*
                    #### move_groups does all this ####
										memmove( ptr.pgaux->address, source_ptr, space );
										for( i=0; i<MAX_GRPS; i++ )
											if( aux_groups[i].no_elements &&
													( ptr.pgaux->address < aux_groups[i].address ) )
														aux_groups[i].address -= ptr.pgaux->no_elements;

										total_elements -= ptr.pgaux->no_elements;
										group_data_length = total_elements * sizeof( Str_grp_element );
*/
										ptr.pgaux->no_elements = 0;
/*                  	ptr.pgaux->address = (char*)group_data + group_data_length;*/
									}
									else
										PTRtable->keep_old_group = 1;
								}
		
								PTRtable->dat = ((char*)group_data) + group_data_length;
							}
							write_received_frame( PTRtable);

							if( PTRtable->length == PTRtable->total_length )
							{
				                if( PTRtable->keep_old_group )
				                { /* Update the remote points list */
				                  	PTRtable->keep_old_group = 0;
									ptr2.pgrel = ptr.pgaux->address;
 									for( i = 0; i < ptr.pgaux->no_elements; i++, ptr2.pgrel++ )
									{
										if( GetWordBit(ptr2.pgrel->flag5Int,grp_location,2)/*ptr2.pgrel->location*/ )
											delete_remote_point( &ptr2.pgrel->point, -1 );
									}
                  /* the new data was added at the end of the group_data
									buffer and now we have to overwrite the old group */
									source_ptr = (char*)( ptr.pgaux->address ) + ptr.pgaux->no_elements * sizeof( Str_grp_element );
									space = ( ((char*)group_data) + group_data_length + PTRtable->length ) - source_ptr;

									move_groups( (char*)ptr.pgaux->address, source_ptr,	space, ptr.pgaux->no_elements, ptr.pgaux->address );
/*
									memcpy( ptr.pgaux->address, source_ptr, space );
									for( i=0; i<MAX_GRPS; i++ )
										if( aux_groups[i].no_elements &&
												( ptr.pgaux->address < aux_groups[i].address ) )
													aux_groups[i].address -= ptr.pgaux->no_elements;
									total_elements -= ptr.pgaux->no_elements;
									group_data_length = total_elements * sizeof( Str_grp_element );
*/
                				}
               					ptr.pgaux->address = (char*)group_data + group_data_length;
								ptr.pgaux->no_elements = PTRtable->length / sizeof( Str_grp_element );
								total_elements += ptr.pgaux->no_elements;
								group_data_length += PTRtable->length;
								if( !ptr.pgaux->no_elements )
								{
									ptr.pgaux->address = NULL;
								}
								else
								{
									ptr2.pgrel = ptr.pgaux->address;
									for( i = 0; i < ptr.pgaux->no_elements; i++, ptr2.pgrel++ )
									{
										if( GetWordBit(ptr2.pgrel->flag5Int,grp_location,2)/*ptr2.pgrel->location*/ )
											insert_remote_point( &ptr2.pgrel->point, -1 );

									}
								}
								PTRtable->special = 0;
							}
						}
						else
						{
							PTRtable->special = 0;
						}
					}
				}
				else
				{
					PTRtable->special = 1;
					space = ( MAX_ELEMENTS - total_elements + ptr.pgaux->no_elements ) * sizeof( Str_grp_element );
					PTRtable->length = space;
				}
			}
			else
			{
				PTRtable->length = ptr.pgaux->no_elements * sizeof( Str_grp_element );
				PTRtable->dat = (char *)ptr.pgaux->address;
				ptr2.pgrel = ptr.pgaux->address;
				for( bank = 0; bank < ptr.pgaux->no_elements; bank++, ptr2.pgrel++ )
				{
					update_grp_element( ptr2.pgrel);
				}
				space = MAX_ELEMENTS;   /* max number of elements */
				memcpy( PTRtable->para.string, &space, 2 );
				space = total_elements; /* total number of existing elements */
				memcpy( PTRtable->para.string+2, (void *)&space, 2 );
				PTRtable->add_para = 1; /* the para field will be added before the asdu field */
				PTRtable->para_length = 4;
			}

		//	bank = bank * 256;  // shift bank at the beginning

			#endif

			break;
		}
		case 20:
		{
			#if 1
			point = *( Point * )( PTRtable->arg );
			ptr.pinf = &info[point.point_type-1];
			no_points = 1;
			if( point.point_type >= OUTPUT && point.point_type <= ARRAYS )
			{
				if( ( point.point_type == CONTROLLER ) && ( PTRtable->command < 100 ) )
				{
					ptr2.pcon = &controllers[point.number];
					get_point_value( (Point*)&ptr2.pcon->input, &ptr2.pcon->input_value );
					get_point_value( (Point*)&ptr2.pcon->setpoint, &ptr2.pcon->setpoint_value );
				}
				PTRtable->length = ptr.pinf->size;
				PTRtable->entitysize = PTRtable->length;
				PTRtable->dat = ptr.pinf->address + point.number * PTRtable->length;

         		if(point.point_type==ANNUAL_ROUTINE)
          			misc_flags.check_ar=1;

			/*	bac_flash.table = point.point_type - 1;
				bac_flash.index = point.number;
				bac_flash.flag = 2;
				bac_flash.len = ptr.pinf->size;
				memcpy(bac_flash.dat, PTRtable->asdu,  ptr.pinf->size);*/
			}
			#endif
			break;
		}
		case 21:
		{
			PTRtable->dat = (char*)&ora_current;
			PTRtable->length = sizeof(Date_block);
			if( PTRtable->command > 100 ) /* write comm */
			{
				if( PTRtable->special )
				{
					write_received_frame( PTRtable );
					update_timers();
				//	if( system_flags.clock_active )
					//	set_clock();
         		//	misc_flags.sendtime = 1;
				}
				else
					PTRtable->special = 1;
			}
			break;
		}

		case 22: /* READMONITORDATA_T3000 */
		{
    
			TSM_ReadMonitor( PTRtable);
    
			break;
		}


		case 23: /* UPDATEMEMMONITOR_T3000 */
		{
    
			TSM_UpdateMonitor( PTRtable);
		 break;
		}


		case 24:
		{
		}
		case 25:
		{
			#if 1
				/* Point Info */
			if( PTRtable->command > 100 ) /* write comm */
			{
				if( PTRtable->special )
				{								
					write_received_frame( PTRtable );
					ptr.pgaux = &aux_groups[PTRtable->arg[1]];
          			switch( PTRtable->arg[0] )
					{
						case 0:  /* DELETE_ELEMENT */
							ptr2.pgrel = ptr.pgaux->address;
							for( i=0; i<ptr.pgaux->no_elements; i++, ptr2.pgrel++ )
              				if( ptr2.pgrel->nr_element == PTRtable->arg[2] ) break;
              				if( i >= ptr.pgaux->no_elements )             	break;
							if( GetWordBit(ptr2.pgrel->flag5Int,grp_location,2) /*ptr2.pgrel->location */)
								delete_remote_point( &ptr2.pgrel->point, -1 );
							space = ( ((char*)group_data) + group_data_length ) - (char*)(ptr2.pgrel+1);
						
              				move_groups( (char*)ptr2.pgrel, (char*)(ptr2.pgrel+1), space, 1, ptr.pgaux->address );
              /* move the groups located after the current group and update
							   their start address */
							ptr.pgaux->no_elements--;
							break;
            			case 1:  /* ADD_ELEMENT */
						
			              	if( total_elements < MAX_ELEMENTS )
			              	{					
								if( !ptr.pgaux->no_elements || !ptr.pgaux->address )
			                		ptr.pgaux->address = (char*)group_data + group_data_length;
								ptr2.pgrel = ptr.pgaux->address + ptr.pgaux->no_elements;
								
                /* now calculate the length of group_data located after
								   this group */
								space = ( ((char*)group_data) + group_data_length ) - (char*)ptr2.pgrel;
               	/* dest = end of this group + one group element */
               	/* source = end of this group */
              					move_groups( (char*)(ptr2.pgrel+1), (char*)ptr2.pgrel, space, 1, ptr.pgaux->address );
              	/* move the groups located after the current group and
								   update their start address */
                /* make room for the new element by moving the groups located
								after the current group */
				                memcpy( (char*)ptr2.pgrel, PTRtable->asdu, sizeof( Str_grp_element ) );
								if( GetWordBit(ptr2.pgrel->flag5Int,grp_location,2) /*ptr2.pgrel->location */ )
									insert_remote_point( &ptr2.pgrel->point, -1 );
				                ptr.pgaux->no_elements++;
				              	break;
							}
            			case 2:  /* UPDATE_ELEMENT */
						
							ptr2.pgrel = ptr.pgaux->address;
              				for( i=0; i<ptr.pgaux->no_elements; i++, ptr2.pgrel++ )
              				if( ptr2.pgrel->nr_element == PTRtable->arg[2] )          	break;
              				if( i >= ptr.pgaux->no_elements )             	break;
              				if( !memcmp( ptr2.pgrel, work_buffer, sizeof(Point_Net) ) )
	            					memcpy( ptr2.pgrel, PTRtable->asdu, sizeof( Str_grp_element ) );
              				break;
          			}
					PTRtable->special = 0;
					
				}
				else
				{					
					PTRtable->special = 1;
					PTRtable->length = sizeof( Str_grp_element );
					PTRtable->dat = work_buffer;
					PTRtable->entitysize = sizeof( Str_grp_element );
				}
			}
			else
			{
				no_points = 1;
				point = *( Point * )( PTRtable->arg );
				PTRtable->dat = work_buffer;
				PTRtable->length = sizeof( Str_grp_element );
				memset( work_buffer, 0, 40 );
				ptr.ppinf = (Point_info *)work_buffer;
				ptr.ppinf->number = point.number;
				ptr.ppinf->point_type = point.point_type;
				ptr.ppinf->panel = Station_NUM;
				ptr.ppinf->network_number = panel_net_info.network_number;
				update_grp_element( (Str_grp_element *)work_buffer );
			
			}
			#endif
			break;
		}
		case 28: /* Clear Panel */
		{
		
				system_flags.clear_panel = 1;
				system_flags_2.clear_panel = 1;
				system_flags_3c.clear_panel = 0;
				PTRtable->length = 0;
		
				break;
		}
		case 47:
		{
			#if 1
			if( PTRtable->command < 100 ) /* read comm */
			{
				if( PTRtable->special )
				{
					if( PTRtable->special == 1 )
					{
						PTRtable->para.string[0] = 0;
					}
					PTRtable->special++;
					PTRtable->length_asdu = search_point( (Byte*)PTRtable->arg,(Byte*)PTRtable->para.string, PTRtable->asdu, DESCRIPTOR_POINT );
				}
				else
				{
					PTRtable->special = 1;
					PTRtable->para.string[0] = 0;
					PTRtable->length = search_point( (Byte*)PTRtable->arg,(Byte*)PTRtable->para.string, NULL, LENGTH_POINT );
				}
			}
			else
			{
				 PTRtable->dat = work_buffer;
				 PTRtable->length = 0;
			}
			#endif
			break;
		}
		case 49:
		{
			#if 1
			 PTRtable->dat = (char *) arrays_address[bank];
			 PTRtable->length = arrays[bank].length * sizeof( long );
			#endif
			 break;
		}
		case 50:
		{
			switch( PTRtable->arg[0] )
			{
				case 21:   /* station list command */
					PTRtable->dat = (char*)station_list;
					PTRtable->length = MAX_STATIONS * sizeof( Station_point );
/*					point.point_type = 1;*/
/*					point.number = 0;*/
         			pdeslength();

	/*				panel_net_info.desc_length = search_point( &point.point_type,&point.number, NULL, LENGTH );
          			station_list[Station_NUM-1].des_length = panel_net_info.desc_length;*/
					break;
					case 22:
					case 75:
						PTRtable->dat = (char*) table_bank;
						PTRtable->length = TABLE_BANK_LENGTH;
						break;
					case 32:				
					case 33:
						PTRtable->dat = (char*)default_panel;
						PTRtable->length = 13;
						break;
					case 51: /* ALARM_NOTIFY_COMMAND: */
						#if 1
						PTRtable->length = 1;
						PTRtable->dat = (char *)&ind_alarms;
						break;
						#endif
					case 70:
        			{
					#if 1	
						bank = mGetPointWord2(*(U16_T*)PTRtable->asdu);
						if( bank > 32 )		break;
						else
						{
	              			i=2;
	              			temp = PTRtable->arg[1];
						    if( (temp&0x01)==0x01 )
					    	{
					     		if( bank!=Station_NUM )
					     		{
									if(!( Port_parameters[PTRtable->port].need_info & (1L<<(bank-1)) ) )
									{
										Port_parameters[PTRtable->port].rec_trigger_sequence = 4;  /* laststation_connected for RS485 */
								  		Port_parameters[PTRtable->port].need_info |= ( 1L << ( bank - 1 ) );
						      			station_list[bank - 1].state = 1;
/*                  set_active_panel( bank );*/
/*						   new_alarm_flag |= 0x04;
						     resume(ALARMTASK);
*/
						    		}
						   		memcpy( station_list[bank-1].name, &PTRtable->asdu[2], 17);
								i+=17;
								memcpy(&station_list[bank-1].des_length, &PTRtable->asdu[2+17], 2);
						station_list[bank-1].des_length = mGetPointWord2(station_list[bank-1].des_length);
								i+=2;

							    station_list[bank-1].panel_type=PTRtable->asdu[i++];
							    memcpy(&station_list[bank-1].version, &PTRtable->asdu[i], 2);
						station_list[bank-1].version = mGetPointWord2(station_list[bank-1].version);
							    i+=2;
							    memcpy(station_list[bank-1].tbl_bank, &PTRtable->asdu[i], TABLE_BANK_LENGTH);
							    i += TABLE_BANK_LENGTH;
						     }
						     else
							    i+=17+2+1+2+TABLE_BANK_LENGTH;
						}

						if(temp&0x02)
						{
							//	convert_T3000_time( (T3000_Date_block*)&PTRtable->asdu[i] ); /*2 = panel*/
							//	update_timers();
							//	if( system_flags.clock_active )
							//		set_clock();
							i += sizeof(T3000_Date_block);
						}
					    if(temp&0x08)
					    {
						    memcpy(&space, &PTRtable->asdu[i], 2);
						space = mGetPointWord2(space);
						    i+=2;
					      if( space>32 ) break;
						    if( space==Station_NUM )
						    {
							   panelconnected = 1;
						    }
					    }
					    if( !temp )     /* panel OFF*/
					    {
							if( bank == Station_NUM )
							{
							 	Port_parameters[PTRtable->port].FirstToken = 0;
							}
							else
							{
							//reset_active_panels( bank, &Port_parameters[PTRtable->port] );
							}
					    }
/*
					if( (temp&0x01)==ON )
					{
						router(N_UNITDATArequest, I_Am_Router_To_Network_Prop, NULL, port);
					}
*/
						}
						bank = mGetPointWord2(bank);
						#endif
				}
				break;
				case SEND_WANTPOINTS_COMMAND:      /* 72 */
				
/* check if other panels need local points
														and add them to the network point list */
				{
				#if 1
				bank = mGetPointWord2(*(U16_T*)PTRtable->asdu);
					bank /= sizeof(Point_Net);
/*					ptr2.pnp = network_points_list;*/
					ptr.pwp = (WANT_POINTS*)(PTRtable->asdu+2);
/*					if(wantpointsentry!=2)*/
/*           sendwantnetpoints(bank,ptr,0);*/
					 for( space=0; space<bank; space++, ptr.pwp++)
					 {
						if( (ptr.pwp->panel==Station_NUM-1) && ptr.pwp->network_number == panel_net_info.network_number )
						{
							misc_flags.wantpointsentry=1;
							ptr2.pnp = network_points_list;
							for( i=0; i<MAXNETWORKPOINTS; i++, ptr2.pnp++)
							{
								if( !memcmp( ptr.pwp, &ptr2.pnp->point, sizeof( Point_Net ) ) )
								{
									break;
								}
							}
							if( i>=MAXNETWORKPOINTS )
							{
								ptr2.pnp = network_points_list;
								for( i=0; i<MAXNETWORKPOINTS; i++ ,ptr2.pnp++ )
								{
									if( !ptr2.pnp->point.point_type )
									{
										memcpy( ptr2.pnp, ptr.pwp, sizeof( Point_Net ) );
										break;
									}
								}
							}
						}
					 }
					 #endif
					break;
				}
				case SEND_NETWORKPOINTS_COMMAND:			
				/* check if points from this list are used localy and update the remote points list */
				{
					#if 1
/*					bank = *(Uint*)PTRtable->asdu; */
					PTRtable->asdu += 2;
					PTRtable->asdu++;
				bank = mGetPointWord2(*(U16_T*)PTRtable->asdu);
					bank /= sizeof(NETWORK_POINTS);
					ptr.pnp = (NETWORK_POINTS	*)(PTRtable->asdu+2);
/*          sendwantnetpoints(bank,ptr,1);*/
					for(space=0; space<bank; space++, ptr.pnp++)
					{
						ptr2.prp = remote_points_list;
						for( i=0; i<MAXREMOTEPOINTS; i++, ptr2.prp++ )
						{
						 	if( ptr.pnp->point.point_type )
								if( !memcmp( &ptr.pnp->point,&ptr2.prp->point, sizeof(Point_Net) ) ||
							    	(!memcmp( &ptr.pnp->point,&ptr2.prp->point, sizeof(Point_T3000)) &&
                   				((unsigned int)ptr2.prp->point.network_number) == 0x0FFFF))
							{
								SetByteBit(&ptr.pnp->flag,GetByteBit(ptr2.prp->flag1,REMOTE_description_label,3),REMOTE_description_label,3);
							 //	ptr.pnp->description_label = ptr2.prp->description_label;
               					l = ptr2.prp->point.network_number;
							 	memcpy( &ptr2.prp->point, ptr.pnp, sizeof(NETWORK_POINTS) );
               					ptr2.prp->point.network_number=l;
							}
						}
					}
					#endif
					break;
				}
				case SEND_INFO_COMMAND:
				{
					if(PTRtable->arg[1]==SENDINFO_IAMPANELOFF)
					{
					 bank = mGetPointWord2(*(U16_T*)PTRtable->asdu);   /* panel# that is OFF*/
					 if( bank == Station_NUM )
					 {
				     Port_parameters[PTRtable->port].FirstToken = 0;
					 }
					 else
					 {
			       //reset_active_panels( bank, &Port_parameters[PTRtable->port] );
						 if( Port_parameters[PTRtable->port].PTP_transmission_state == bank )
						 {
                /* NS - next station for RS485     */
						  memcpy(&space, &PTRtable->asdu[4], 2);        /* the next panel# for the panel# that is the OFF*/
							space = mGetPointWord2(space);
						  Port_parameters[PTRtable->port].PTP_transmission_state = space;    /* reset the NS*/
						 }
						 if( Port_parameters[PTRtable->port].PTP_reception_state == bank ) /* change OS?*/
						 {
								/* OS - original station for RS485 */
						  memcpy(&space, &PTRtable->asdu[2], 2);        /* the originate panel# for the panel# that is the OFF*/
							space = mGetPointWord2(space);
						  Port_parameters[PTRtable->port].PTP_reception_state = space;
					   }
					 }
					}
				}
       			 break;
				case PANEL_INFO1_COMMAND:  // 110
					if( PTRtable->command > 100 )
					{
						if( !PTRtable->special )
						{
							PTRtable->dat = (char*) work_buffer;
							PTRtable->length = sizeof( Panel_Net_Info );
							PTRtable->special = 1;
							flash_write_status = 0x00;
						}
						else
						{
							write_received_frame( PTRtable );
					
							system_flags.name_changed = 1;
							system_flags_2.name_changed = 1;
							system_flags_3c.name_changed = 0;
				
							PTRtable->special = 0;
						}
					}
					else
					{
/*
						point.point_type = 1;
						point.number = 0;
*/
           				pdeslength();
						panel_net_info.desc_length = search_point( &point.point_type,&point.number, NULL, LENGTH );
            			station_list[Station_NUM-1].des_length = panel_net_info.desc_length;

						PTRtable->dat = (char*) &panel_net_info;
						PTRtable->length = sizeof( Panel_Net_Info );
					}
					break;
				case 111: /* MiniInfo2 */
					if( PTRtable->command > 100 )
					{

					}
					else
					{
#ifdef MINI64
						PTRtable->dat = &cards_info;
#endif

#ifdef MINI8x8
						PTRtable->dat = work_buffer;
#endif
						PTRtable->length = sizeof(MiniInfo2);
					}
					break;
				case 112: /* MiniCommInfo */
					if( PTRtable->command > 100 )
					{			
//I disabled it for now
			
						if( !PTRtable->special )
						{
							PTRtable->dat = work_buffer;
							PTRtable->length = 2 * sizeof( MiniCommInfo );
							PTRtable->special = 1;
						//	flash_write_status = 0x00;
						}
						else
						{
							write_received_frame( PTRtable );
						/*	if( memcmp( (void*)comm_info, (void*)work_buffer, 2*sizeof( MiniCommInfo ) ) )
							{								
									system_flags.comm_changed = 1;
									system_flags_2.comm_changed = 1;
									system_flags_3c.comm_changed = 0;
							}*/
				
              			// TBD:	memcpy( flash_data+31048, work_buffer, 2*sizeof( MiniCommInfo ) );  
							PTRtable->special = 0;
						}
                

					}
					else
					{
						PTRtable->dat = (char*)comm_info;
						PTRtable->length = 2 * sizeof( MiniCommInfo );
					}
					break;
				case 113: /* System_Name_Number */
					break;
				case ICON_NAME_TABLE_COMMAND:
				#if 1
				{
				 PTRtable->length = sizeof(Icon_names);
				 PTRtable->dat   = (char *)Icon_names;
				}
				#endif 
				break;

			 	case 115: /* ERASE SECTOR */
				{



				}
				break;
				case 116: /* WRITEDATAMINI_COMMAND */
					PTRtable->dat = work_buffer;
					PTRtable->length = 0;
					/*flash_flags.write_data = 1;
					flash_flags_2.write_data = 1;
					flash_flags_3c.write_data = 0;*/

					PTRtable->special = 0;
					break;
				case 117: /* SENDCODEMINI_COMMAND , receive code and execute */				
	/*			{
					if( PTRtable->command > 100 )
					{
						if( !PTRtable->special )
						{
							PTRtable->dat = RAM_code;
							PTRtable->length = MAX_RAM_CODE_LENGTH;
							PTRtable->special = 1;
						}
						else
						{
							if( PTRtable->timeout <= 0 )
							{
								RAM_code_length = 0;
								PTRtable->special = 0;
							}
							else
							{
								if( PTRtable->accepted_length >= PTRtable->total_length )
								{
									write_received_frame( PTRtable );
									if( PTRtable->length == PTRtable->total_length )
									{
										RAM_code_length = PTRtable->length;
										flash_flags.run_code = 1;
										flash_flags_2.run_code = 1;
										flash_flags_3c.run_code = 0;
										PTRtable->special = 0;
									}
								}
							}
						}
					}
				}*/
				break;
				case 118: /* SENDDATAMINI_COMMAND  */
			
				/*	if( !PTRtable->special  )
					{
						if( PTRtable->arg[1] != 0 )
							flash_data_length = 0;
						if( FLASH_BUFFER0_LENGTH - flash_data_length > 0x0FFFF )
							PTRtable->length = 0x0FFFF;
						else
							PTRtable->length = FLASH_BUFFER0_LENGTH - flash_data_length;
						PTRtable->dat = flash_data + flash_data_length;
						PTRtable->special = 1;
					}
					else
					{
						if( PTRtable->timeout <= 0 )
						{
							PTRtable->special = 0;
						}
						else
						{
							if( PTRtable->accepted_length >= PTRtable->total_length )
							{
								write_received_frame( PTRtable );
								if( PTRtable->length == PTRtable->total_length )
								{
									flash_data_length += PTRtable->length;
									PTRtable->special = 0;
								}
							}
						}
					}*/			
					break;

				case 119: /* READFLASHSTATUS_COMMAND ,Flash info */
				{
					/*l = FLASH_BUFFER0_LENGTH;
					PTRtable->dat = flash_info;
					PTRtable->length = 7 * sizeof( SectorInfo );
					memcpy( PTRtable->para.string, &l, 4 );
					PTRtable->add_para = 1;
					PTRtable->para_length = 4;*/
				}
				break;
				case 120: /* READSTATUSWRITEFLASH_COMMAND, Update status */
				{
					memcpy( work_buffer, (char*)&flash_write_status, 2 );
					memcpy( work_buffer+2, (char*)&FlashCRC, 2 );
					PTRtable->dat = work_buffer;
					PTRtable->length = 4;
				}
				break;
				case 121: /* RESTARTMINI_COMMAND, Restart minipanel with new firmware */
				{
					flash_flags.restart = 1;
					flash_flags_2.restart = 1;
					flash_flags_3c.restart = 0;
					PTRtable->length = 0;
				}
				break;
				case 122: /* STOREPRG_COMMAND */
				{
					//system_flags.store_PRG = 1;
					//system_flags_2.store_PRG = 1;
					//system_flags_3c.store_PRG = 0;
					//PTRtable->length = 0;
					/*flash.table = 1;
					flash.index = 0;
					flash.len = 12*38;
					memcpy(flash.dat, Input, flash.len);
					IntFlashErase(ERA_RUN,0x70000);			
					Flash_Write(flash);*/
					// delay 5 second, then write flash
					flag_write_mass = 1;
				//	count_5s = 0;
					//Test[0]++;
					//Flash_Write_Mass();
				}
				break;
				case 124:			// infodata_command				
					infodatacommand( PTRtable );
					break;
        		
				default:
				{
					PTRtable->dat = NULL;
					PTRtable->length = 0;
					PTRtable->para_length = 0;
					PTRtable->add_para = 0;
					break;
        		}
			}
			break;
		}
/*
		case SEND_ALARM_COMMAND:
		{

	 Alarm_point *ptr,*ptr1;
	 if( PTRtable->command > 100 )
	 {
		if( PTRtable->special )
		{
		 if( PTRtable->timeout <= 0 )
		 {
					PTRtable->special = 0;
		 }
     else
     {
			ptr = (Alarm_point *)PTRtable->asdu;
			if(	ptr->alarm_panel==Station_NUM || ptr->where1==255 || (ptr->where1==Station_NUM||ptr->where2==Station_NUM||
															 ptr->where3==Station_NUM||ptr->where4==Station_NUM||
															 ptr->where5==Station_NUM ) )
			 {
				if( !bank )
				{
				 if( (i=checkforalarm((char *)&ptr->alarm_id,ptr->prg,ptr->alarm_panel,1)) > 0 )
				 {
					if( alarms[i-1].change_flag != 2 )
					{
					 if( ptr->restored && !alarms[i-1].restored )
					 {
						alarms[i-1].restored = 1;
						if(!ind_alarms--) ind_alarms=0;
						if(ptr->alarm_panel==Station_NUM)
						{
						 alarms[i-1].where_state1 = 0;
						 alarms[i-1].where_state2 = 0;
						 alarms[i-1].where_state3 = 0;
						 alarms[i-1].where_state4 = 0;
						 alarms[i-1].where_state5 = 0;
						 new_alarm_flag |= 0x01;
						 resume(ALARMTASK);
						}
					 }
					 else
					 {
						if( ptr->acknowledged && !alarms[i-1].acknowledged )
						{
						 if( !alarms[i-1].restored )
						 {
						  if(!ind_alarms--) ind_alarms=0;
						 }
						 alarms[i-1].acknowledged = 1;
						 if(ptr->alarm_panel==Station_NUM)
						 {
							alarms[i-1].where_state1 = 0;
							alarms[i-1].where_state2 = 0;
							alarms[i-1].where_state3 = 0;
							alarms[i-1].where_state4 = 0;
							alarms[i-1].where_state5 = 0;
							new_alarm_flag |= 0x01;
							resume(ALARMTASK);
						 }
						}
					 }
					}
				 }
				 else
				 {
					if( !ptr->restored && !ptr->acknowledged )
					{
					 i = checkalarmentry();
					 if(i>=0 && alarms[i].change_flag != 2 )
					 {
						ptr1 = &alarms[i];
						ptr1->change_flag  = 2;
						memcpy(ptr1,ptr,sizeof(Alarm_point));
						ptr1->alarm        = 1;
						ptr1->no           = i;
						ptr1->ddelete      = 0;
						ptr1->original     = 0;
						ptr1->change_flag  = 0;
						if( ++ind_alarms > MAX_ALARMS) ind_alarms = MAX_ALARMS;
					 }
					}
				 }
				}
				else
				{
				 if( (i=checkforalarm((char *)&ptr->alarm_id,ptr->prg,ptr->alarm_panel,1)) > 0 )
				 {
					if( !alarms[i-1].restored && !alarms[i-1].acknowledged )
					{
						  if(!ind_alarms--) ind_alarms=0;
					}
					alarms[i-1].alarm        = 0;
					alarms[i-1].change_flag  = 0;
					alarms[i-1].restored     = 0;
					alarms[i-1].acknowledged = 0;
					alarms[i-1].ddelete      = 1;
			    alarms[i-1].original     = 0;
					if(ptr->alarm_panel==Station_NUM)
					{
						 ptr->where_state1 = 0;
						 ptr->where_state2 = 0;
						 ptr->where_state3 = 0;
						 ptr->where_state4 = 0;
						 ptr->where_state5 = 0;
						 new_alarm_flag |= 0x02;
						 resume(ALARMTASK);
					}
				 }
				}
			 }
      }
     }
		 else
					PTRtable->special = 1;

     }
		}
*/
		default:
		{
			PTRtable->dat = NULL;
			PTRtable->length = 0;
			PTRtable->para_length = 0;
			PTRtable->add_para = 0;
		}
	}
	if( !temp )
	{
		PTRtable->accepted_length = PTRtable->length + PTRtable->para_length;
		if( PTRtable->command < 100 )
		{
			if( no_points && PTRtable->entitysize )
			{
				 PTRtable->entities_per_frame = (( MAXASDUSIZE - PTRtable->para_length ) / PTRtable->entitysize );
			
			}
			else
			{
				if( PTRtable->accepted_length > MAXASDUSIZE )
				{
					PTRtable->entitysize = MAXASDUSIZE;
					PTRtable->entities_per_frame = 1;
				}
				else
				{
					PTRtable->entities_per_frame = 1;
					PTRtable->entitysize = PTRtable->accepted_length;
				}
			}
		}
	}
}


#if 1
/*
 * ----------------------------------------------------------------------------
 * Function Name: update_local_list
 * Purpose: 
 * Params:
 * Returns:
 * Note: this function is called back in server_data()
 * ----------------------------------------------------------------------------
 */
void update_local_list( S8_T *prg_code, TSMTable *PTRtable )
{
	Program_remote_points *prp;
	S16_T pbytes, ind, i;

		ind = mGetPointWord2(*((S16_T*)(prg_code))); /* code length */
	ind += 5; /* 3 bytes for RET + 2 bytes for code length*/
			ind += mGetPointWord2(*((S16_T*)(prg_code+ind)));   /* local VARs length */
	ind += 2; /* 2 bytes for local VARs length*/
	ind += mGetPointWord2(*((S16_T*)(prg_code+ind)));   /* TIMERs' length */
	ind += 2; /* time buff length */

	prp = ( Program_remote_points * )( prg_code + ind + 2 );
	pbytes = ind;
	ind = mGetPointWord2(*((S16_T*)(prg_code+pbytes))); /* Progr. points list length*/
	for(i=0; i<ind; )
	{
		if( prp->index < 999 && prp->index >= 0 )
		{
			delete_remote_point( NULL, prp->index );	//	test by chelsea
			memmove( prp, prp+1, (ind-i-1)*sizeof( Program_remote_points ) );
			ind--;
			memcpy( prg_code+pbytes, &ind, 2);  /* update ind*/
			PTRtable->length -= sizeof( Program_remote_points );
		}
		else
		{
			if( prp->index < 0 )
			{
				prp->index = insert_remote_point( &prp->point, -1 ); //  test by chelsea
				i++;
			}
			else
			{
				prp->index -= 1000;
				i++;
			}
      		prp++;
		}
	}
	if( PTRtable->length <= 11 )		PTRtable->length = 0;
}




#if 1

/*
 * ----------------------------------------------------------------------------
 * Function Name: TSM_22
 * Purpose: 
 * Params:
 * Returns:
 * Note: this function is called back in server_data() READMONITORDATA_T3000
 * ----------------------------------------------------------------------------
 */
void TSM_ReadMonitor( TSMTable *PTRtable) 
{
//		Point point;
	Str_points_ptr ptr;
	Str_points_ptr ptr2;

	ptr2.pmaux = mon_aux+(PTRtable->arg[0]-1);
	if( !PTRtable->special )
	{
		switch( PTRtable->arg[1] )
		{
			case ANALOGDATA:
			{
				if( ptr2.pmaux->first_analog_block != 0x0FF )
				{
					ptr.pmb = mon_block + ptr2.pmaux->first_analog_block;
					memcpy( &PTRtable->comm_arg.monupdate.size, PTRtable->asdu, 4 );
					memcpy( &PTRtable->comm_arg.monupdate.most_recent_time,PTRtable->asdu+4, 4 );
					PTRtable->comm_arg.monupdate.oldest_time = ptr.pmb->start_time;
					scan_monitor_blocks( PTRtable, ptr.pmb,ptr2.pmaux->no_analog_blocks, SELECT );
					PTRtable->special = 1;
				}
				break;
			}
			case DIGITALDATA:
			{
				if( ptr2.pmaux->first_digital_block != 0x0FF )
				{
					ptr.pmb = mon_block + ptr2.pmaux->first_digital_block;
					memcpy( &PTRtable->comm_arg.monupdate.size, PTRtable->asdu, 4 );
					memcpy( &PTRtable->comm_arg.monupdate.most_recent_time,PTRtable->asdu+4, 4 );
					PTRtable->comm_arg.monupdate.oldest_time = ptr.pmb->start_time;
					scan_monitor_blocks( PTRtable, ptr.pmb,	ptr2.pmaux->no_digital_blocks, SELECT );
					PTRtable->special = 1;
				}
				break;
			}
			case DIGITALBUFSIZE:
			{
				if( ptr2.pmaux->first_digital_block != 0x0FF )
				{
					ptr.pmb = mon_block + ptr2.pmaux->first_digital_block;
					memcpy( &PTRtable->comm_arg.monupdate.oldest_time,PTRtable->asdu, 8 );
					scan_monitor_blocks( PTRtable, ptr.pmb, ptr2.pmaux->no_digital_blocks, SCAN );
				}
				PTRtable->add_para = 1;
				PTRtable->para_length = 4;
				break;
			}
		}
	}
	else
	{
		send_monitor_frame( PTRtable, ptr.pmb );
	}
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: TSM_UpdateMoniter
 * Purpose: 
 * Params:
 * Returns:
 * Note: this function is called back in server_data() UPDATEMEMMONITOR_T3000
 * ----------------------------------------------------------------------------
 */
void TSM_UpdateMonitor( TSMTable *PTRtable)
{
	Str_points_ptr ptr;
	Str_points_ptr ptr2;

	ptr2.pmaux = mon_aux+( PTRtable->arg[0] );
	if( !PTRtable->special )
	{
		switch( PTRtable->arg[1] )
		{
			case ANALOGDATA:
			{
				memcpy( &PTRtable->comm_arg.monupdate.size, PTRtable->asdu, sizeof(MonitorUpdateData) );
				if( ptr2.pmaux->first_analog_block != 0x0FF )
				{
					ptr.pmb = mon_block+ptr2.pmaux->first_analog_block;
					scan_monitor_blocks( PTRtable, ptr.pmb,	ptr2.pmaux->no_analog_blocks, SELECT );
					PTRtable->special = 1;
				}
				break;
			}
			case DIGITALDATA:
			{
				memcpy( &PTRtable->comm_arg.monupdate.size, PTRtable->asdu, sizeof(MonitorUpdateData) );
				if( ptr2.pmaux->first_digital_block != 0x0FF )
				{
					ptr.pmb = mon_block+ptr2.pmaux->first_digital_block;
					scan_monitor_blocks( PTRtable, ptr.pmb,	ptr2.pmaux->no_digital_blocks, SELECT );
					PTRtable->special = 1;
				}
				break;
			}
			case ANALOG_TIMES_SIZE:
			{
				if( ptr2.pmaux->first_analog_block != 0x0FF )
				{
					ptr.pmb = mon_block+ptr2.pmaux->first_analog_block;
					PTRtable->comm_arg.monupdate.most_recent_time = time_since_1970;
					PTRtable->comm_arg.monupdate.oldest_time = ptr.pmb->start_time;
					scan_monitor_blocks( PTRtable, ptr.pmb,
															 ptr2.pmaux->no_analog_blocks, SCAN );
					PTRtable->para.montimes.most_recent_time = time_since_1970;
					PTRtable->para.montimes.oldest_time = ptr.pmb->start_time;
				}
				PTRtable->add_para = 1;
				PTRtable->para_length = 12;
				break;
			}
			case DIGITAL_TIMES_SIZE:
			{
				if( ptr2.pmaux->first_digital_block != 0x0FF )
				{
					ptr.pmb = mon_block+ptr2.pmaux->first_digital_block;
					PTRtable->comm_arg.monupdate.most_recent_time = time_since_1970;
					PTRtable->comm_arg.monupdate.oldest_time = ptr.pmb->start_time;
					scan_monitor_blocks( PTRtable, ptr.pmb,ptr2.pmaux->no_digital_blocks, SCAN  );
					PTRtable->para.montimes.most_recent_time = time_since_1970;
					PTRtable->para.montimes.oldest_time = ptr.pmb->start_time;
				}
				PTRtable->add_para = 1;
				PTRtable->para_length = 12;
				break;
			}
		}
	}
	else
	{
		send_monitor_frame( PTRtable, ptr.pmb );
	}

}
#endif

#endif


#endif

