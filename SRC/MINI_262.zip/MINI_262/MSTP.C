
#include "main.h"
#ifdef BACNET



#define ON        1
#define OFF       0
#define FALSE     0
#define TRUE      1

void MSTP_Master_node(void );
void initmstpvars(Protocol_parameters *ps);


bit flag_test = 0;

void vStartMstpTask(void)
{
	sTaskCreate(MSTP_Master_node, (const signed portCHAR * const)"MSTP_Master_node",portMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, (xTaskHandle *)&xHandleMSTP); 
}


/* 0 want_points, 1 network_points */
/*
 * ----------------------------------------------------------------------------
 * Function Name: initmstpvars
 * Purpose: initial MSTP variables
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
S16_T sendpoints( Protocol_parameters *ps, S16_T type )
{	
					
	Str_points_ptr ptr;
	S16_T  i,j,k,l;
	FRAME_ENTRY *frame;
/* S8_T *p;*/
	l = 0;
/*	i = 0;*/

	if(!type)
	{
		k = 0;
		ptr.prp = &remote_points_list[0];
		for( j=0; j<MAXREMOTEPOINTS; j++, ptr.prp++ )
		{
/*
if(ptr.prp->point.network_number==panel_net_info.network_number || ptr.prp->point.network_number==0x0FFFF )
*/
			if( ptr.prp->point.point_type )
			{
				k += sizeof(Point_Net);
			}
		}
		l = k+2;
	}
	else
	{
		k=0;
		ptr.pnp = &network_points_list[0];
		for(j=0; j<MAXNETWORKPOINTS; j++, ptr.pnp++ )
		{
			if( ptr.pnp->point.point_type )
			{
				k += sizeof(NETWORK_POINTS);
			}
		}
		l = k+5;
	}

	if( k )
	{
    	frame = SendFreeEntry( ps->port, 0 );
		if( !frame )	{  	return 0; }
		
/*    p = frame->Buffer[0];*/
/* npci */
		frame->Buffer[0] = 0x01; /* npci  version BACnet */
		frame->Buffer[1] = 0x00; /* local network, DNET, DADR, SNET, SADR absent */
/* apci */
		frame->Buffer[2] = (BACnetUnconfirmedRequestPDU<<4);
		frame->Buffer[3] = UnconfirmedPrivateTransfer;
/* asdu - service request */
		frame->Buffer[4] = 0x09;           /* tag */
		frame->Buffer[5] = VendorID;
		frame->Buffer[6] = 0x1A;           /* tag */
		frame->Buffer[7] = 50;
		frame->Buffer[8] = 72+type;
    	i=9;
		l += 3;                              /* 3 bytes args */
		i += encodetag(1, 2, frame->Buffer+i, l );
		frame->Buffer[i++] = 0;             /* extra low   */
		frame->Buffer[i++] = 0;             /* extra high  */
		frame->Buffer[i++] = 0;             /* reserved    */

		k = i;
		if(!type)
		{
			ptr.prp = remote_points_list;
			for(j=0; j<MAXREMOTEPOINTS; j++, ptr.prp++ )
			{
			if( ptr.prp->point.point_type )
			{
				memcpy( &frame->Buffer[i+2], &ptr.prp->point, sizeof(Point_Net) );
			  memcpy(&((Point_Net*)&frame->Buffer[i+2])->network_number,&panel_net_info.network_number,2);
				i += sizeof(Point_Net);
			}
			}
			*(U16_T*)&frame->Buffer[k] = mGetPointWord2(i-k);
			i += 2;
		}
		else
		{
			memcpy( &frame->Buffer[i], &panel_net_info.network_number, 2 );
			i += 2;
			frame->Buffer[i++] = Station_NUM;
			k = i;
			ptr.pnp = network_points_list;
			
			for(j=0; j<MAXNETWORKPOINTS; j++, ptr.pnp++ )
			{
				if( ptr.pnp->point.point_type )
				{
					if( !get_point_info( (Point_info*)&ptr.pnp->point ) )
					{
					/*	ptr.pnp->auto_manual = 0;
						ptr.pnp->digital_analog = 0;
						ptr.pnp->decomisioned = 0;
					*/
						ptr.pnp->flag = 0;						
						ptr.pnp->units = 1;
						ptr.pnp->point_value = 0;
			
					}
					memcpy( &frame->Buffer[i+2], ptr.pnp, sizeof(NETWORK_POINTS) );
					i += sizeof(NETWORK_POINTS);
				}
			}

		 	*(U16_T*)&frame->Buffer[k] = mGetPointWord2(i - k);
		 	i += 2;
		}
		frame->Length = i;
		Send_frame( frame, BACnetDataNotExpectingReply, 0x0FF, ps );
		RemoveSentEntry( frame );
/* 4.6ms per remote point for type=1*/
	#if 0
	 	if(type)
		{
			j = ((1 + i / sizeof(NETWORK_POINTS)) * 46 / 50) + 1;
			if( j < 8 ) j = 8;
		//	vTaskDelay( j );
			
		}
		else
		{
			/* 1.5ms per remote point for type=0*/
			j = ((1 + i / sizeof(Point_Net)) * 15 / 50) + 2;
			if( j < 8 ) j = 8;
		//	vTaskDelay( j );
		}
	#endif

		if( type )
		{
			memset( network_points_list, 0, MAXNETWORKPOINTS * sizeof(NETWORK_POINTS) );
		}


	}
	return 1;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: sendinfo
 * Purpose: 
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
int sendinfo(S16_T status, S16_T panel, Protocol_parameters *ps)
{
	S16_T i = 0;
	U16_T l = 0;
	
	FRAME_ENTRY *frame;
	S8_T *Buffer;

    frame = &sendinfo_buffer;
    Buffer = &frame->Buffer[0];
/* npci */
	Buffer[i++]=0x01;      /* npci  version BACnet */
	Buffer[i++]=0x00;      /* npci  local network  */
/* apci */
	Buffer[i++] = (BACnetUnconfirmedRequestPDU<<4);
	Buffer[i++] = UnconfirmedPrivateTransfer;
/* here comes the Service Request encoding defined in "PROTOCOL.DOC" */
	Buffer[i++] = 0x09;           /* tag */
	Buffer[i++] = VendorID;
	Buffer[i++] = 0x1A;           /* tag */
	Buffer[i++] = COMMAND_50+100;
	Buffer[i++] = 70;


/*//////////////////////////////*/
	Buffer[i++]=0x2D;               			/*Octet String, L>4*/
	Buffer[i] = 3+2;     /* panel_num*/
	
	if( status&0x01 )
		Buffer[i] += 17+2;    //24    17 is sizo of station_name 
	if( status&0x02 )
		Buffer[i] += sizeof(T3000_Date_block);  /* time*/  //28    23
	if( status&0x08 )
		Buffer[i] += 2+22+2+17;  /* panel_to_receive,system_name,network,network_name*/   //  48
	l = i;
	i++;
	/* parameters*/
	Buffer[i++]=status;                 				/*extra low*/
	Buffer[i++]=0;             				/*extra high*/
	Buffer[i++]=0;                  				/*reserved*/
	memcpy( &Buffer[i], &panel, 2);
	i += 2;

	if( (status&0x01)==ON )
	{
		memcpy( &Buffer[i], panel_net_info.panel_name/*"11111111111111111"*/, 17 );
		i += 17;
		memcpy( &Buffer[i], &panel_net_info.desc_length, 2 );
		i += 2;
		Buffer[i++] = panel_net_info.panel_type;
		memcpy( &Buffer[i], (S8_T*)&panel_net_info.version_number, 2);
		i += 2;
		memcpy( &Buffer[i], table_bank, TABLE_BANK_LENGTH);
		i += TABLE_BANK_LENGTH;
		Buffer[l] += 1+2+TABLE_BANK_LENGTH;
	}
	if( status&0x02 )
	{
		//convert_mini_time( &Buffer[i] );   test by chelsea
		memcpy( &Buffer[i], (char*)&ora_current, sizeof(T3000_Date_block));
		i += sizeof( T3000_Date_block);
	}
	if( status&0x08 )
	{
		l = ps->PTP_reception_state;    /* OS - original station for RS485 */
		memcpy( &Buffer[i], &l, 2);
		i += 2;
		memset( &Buffer[i], 0, 22);  /* system_name */
		i += 22;
		memcpy( &Buffer[i], (S8_T*)&panel_net_info.network_number, 2);
		i += 2;
		memcpy( &Buffer[i], (S8_T*)panel_net_info.network_name, 17);
		i += 17;
	}

	frame->Length = i;
	Send_frame( frame, BACnetDataNotExpectingReply, 0x0FF, ps );

//	vTaskDelay(6);
	return i;
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: initmstpvars
 * Purpose: initial MSTP variables
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
void initmstpvars(Protocol_parameters *ps)
{
	ps->SoleMaster = 0;
	ps->FirstToken = 0;
	ps->timepoints = 400;
  	ps->rec_trigger_sequence = 0;            /* laststation_connected for RS485 */
	ps->PTP_reception_state=Station_NUM;     /* OS - original station for RS485 */
	ps->PTP_transmission_state=Station_NUM;  /* NS - next station for RS485     */
 	ps->ack1received = 0;                    /* newpanelbehind for RS485 */
	netpointsflag=0;
	ps->need_info = ( 1L << ( Station_NUM - 1 ) );
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: MSTP_Master_node
 * Purpose: MSTP master node state machine
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
extern U8_T MstpDataReady;
extern U8_T flag_Ready;
extern bit flag_int;
void MSTP_Master_node(void )
{
	volatile S8_T TimeOut,resetport;
//	volatile S8_T timebetweentoken; /*, netpointsflag=0;*/
	volatile S16_T n,counter;
/*	S8_T action;	*/
	volatile U8_T     NS;
	volatile U8_T     PS;
/*	volatile U8_T 	  OS; */  //  ps->PTP_reception_state    //Original Station
	volatile U8_T     TokenCount;
	volatile U8_T     source_panel;
	volatile U8_T     day;       		/* 1-31	*/

	portTickType xDelayPeriod = ( portTickType )2 / portTICK_RATE_MS;
//	portTickType xLastWakeTime = xTaskGetTickCount();


	FRAME_ENTRY *frame, *rec_frame;
	Protocol_parameters *ps;		

	panelconnected = 0;						/* panelconnected */
	ps->nack0received	 = 0;               /* panelOff for RS485 */
	ps->ack0received = 0;    				/* receivedpollformaster for RS485 */
	ps->ack1received = 0;					/* newpanelbehind*/
	ps->nack1received = 0 ;					/* receivedtoken */
	initmstpvars(ps);
	ps->rec_trigger_sequence = 0;			/* laststation_connected for RS485 */
//	resetport = 700;
//	counter = 10;
	TokenCount = NMAX_POLL;
	for(; ;)
	{
		
		//if( cQueueReceive( M, &flag_Ready, ( portTickType ) 5 ) == pdPASS )
		//if(!flag_int)
		{
	//	vTaskDelayUntil( &xLastWakeTime, 1 );
		vTaskDelay(xDelayPeriod);	
		/*	ps->TS = Station_NUM;  /* node address */
		if( !port )
		{
			rec_frame = &ReceiveFrame_0;
			ps = Port_parameters;
		//	ps = Port_parameters;
		//	rec_frame = ps->rec_frame;
		}
		else
		{
			rec_frame = &ReceiveFrame_1;
			ps = &Port_parameters[1];
		}
	
		switch( ps->MSTP_MASTER_state )
		{
			case MSTP_MASTER_IDLE: 
			/*In the IDLE state, the node waits for a frame.*/

			/* 		 LostToken    */
			if( ps->SilenceTimer >= TNO_TOKEN /*|| !resetport*/)
			{	
				/*if(!resetport)	
				{
					resetport = 700;
					counter = 1;
				}*/	
				
				if(ps->FirstToken)  // ???????????????????????
				{	
					initmstpvars(ps);
					init_active_panels();
					PS = Station_NUM;
					NS = Station_NUM;
					ps->PTP_reception_state = Station_NUM;

				}				
				//counter--;
				/* panelOff for RS485 */
				if(ps->nack0received)  
				{
					ps->SilenceTimer = 0;
				}
				ps->MSTP_MASTER_state = MSTP_MASTER_NO_TOKEN;
				break;
			}

			if( ReceiveFrameAvailable( ps ) )   
			{
			//	if(ps->nack0received)	 break;  /* panel off */
				/*        ReceivedInvalidFrame*/
				if( ps->received_invalid_frame == TRUE )
				{
					
					RemoveReceivedEntry( ps );
				//	ps->received_invalid_frame = FALSE;
					break;
				}
				
				if( ps->received_valid_frame == TRUE )
				{
				//	ps->received_valid_frame = FALSE;

				/*         	 ReceivedUnwantedFrame */
					if( (rec_frame->Destination != Station_NUM && rec_frame->Destination != 255) ||
					(rec_frame->Destination == 255 && ( rec_frame->FrameType == Token || rec_frame->FrameType == BACnetDataExpectingReply ||rec_frame->FrameType == TestRequest ) ))
						 /* or a proprietary type known to this node and which expects a reply or FrameType has a value which indicates a standard or
								proprietary type which is not known to this node */						
					{
						 
						 RemoveReceivedEntry( ps );
						 break;
					}
					

			/*          ReceivedToken 	*/
					if( rec_frame->Destination == Station_NUM && rec_frame->FrameType == Token )
					{
						//resetport = 700;
						source_panel = rec_frame->Source;
						/*				 RemoveReceivedEntry( ps );*/
						ps->UsedToken = FALSE;
						
						if(ps->ack0received==0)         /* receivedpollformaster for RS485 */
						{
							RemoveReceivedEntry( ps );
							/* received token before poll for master. There is another panel*/
							/* with the same panel number. The panel does not respond to the received token*/
							panelconnected = 3;
							ps->nack0received = 1;             /* panelOff for RS485 */
							
							break;
						}					
			

						if( ps->nack1received == 0 )  /* receivedtoken for RS485 */
						{
						//	ps->nack1received = 1;
/*
					// indicates the panel received the token. It is used in
					// connection with NETTASK. It is used when you want to
					// assure that the token goes ones around the network
					// before to take an action.
					// Ex. If you want to broadcast a command and then to continue
					// after the token goes around the network, set mstp->receivedtoken=0
					// and then wait until mstp->receivedtoken becomes 1.
*/
						}

						if(ps->PTP_reception_state != source_panel) /* OS - original station for RS485 */
						{
							if(ps->PTP_reception_state!=Station_NUM || ps->SoleMaster == TRUE )
							{
							  /* a new panel behind me ON network*/
							  	ps->ack1received = 1;      /* newpanelbehind for RS485 */
								
							}
						}
						ps->PTP_reception_state = source_panel;     /* OS - original station for RS485 */
	

/*----------------*/
/*           send info to last panel connected: system name etc. */
/*           if first token then broadcast information about its: system name, etc*/
					 	if( ps->rec_trigger_sequence >= 1 )  /* laststation_connected for RS485 */
						{
							--ps->rec_trigger_sequence;
							if( ps->FirstToken >= 2 )
							{
								if(!ps->ack1received)  /* newpanelbehind for RS485 */
								{
									
									sendinfo( ON,Station_NUM,ps );									
								}
								else
								{
									sendinfo( 0x09,Station_NUM,ps );									
								}
								
							/*	if(Station_NUM<ps->PTP_reception_state) // OS - original station for RS485
								{
									sendinfo( 0x02,Station_NUM,ps );
								}*/
							
							}
						  	if( !ps->rec_trigger_sequence )  /* laststation_connected for RS485 */
							{								
								ps->ack1received=0;    /* newpanelbehind for RS485 */
								if(	memcmp(&ps->need_info, &panel_net_info.active_panels[0], 4 ) )
									sendinfo( ON,Station_NUM,ps );  
								if(Station_NUM < ps->PTP_reception_state) /* OS - original station for RS485 */
									misc_flags.sendtime = 1;
							}
						}

						if( ps->FirstToken < 50 )
						{
							ps->FirstToken++;
							if(!ps->ack1received)  /* newpanelbehind for RS485 */
							{
								//ps->ack1received = 1;
							 	sendinfo( ON,Station_NUM,ps );
							}
							else
							{
							 	sendinfo( 0x09,Station_NUM,ps );
							}						
						}

						if( netpointsflag )
						{
							if(misc_flags.wantpointsentry)
							{
							 	//for( n=0; n<0x2000; n++ );  // why delay here ?
								Send_frame( NULL, -1, Station_NUM, ps );
								sendpoints( ps, 1);
							}
							misc_flags.wantpointsentry=0;
							netpointsflag=0;
							ps->timepoints = 5000;
						}

						if(!ps->timepoints)
						{
							if( number_of_remote_points )
							{
								//for( n=0; n<0x2000; n++ );  
							 	Send_frame( NULL, -1, Station_NUM, ps );
							 	sendpoints( ps, 0 );

							}
							netpointsflag++;
						}
	
#if 1
					/*  syncronize time */
						if(misc_flags.sendtime )
						{
							misc_flags.sendtime = 0;
							sendinfo( 0x02,Station_NUM,ps );
							
							day = 0;
						}
						else if( day != ora_current.day )
					 	{
	            			day = ora_current.day;
							if(Station_NUM < ps->PTP_reception_state) /* OS - original station for RS485 */
							{
	 					   		sendinfo( 0x02,Station_NUM,ps );		
	/*
							sendinfoflag = 1;
							ps->PTP_connection_state|=SENDINFO_TIME;
							resume( CLIENT_TASK );
	*/
							}

					 	}
#endif 

						RemoveReceivedEntry( ps );
						
					 	ps->FrameCount = 0;
					 	ps->MSTP_MASTER_state = MSTP_MASTER_USE_TOKEN;
						break;
					}

					/*      ReceivedPollForMaster */
						if( rec_frame->Destination == Station_NUM && rec_frame->FrameType == PollForMaster )
						{
							source_panel = rec_frame->Source;
							RemoveReceivedEntry( ps );
							/*		ps->validint = 1;	*/
							Send_frame( NULL, ReplyToPollForMaster, source_panel, ps );
							ps->FirstToken = 0;
							ps->ack0received = 1;                    /* receivedpollformaster for RS485 */
							ps->nack0received = 0;                   /* panelOff for RS485 */
							
							break;
						}

						if(ps->ack0received==0)         /* receivedpollformaster for RS485 */
						{
						/* received frame before poll for master. There is another panel*/
						/* with the same panel number. The panel does not respond to the received token*/
						   	RemoveReceivedEntry( ps );
						
							break;
						}	

	
					/*      ReceivedDataNoReply   */
						if( ( rec_frame->Destination == Station_NUM || rec_frame->Destination == 255 ) &&
								( rec_frame->FrameType == BACnetDataNotExpectingReply ||rec_frame->FrameType == TestResponse))
								/* or a proprietary type known to this node which does not expect a reply */						
						{				
							/* 			 indicate the successful reception to the higher layer */
							NL_unitdata_ind( ps, rec_frame->Buffer, rec_frame->Length, rec_frame->Source );		
							RemoveReceivedEntry( ps );
							
							break;
						}
	
					/*          ReceivedDataNeedingReply */
						if( rec_frame->Destination == Station_NUM && (rec_frame->FrameType == BACnetDataExpectingReply ||rec_frame->FrameType == TestRequest ))
						 /* or a proprietary type known to this node which	expects a reply */
						{
							/* indicate the successful reception to the higher layer */					
							n = ps->InactivityTimer;
							NL_unitdata_ind( ps, rec_frame->Buffer, rec_frame->Length, rec_frame->Source );
							RemoveReceivedEntry( ps );			
							ps->MSTP_MASTER_state = MSTP_MASTER_ANSWER_DATA_REQUEST;
							break;						
						}
					
					}
					else
					{
						RemoveReceivedEntry( ps );
						break;
					}
				}	
				
			/*	if( ps->SilenceTimer < TNO_TOKEN - 1 )
				{
					vTaskDelay( TNO_TOKEN - ps->SilenceTimer );
				}
			*/	
	
				break;
	
			 case MSTP_MASTER_USE_TOKEN:
/*In the USE_TOKEN state, the node is allowed to send one or more data frames. These may be BACnet Data frames or proprietary frames.*/
				frame = SendFrameAvailable( ps->port, -1 );
				
				if( !frame )
				{
						/*  NothingToSend */
					if( TokenCount < NMAX_POLL && ps->SoleMaster == TRUE )
					{
						ps->FrameCount = 0;
						TokenCount = NMAX_POLL;
						ps->SoleMaster = FALSE;
						ps->SilenceTimer = 0;
						ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
					}
					else
					{
						ps->FrameCount = NMAX_INFO_FRAMES;
						ps->MSTP_MASTER_state = MSTP_MASTER_DONE_WITH_TOKEN;
					}
				 }
				 else
				 {
					/*         SendNoWait */
					if( frame->FrameType == TestResponse ||frame->FrameType == BACnetDataNotExpectingReply )
					{	/* or a proprietary type which does not expect a reply */
						 Send_frame( frame, frame->FrameType, frame->Destination, ps );
						 RemoveSentEntry( frame );
		/* wait to allow frame processing in the other panels*/
						// vTaskDelay(4);						 	
						 ps->FrameCount++;
					 	 ps->MSTP_MASTER_state = MSTP_MASTER_DONE_WITH_TOKEN;
					}
			        else
			        {
			/*         SendAndWait */
						if( frame->FrameType == TestRequest ||frame->FrameType == BACnetDataExpectingReply )						
						{/* or a proprietary type which expects a reply */	
							ps->EventCount = 0;
							Send_frame( frame, frame->FrameType, frame->Destination, ps );
							RemoveSentEntry( frame );
							ps->FrameCount++;
							ps->MSTP_MASTER_state = MSTP_MASTER_WAIT_FOR_REPLY;
							
						}
		        		else
						 	RemoveSentEntry( frame );
	       			}
				 }
				 break;

			 case MSTP_MASTER_WAIT_FOR_REPLY:
/* In the WAIT_FOR_REPLY state, the node waits for a reply from another node. */
					TimeOut=FALSE;
	/*				n = ps->EventCount;		*/
					if( !ReceiveFrameAvailable( ps ) )	vTaskDelay(TREPLY_TIMEOUT);
				
					if( !ReceiveFrameAvailable( ps ) )
					{
					 	if( ps->EventCount >= NMIN_OCTETS )
					 	{
						  	ps->EventCount = 0;
							if( TREPLY_TIMEOUT > ps->SilenceTimer )		 vTaskDelay((TREPLY_TIMEOUT-ps->SilenceTimer));
						  	if(!ReceiveFrameAvailable( ps ))
						  	{
								if( ps->EventCount >= NMIN_OCTETS )
								{
									ps->EventCount = 0;
									if( TREPLY_TIMEOUT > ps->SilenceTimer )
										  vTaskDelay((TREPLY_TIMEOUT - ps->SilenceTimer));
									if(!ReceiveFrameAvailable( ps ))
									{
									 	TimeOut=TRUE;
									}
								}
								else
								 	TimeOut=TRUE;
							}
						}
						else
						{
							Send_frame( NULL, -1, Station_NUM, ps ); /*pad same bytes to announce its presents*/
						//	vTaskDelay(5);        /* allow the requested panel to finish processing*/
							TimeOut=TRUE;
						}
					}					
			/*      ReplyTimeout 		*/
				 if(TimeOut/*ps->SilenceTimer >= TREPLY_TIMEOUT*/ )
				 {
						Send_frame( NULL, -1, Station_NUM, ps ); /*pad same bytes to announce its presents*/
						ps->FrameCount = NMAX_INFO_FRAMES;
						ps->MSTP_MASTER_state = MSTP_MASTER_DONE_WITH_TOKEN;
						break;
				 }

				 if( !TimeOut/* ps->SilenceTimer < TREPLY_TIMEOUT*/ )
				 {
	/*         InvalidFrame */
					if( ps->received_invalid_frame == TRUE )
					{
						 RemoveReceivedEntry( ps );
						 ps->MSTP_MASTER_state = MSTP_MASTER_DONE_WITH_TOKEN;
						 break;
					}
	/*         ReceivedReply */
					if( ps->received_valid_frame == TRUE && rec_frame->Destination == Station_NUM &&( rec_frame->FrameType == BACnetDataNotExpectingReply ||rec_frame->FrameType == TestResponse ))
					{	/* a proprietary type which indicates a reply */
	/*           indicate successful reception to the higher layer */
						NL_unitdata_ind( ps, rec_frame->Buffer, rec_frame->Length, rec_frame->Source );
						RemoveReceivedEntry( ps );
						ps->MSTP_MASTER_state = MSTP_MASTER_DONE_WITH_TOKEN;
					 	break;
					}
	/*         ReceivePostpone */
					if( ps->received_valid_frame == TRUE && rec_frame->Destination == Station_NUM &&rec_frame->FrameType == ReplyPostponed )
					{
						RemoveReceivedEntry( ps );
						ps->MSTP_MASTER_state = MSTP_MASTER_DONE_WITH_TOKEN;
						break;
					}
	/*         ReceivedUnexpectedFrame */	

					if( ps->received_valid_frame == TRUE &&
						( rec_frame->Destination != Station_NUM ||
							rec_frame->FrameType != BACnetDataNotExpectingReply ||
							rec_frame->FrameType != TestResponse )
							// or a proprietary reply frame
						)	
					
					{
					 RemoveReceivedEntry( ps );
					 ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
					 break;
					}
				 }
				 break;

			 case MSTP_MASTER_DONE_WITH_TOKEN:
/*	The DONE_WITH_TOKEN state either sends another data frame, passes the token, or initiates a Poll For Master cycle. */

	/*        SendAnotherFrame */
				 if( ps->FrameCount < NMAX_INFO_FRAMES )
				 {
					 ps->MSTP_MASTER_state = MSTP_MASTER_USE_TOKEN;
					 break;
				 }
				 else   //   if( ps->FrameCount >= NMAX_INFO_FRAMES )
				 {
	/*         SoleMaster */
					if( TokenCount < NMAX_POLL && ps->SoleMaster == TRUE )
					{
						ps->FrameCount = 0;
						TokenCount++;
						ps->MSTP_MASTER_state = MSTP_MASTER_USE_TOKEN;
						break;
					}
	/*         SendToken */
					if( (TokenCount < NMAX_POLL && ps->SoleMaster == FALSE ) ||( NS == ( (Station_NUM+1)%(NMAX_MASTER+1) ) ) )
					{								
						if( ps->InactivityTimer < 30 )  /* 150 milisec */
						{
						 	if( ps->UsedToken == FALSE )
						 	{
								/* pad same bytes to announce its presence */
					    		//for( n = 0; n < 0x2000; n++ );
								Send_frame( NULL, -1, Station_NUM, ps );
						 	}
						 	if( ps->InactivityTimer < 29 )
							{
						 		vTaskDelay( (29 - ps->InactivityTimer) );
							}
							
						}
						TokenCount++;
						ps->RetryCount = 0;
						ps->EventCount = 0;	
						Send_frame( NULL, Token, NS, ps );
						ps->MSTP_MASTER_state = MSTP_MASTER_PASS_TOKEN;
						break;
					}

			/* SendMaintanencePFM */
					if( TokenCount >= NMAX_POLL && NS != (PS+1)%(NMAX_MASTER+1) )
					{
						PS = (PS+1)%( NMAX_MASTER + 1 );
						/* PollForMaster to PS */
						Send_frame( NULL, PollForMaster, PS, ps );
						ps->RetryCount = 0;
						ps->MSTP_MASTER_state = MSTP_MASTER_POLL_FOR_MASTER;
						break;
					}
			/* ResetMaintenancePFM */
					if( TokenCount >= NMAX_POLL && NS == (PS+1)%(NMAX_MASTER+1) && ps->SoleMaster == FALSE )
					{
						PS = Station_NUM;
						/* Token to NS */
						ps->RetryCount = 0;
						TokenCount = 0;
						ps->EventCount = 0;
						Send_frame( NULL, Token, NS, ps );
						ps->MSTP_MASTER_state = MSTP_MASTER_PASS_TOKEN;
						break;
					}
					/* SoleMasterRestartMaintenancePFM */
				    if( TokenCount >= NMAX_POLL && TokenCount >= NMAX_POLL && NS == (PS+1)%(NMAX_MASTER+1) && ps->SoleMaster == TRUE)
					{
						PS = (NS + 1) % (NMAX_MASTER+1);
						Send_frame( NULL, PollForMaster, PS, ps );
						NS = Station_NUM;
						ps->RetryCount = 0;
						TokenCount = 0;
						ps->EventCount = 0;
						ps->MSTP_MASTER_state = MSTP_MASTER_POLL_FOR_MASTER;
					}

				 }
				 break;

			 case MSTP_MASTER_PASS_TOKEN:
				 ps->InactivityTimer = 0;
				 if( ps->EventCount < NMIN_OCTETS )		vTaskDelay( TUSAGE_TIMEOUT); 
				 /* SawTokenUser */
				 if( /*ps->SilenceTimer < TUSAGE_TIMEOUT &&*/  ps->EventCount > NMIN_OCTETS )
				 {
						ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
						break;
				 }
				 /* RetrySendToken */
				 if(/*ps->SilenceTimer >= TUSAGE_TIMEOUT &&*/ ps->RetryCount < NRETRY_TOKEN )
				 {
					ps->RetryCount++;
					/* Token to NS */
					ps->EventCount = 0;
					Send_frame( NULL, Token, NS, ps );
					break;
				 }
				 /* FindNewSuccessor */
				 if(/*ps->SilenceTimer >= TUSAGE_TIMEOUT &&*/ ps->RetryCount >= NRETRY_TOKEN )
				 {
					if( NS != Station_NUM )
					{
	 					sendinfo( OFF,NS,ps );
	/*  PTP_connection_state sendinfo_flag for RS485         */
	/*
						sendinfoflag = 1;
	          ps->nextpanelisoff = NS;
						ps->PTP_connection_state|=SENDINFO_PANELOFF;
		        resume( CLIENT_TASK );
	*/
					  	reset_active_panels( NS, ps );
	/*				 sendinfo( OFF, NS, 0x0FF, ps );*/
					}
	
					PS = (NS+1)%(NMAX_MASTER+1);
					/* PollForMaster to PS */
					ps->RetryCount = 0;
					TokenCount = 0;
					ps->EventCount = 0;
					Send_frame( NULL, PollForMaster, PS, ps );
					NS = Station_NUM;
		      		ps->PTP_transmission_state = Station_NUM;  /* NS - next station for RS485     */
					ps->MSTP_MASTER_state = MSTP_MASTER_POLL_FOR_MASTER;
					break;
				 }
				 break;

			 case MSTP_MASTER_NO_TOKEN:
				 /* SawFrame */
				 n = TNO_TOKEN + ( TSLOT * Station_NUM );
			
				 if( ( ps->SilenceTimer < n ) && ( ps->EventCount > NMIN_OCTETS ) )
				 {			
					ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
					break;
				 }
				 /* GenerateToken */
				 if( ( ps->SilenceTimer >= n ) && ( ps->SilenceTimer < ( n + TSLOT ) ) )
				 {
				
					PS = (Station_NUM+1)%(NMAX_MASTER+1);
					/* PollForMaster to PS */
					ps->RetryCount = 0;
					TokenCount = 0;
					ps->EventCount = 0;
					Send_frame( NULL, PollForMaster, PS, ps );
					NS = Station_NUM;
		      		ps->PTP_transmission_state=Station_NUM;  /* NS - next station for RS485     */
					ps->MSTP_MASTER_state = MSTP_MASTER_POLL_FOR_MASTER;
					break;
				 }
				 if( ps->SilenceTimer >= ( n + TSLOT ) )
				 {	
				
					ps->SilenceTimer=0;
					ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
					break;
				 }
				 break;
			 case MSTP_MASTER_POLL_FOR_MASTER:
				TimeOut=FALSE;
				if( !ReceiveFrameAvailable( ps ) )
					vTaskDelay( TUSAGE_TIMEOUT );  // modify delay by chelsea
				
				if( !ReceiveFrameAvailable( ps ) )
				{
					if( ps->EventCount >= NMIN_OCTETS )
					{
						vTaskDelay( TUSAGE_TIMEOUT);
						if( !ReceiveFrameAvailable( ps ) )
							TimeOut = TRUE;
					}
					else
						TimeOut = TRUE;
				
				}

				if( /*ps->SilenceTimer < TUSAGE_TIMEOUT */TimeOut != TRUE )
				{/* ReceivedReplyToPFM */
					if( ps->received_valid_frame == TRUE &&	rec_frame->Destination == Station_NUM && rec_frame->FrameType == ReplyToPollForMaster )
					{
					//	ps->SoleMaster = 0;  // add by chelsea
						NS = rec_frame->Source;
		        		ps->PTP_transmission_state = NS;  /* NS - next station for RS485     */
						RemoveReceivedEntry( ps );
						ps->EventCount = 0;
						/* Token to NS */
						Send_frame( NULL, Token, NS, ps );
						PS = Station_NUM;
						ps->RetryCount = 0;
						TokenCount = 0;
						ps->MSTP_MASTER_state = MSTP_MASTER_PASS_TOKEN;
						break;
					}
					/* ReceivedUnexpectedFrame  */
					if( ps->received_valid_frame == TRUE &&	(rec_frame->Destination != Station_NUM ||rec_frame->FrameType != ReplyToPollForMaster ) )
					{
						RemoveReceivedEntry( ps );
						ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
						break;
					}
				}

				if( ps->rec_frame_ready )
					RemoveReceivedEntry( ps );
	
					/* SoleMaster */
					if( ps->SoleMaster == TRUE && ( TimeOut/*ps->SilenceTimer >= TUSAGE_TIMEOUT*/ || ps->received_invalid_frame == TRUE) )
					{/*	received_invalid_frame = FALSE; */
						if( ps->rec_frame_ready == TRUE ) 	RemoveReceivedEntry( ps );
						ps->FrameCount=0;
						ps->MSTP_MASTER_state = MSTP_MASTER_USE_TOKEN;
						break;
					}
					/* DoneWithPFM */
					if( ps->SoleMaster == FALSE && NS != Station_NUM &&	( TimeOut/*ps->SilenceTimer >= TUSAGE_TIMEOUT*/  || ps->received_invalid_frame == TRUE ) )
					{/*				received_invalid_frame = FALSE; */
						if( ps->rec_frame_ready == TRUE ) 	RemoveReceivedEntry( ps );            
						ps->EventCount = 0;
						/* Token to NS */
						Send_frame( NULL, Token, NS, ps );
						ps->RetryCount = 0;
						ps->MSTP_MASTER_state = MSTP_MASTER_PASS_TOKEN;
						break;
					}
	/*         SendNextPFM */
					if( ps->SoleMaster == FALSE && NS==Station_NUM &&( Station_NUM != (( PS+1 ) % ( NMAX_MASTER+1 ) ) ) &&	( TimeOut/*ps->SilenceTimer >= TUSAGE_TIMEOUT*/  || ps->received_invalid_frame == TRUE ) )
					{/*		received_invalid_frame = FALSE; */
						if( ps->rec_frame_ready == TRUE ) 			RemoveReceivedEntry( ps );         
						PS = (PS + 1) % (NMAX_MASTER + 1);
						/* PollForMaster to PS */
						ps->EventCount = 0;     /*Add Dec 1997*/
						Send_frame( NULL, PollForMaster, PS, ps );
						ps->RetryCount = 0;
						break;
					}
	/*         DeclareSoleMaster */
					if( ps->SoleMaster == FALSE && NS == Station_NUM &&	( Station_NUM==(PS+1) % (NMAX_MASTER+1) ) &&( TimeOut/*ps->SilenceTimer >= TUSAGE_TIMEOUT*/  || ps->received_invalid_frame == TRUE ) )
					{	/*				received_invalid_frame = FALSE; */
						if( ps->received_invalid_frame == TRUE )
							RemoveReceivedEntry( ps );
						ps->SoleMaster = TRUE;
						ps->FrameCount = 0;
						ps->MSTP_MASTER_state = MSTP_MASTER_USE_TOKEN;
						//panelconnected=2;
						break;
					}
					ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;   // maybe delete ????????????
					break;
			 case MSTP_MASTER_ANSWER_DATA_REQUEST:
				frame = SendFrameAvailable( ps->port, 1 );
				if( frame )
				{
					if( ps->InactivityTimer - n <= TREPLY_DELAY )
					{						
						Send_frame( frame, frame->FrameType, frame->Destination, ps );
						RemoveSentEntry( frame );
					}
					else
					{	
	          			/*SetByteBit(&frame->flag,0,3,1);*/frame->reply_flag = 0;
					}
				}
				flag_test = 1;
				ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
		 	    //break;  //???????????????????
		 }
		
		}	
	}
//	flag_Ready = 0;
//	suspend( ps->base_task ); 	
}


#endif
