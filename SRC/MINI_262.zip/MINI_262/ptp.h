#include "types.h"

U16_T CalcBlockDataCRC( U8_T *, U16_T length,U16_T crcValue );//KR new code
S16_T Calc_CRC_and_toggle_activity_light( U8_T *addr, S32_T length, S16_T CRC );
S16_T ReceiveFrameAvailable( Protocol_parameters *ps );
void RemoveReceivedEntry( Protocol_parameters *ps );
FRAME_ENTRY *SendFreeEntry( S16_T port, S16_T reply );
FRAME_ENTRY *SendFrameAvailable( S16_T port, S16_T reply );
void RemoveSentEntry( FRAME_ENTRY *frame_ptr );
void Send_frame( FRAME_ENTRY *frame, S16_T frame_type, S16_T dest,Protocol_parameters *ps );
S16_T send_octet( S16_T octet, U8_T **buffer, S16_T link_type );

void PTP_connection_sm(void );
void PTP_reception_sm(void );
void PTP_transmission_sm(void );
