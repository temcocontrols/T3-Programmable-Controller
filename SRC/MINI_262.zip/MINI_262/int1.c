#include "main.h"

void handle_PTP_RX( void );
void handle_MSTP_RX( U8_T temp  );
void handle_Modbus_RX0(void);
void handle_Modbus_RX1(void);

bit transmit_finished = 1;
U8_T far data_buffer[1000]; // should be 511 real data, some data is 0x90 + real data
U16_T far rece_count = 0;
U16_T far packet_size = 0;				 



void Handle_MSTP_Task(void) reentrant;


bit flag_int;

U8_T MstpDataReady;
U8_T flag_Ready;
//extern U8_T Test[4];

#define MSTPRev_STACK_SIZE				( ( unsigned portSHORT ) 256 )


xQueueHandle	xReadyQueue; /* trasmit data from comm to interupt */
xTaskHandle far Handle_MSTPRev;


extern U8_T port; // Serial port 0 / 1


extern U8_T far flag_uart;
extern bit flagLED_232;
extern bit flagLED_485;
extern U8_T far CommCount;

U8_T tempSBUF;

#if 1
static void UART0_ISR(void) interrupt 4
{

	flag_uart = UART0;
	if (RI0)
	{
	
		EA = 0;
		//flag_int = 1;
	 	
		/* refresh commnicaiton status LED */
		flag_uart = UART0;
		flagLED_232 = 1;flagLED_485 = 0;
		CommCount = 0;

		
		if(Modbus.PROTOCAL == MODBUS)	
			handle_Modbus_RX0();
		#ifdef BACNET
		else if(Modbus.PROTOCAL == BACNET_MSTP)
		{
			tempSBUF = SBUF0;
			/*xTaskWokenByPost = */
			cQueueSendFromISR( xReadyQueue, &tempSBUF,  0);
			/*if( xTaskWokenByPost == pdPASS )
			{				
				MstpDataReady = 1;				
				//handle_MSTP_RX(temp);
			}*/			
		}	
		else if(Modbus.PROTOCAL == BACNET_PTP)
			handle_PTP_RX();		
		#endif

		//flag_int = 0;
		RI0 = 0;
		EA = 1;
		
	
	} 
	else if (TI0)
	{
		EA = 0;
		TI0 = 0;
		transmit_finished = 1;
		EA = 1;	
	} 
}
#endif


#if 1
static void UART1_ISR(void) interrupt 6
{
	flag_uart = UART1;
	if (RI1)
	{
		EA = 0;
		
	/* refresh commnicaiton status LED */
		flag_uart = UART1;
		flagLED_232 = 0;flagLED_485 = 1;
		CommCount = 0;

		
		if(Modbus.PROTOCAL == MODBUS)
			handle_Modbus_RX1();
		
	//	flag_int = 0;
		RI1 = 0;
		EA = 1;
	
	} 
	else if (TI1)
	{
		EA = 0;
		TI1 = 0;
		transmit_finished = 1;
		EA = 1;	
	} 	
}
#endif

#ifdef BACNET

#define Max_LEN 1000//512

//U8_T flag_MSTP = 0;

U8_T flag_MSTP = 0;

void vStartHandleMstpTasks( unsigned char uxPriority)
{

	sTaskCreate( Handle_MSTP_Task, "mstprevtask", MSTPRev_STACK_SIZE, NULL, uxPriority, &Handle_MSTPRev );
	xReadyQueue = xQueueCreate(10,sizeof(U8_T));
	
}



void print_dat(U16_T dat)
{
	if(dat > 9999)	
	{
		uart1_PutChar(dat / 10000 + 0x30);
		uart1_PutChar(dat % 10000 / 1000 + 0x30);
		uart1_PutChar(dat % 1000 / 100 + 0x30);
		uart1_PutChar(dat % 100 / 10 + 0x30);
		uart1_PutChar(dat % 10 + 0x30);
	}
	else if(dat >= 1000)
	{
		uart1_PutChar(dat / 1000 + 0x30);
		uart1_PutChar(dat % 1000 / 100 + 0x30);
		uart1_PutChar(dat % 100 / 10 + 0x30);
		uart1_PutChar(dat % 10 + 0x30);
	}
	else if(dat >= 100)
	{
		uart1_PutChar(dat / 100 + 0x30);
		uart1_PutChar(dat % 100 / 10 + 0x30);
		uart1_PutChar(dat % 10 + 0x30);
	}
	else if(dat >= 10)
	{		
		uart1_PutChar(dat / 10 + 0x30);
		uart1_PutChar(dat % 10 + 0x30);
	}
	else
	{
		uart1_PutChar(dat + 0x30);
	}
}




void reset_active_panels( S16_T n, Protocol_parameters *ps )
{
	if( n > 32 )	return;
	ps->need_info &= ~( 1L << ( n - 1 ) );
	if( n < 9 )
		panel_net_info.active_panels[0] &= ~active_panel[n-1];
	else if( n < 17 )
		panel_net_info.active_panels[1] &= ~active_panel[n-9];
	else if( n < 25 )
		panel_net_info.active_panels[2] &= ~active_panel[n-17];
	else if( n < 33 )
		panel_net_info.active_panels[3] &= ~active_panel[n-25];

	memset(&station_list[n-1],0,sizeof(Station_point));
/*
	station_list[n-1].state = 0;
	station_list[n-1].des_length = 0;
	station_list[n-1].panel_type = 0;
	station_list[n-1].version=0;
*/
}


void init_active_panels( void )
{
	memset( panel_net_info.active_panels, 0 , 4 );
	
/*  set_active_panel( Station_NUM );*/
	if( Station_NUM < 9 )
		panel_net_info.active_panels[0] |= active_panel[Station_NUM-1];
	else if( Station_NUM < 17 )
		panel_net_info.active_panels[1] |= active_panel[Station_NUM-9];
	else if( Station_NUM < 25 )
		panel_net_info.active_panels[2] |= active_panel[Station_NUM-17];
	else
		panel_net_info.active_panels[3] |= active_panel[Station_NUM-25];

	
	memset( station_list, 0 , sizeof(station_list));
 	strcpy(station_list[Station_NUM-1].name,panel_net_info.panel_name);
  	station_list[Station_NUM-1].state = 1;
	station_list[Station_NUM-1].panel_type = MINI_T3000;
  	station_list[Station_NUM-1].des_length = panel_net_info.desc_length;
  //	station_list[Station_NUM-1].version = panel_net_info.version_number;
  	memcpy( station_list[Station_NUM-1].tbl_bank,table_bank,TABLE_BANK_LENGTH);
//	panel_net_info.active_panels[0] = 0x04;
}


void init_communication_structures( void )
{
	int i;
	Protocol_parameters *ptr;
  	FRAME_ENTRY *pframe;

  /* check for  comm_info's integrity  */
	if(comm_info[0].media_type != RS485_LINK && comm_info[0].media_type != SERIAL_LINK && comm_info[1].media_type != RS485_LINK && comm_info[1].media_type != SERIAL_LINK )
  	{
  		comm_info[0].media_type = RS485_LINK;
		comm_info[0].baudrate = 19200;
  	}
/*	switch( comm_info[0].baudrate )
	{
		case   300:
		case  1200:
		case  2400:
		case  4800:
		case  9600:
		case 19200:
		case 38400:
		case 57600:		break;
		default:
		  comm_info[0].baudrate = 19200;
	}
	switch( comm_info[1].baudrate )
	{
	case   300:
	case  1200:
	case  2400:
	case  4800:
	case  9600:
	case 19200:
	case 38400:
	case 57600:		break;
	default:
			comm_info[1].baudrate = 19200;
	}
*/


	if(Modbus.PROTOCAL == BACNET_MSTP)
	{
		comm_info[0].media_type = RS485_LINK;   // FOR BACNET-MSTP
	}

	if(Modbus.PROTOCAL == BACNET_PTP)
		comm_info[0].media_type = SERIAL_LINK;   // FOR BACNET-PTP

	Test[14] = Modbus.PROTOCAL;	
	memset( SendFrame, 0, sizeof( FRAME_ENTRY )* MAX_SEND_FRAMES );
	pframe=SendFrame;
	for( i=0; i<MAX_SEND_FRAMES; i++, pframe++ )
	pframe->number = i;
//	SetByteBit(&pframe->flag,0,4,2);
// 	Using_send_frame = 0;

//	set_baudrate( 0 );
//	set_baudrate( 1 );

	memset( Routing_table, '\x0', MAX_Routing_table*sizeof( Routing_Table ) );
	memset( NL_PARAMETERS, '\x0', 2*sizeof( UNITDATA_PARAMETERS ) );
	NL_PARAMETERS[0].primitive = DL_INVALID;
	NL_PARAMETERS[1].primitive = DL_INVALID;

	memset( Port_parameters, '\x0', 2*sizeof( Protocol_parameters ) );

	ptr = &Port_parameters[0];

	for( i=0; i<2; i++, ptr++ )
	{
		ptr->port = i;

		if( comm_info[i].media_type == RS485_LINK )
		{
			ptr->link_type = RS485_LINK;
		}
		else
		{
			ptr->link_type = SERIAL_LINK;
     	}

		if( !i )
				ptr->rec_frame = &ReceiveFrame_0;
		else
				ptr->rec_frame = &ReceiveFrame_1;

		ptr->tx_end = 1;
		ptr->tx_wake_up = 0x0ff;

		ptr->PTP_DLE_mask = 0x0FF;
		ptr->reception_blocked = Q_NOT_BLOCKED;
		ptr->receive_frame_free = 1;
		ptr->send_frame_free = 1;
		ptr->transmission_blocked = 1;

		ptr->PTP_transmission_state = TR_IDLE;
		ptr->PTP_reception_state = REC_IDLE;
		ptr->PTP_connection_state = DISCONNECTED; 		
		ptr->Rec_frame_state = RX_IDLE;
		ptr->rec_trigger_sequence = 0;
		ptr->MSTP_MASTER_state = MSTP_MASTER_IDLE;
	}
	password_needed = 0;

	/* add initial infomation by chelsea */
	Station_NUM = 2;
	panel_net_info.panel_type = MINI_T3000;
	panel_net_info.network_number = 9999;
	panel_net_info.network_number = mGetPointWord2(panel_net_info.network_number); // add by chelsea 
	panel_net_info.panel_number = Station_NUM;
    panel_net_info.version_number = 260;    // add by chelsea 
	strcpy( panel_net_info.network_name, "MINI PANEL" );
	strcpy( panel_net_info.panel_name, "T3000 Mini" );
	memcpy( default_panel, "MINI0000.PRG", 13 );

	//MstpDataReady = xQueueCreate(5,sizeof(U8_T));
	
}



void Send_Buffer(U8_T *buffer,S16_T length, U8_T port)
{
	U16_T i;
	U8_T test;
	
	if(port == 0)	
	{		
		for(i = 0;i < length;i++)
		{	
		
			transmit_finished = 0;						
			//if(Modbus.PROTOCAL == BACNET_PTP)	
				SBUF0 = *(buffer++);
			//else 	
			//	SBUF1 = *(buffer++);	
			while (!transmit_finished){}
				
		}		
	}
}





void PTP_rx_err( void )
{
	Protocol_parameters *ps;

	if( !port )
	{
		ps = Port_parameters;
	}
	else
	{
		ps = &Port_parameters[1];
	}

	ps->SilenceTimer = 0;

 	if( ps->Rec_frame_state == RX_DATA )
	{
		ps->received_invalid_frame = 1;
		ps->rec_frame_ready = 1;
		ps->reception_blocked = Q_BLOCKED;
		ps->receive_frame_free = 0;
	 
  	}
	ps->Rec_frame_state = RX_IDLE;
} /* 	retcs !_handle_PTP_rx_err_interrupt */


/*
Frame Receive State Machine : 
	IDLE, 		PREMABLE , 		(HEADER, HEADERCRC),		( DATA,DATACRC)	--	Standard Frame Receive State Machine
	RX_IDLE,	RX_PREAMBLE,		RX_HEADER,					RX_DATA		--	following code
*/

void handle_PTP_RX( void )
{
	register Protocol_parameters *ps;
	static char tttt = 0;
	if( !port )
	{
		ps = Port_parameters;
	}
	else
	{
		ps = &Port_parameters[1];
	}

 	ps->Rx_work_byte = SBUF0;
	//RI0 = 0;

//	print_dat(ps->Rx_work_byte);		
 	if( ps->Rx_work_byte != 0x11 && ps->Rx_work_byte != 0x13 )
 	{
		if( ps->Rx_work_byte != 0x10 )  /* DLE received */
		{
			ps->Rx_work_byte &= ps->PTP_DLE_mask;
			ps->PTP_DLE_mask = 0x0FF;
			if( ps->PTP_connection_state != DISCONNECTED )
			{
	
				switch( ps->Rec_frame_state )
				{
					case RX_DATA:
					if( ps->SilenceTimer > T_FRAME_ABORT )
					{
						ps->received_invalid_frame = 1;
						ps->rec_frame_ready = 1;
						ps->reception_blocked = Q_BLOCKED;
						ps->receive_frame_free = 0;
						ps->Rec_frame_state = RX_IDLE;
						break;
					}

					ps->DataCRC = ( ps->DataCRC >> 8 ) ^
									crc16_table[ ( ps->DataCRC & 0x0ff ) ^ ps->Rx_work_byte ]; 
/*	movw	ax, [vp+27]     ; ax <- DataCRC
					xor		b, b    				; b <- 0
					mov		c, a    				; bc <- DataCRC >> 8
					mov		d, b    				; d <- 0
					mov		e, x    				; de <- DataCRC & 0x0ff
					mov		a, [vp+31]      ; a <- Rx_work_byte
					xor		e, a    				; de <- ( DataCRC & 0x0ff ) ^ Rx_work_byte
					addw	de, de
					movw	ax, _crc16_table[de]
					xor		x, c
					movw	[vp+27], ax     ; DataCRC <- ax*/
				

					if( ps->Index < ps->Length )
					{
						*ps->DataBuffer = ps->Rx_work_byte;
						ps->DataBuffer++;
						ps->Index++;
						break;
					} 
					else if( ps->Index == ps->Length )
					{
						ps->Index++;
						break;
					}
					else
					{
						if( ps->DataCRC != 0x0f0b8 )
						{
							ps->received_invalid_frame = 1;
						}
						else
						{
							ps->received_valid_frame = 1;
						}
						ps->rec_frame_ready = 1;
						ps->reception_blocked = Q_BLOCKED;
						ps->receive_frame_free = 0;
						ps->Rec_frame_state = RX_IDLE;
					//	tasks[ ps->base_task + PTP_RECEPTION ].status = READY;
						break;
					}
					break;
				case RX_IDLE:
					if( ps->Rx_work_byte == 0x55 )
					{
						ps->Rec_frame_state = RX_PREAMBLE;
					}
					else
						ps->Rec_frame_state = RX_IDLE;
					break;
				case RX_PREAMBLE:
					if( ps->SilenceTimer > T_FRAME_ABORT )
					{
						ps->Rec_frame_state = RX_IDLE;
						break;
					}
					if( ps->Rx_work_byte == 0x55 )
					{
						break;
					}
					if( ps->Rx_work_byte == 0x0ff )
					{
						ps->HeaderCRC = 0x0ff;
						ps->Length = 0;
						ps->Index = 0;
						ps->PTP_DLE_mask = 0x0FF;
						ps->Rec_frame_state = RX_HEADER;
					}
					else
					{
						ps->Rec_frame_state = RX_IDLE;
					}
					break;
				case RX_HEADER:
					if( ps->SilenceTimer > T_FRAME_ABORT )
					{
						ps->Rec_frame_state = RX_IDLE;
						break;
					}
					ps->HeaderCRC = crc8_table[ ps->Rx_work_byte ^ ps->HeaderCRC ];
				/*
					ps->DataCRC = ( ps->DataCRC >> 8 ) ^
									crc16_table[ ( ps->DataCRC & 0x0ff ) ^ ps->Rx_work_byte ]; 
					#asm
						mov		a,[vp+31]    			; ps->Rx_work_byte
						xch		a,x
						mov		a,[vp+25]    			; ps->HeaderCRC
						xor		a,x          			; ps->Rx_work_byte ^ ps->HeaderCRC
						movg	tde, #_crc8_table
						mov		a, [de+a]    			; crc8_table[ps->Rx_work_byte^ps->HeaderCRC]
						mov		[vp+25], a
					#endasm*/
					switch( ps->Index )
					{
						case 0:
							ps->FrameType = ps->Rx_work_byte;
							ps->Index++;
							break;
						case 1:
							ps->Length = ps->Rx_work_byte;
							ps->Length <<= 8;
							ps->Index++;
							break;
						case 2:
							ps->Length += ps->Rx_work_byte;
							ps->Index++;
							break;
						case 3:
							if( ps->HeaderCRC != 0x55 )
							{
	/*
								ps->received_invalid_frame = 1;
								ps->rec_frame_ready = 1;
								ps->receive_frame_free = 0;
	*/
								ps->Rec_frame_state = RX_IDLE;
	/*
								if( ps->PTP_connection_state != CONNECTED )
								{
									tasks[ ps->base_task + PTP_CONNECTION ].status = READY;
								}
								else
								{
									tasks[ ps->base_task + PTP_RECEPTION ].status = READY;
								}
	*/
								break;
							}
							if( ps->Length < MAXFRAMEBUFFER )
							{
								if( ps->FrameType == HEARTBEAT_XOFF )
								{
										ps->transmission_blocked = 1;
										ps->InactivityTimer = 0;
								//		tasks[ ps->base_task + PTP_TRANSMISSION ].status = READY;
										ps->Rec_frame_state = RX_IDLE;
										break;
								}
								if( ps->FrameType == HEARTBEAT_XON )
								{
										ps->transmission_blocked = 0;
										ps->InactivityTimer = 0;
								//		tasks[ ps->base_task + PTP_TRANSMISSION ].status = READY;
										ps->Rec_frame_state = RX_IDLE;
										break;
								}
								if( ps->FrameType >= DATA_ACK_0_XOFF &&	ps->FrameType <= DATA_NAK_1_XON )
								{
									switch( ps->FrameType )
									{
									case DATA_ACK_0_XOFF:
										if( ps->TxSequence_number == 0 )
										{			/*	Ack0 XOFF	*/
											ps->ack0received = 1;
											ps->transmission_blocked = 1;
										}
										else
										{
											/*	Duplicate XOFF	*/
											ps->transmission_blocked = 1;
										}
										break;
									case DATA_ACK_1_XOFF:
										if( ps->TxSequence_number == 1 )
										{			/*	Ack1 XOFF	*/
											ps->ack1received = 1;
											ps->transmission_blocked = 1;
										}
										else
										{
											/*	Duplicate XOFF	*/
											ps->transmission_blocked = 1;
										}
										break;
									case DATA_ACK_0_XON:
										if( ps->TxSequence_number == 0 )
										{			/*	Ack0 XON	*/
											ps->ack0received = 1;
											ps->transmission_blocked = 0;
										}
										else
										{
											/*	Duplicate XON	*/
											ps->transmission_blocked = 0;
										}
										break;
									case DATA_ACK_1_XON:
										if( ps->TxSequence_number == 1 )
										{			/*	Ack1 XON	*/
											ps->ack1received = 1;
											ps->transmission_blocked = 0;
										}
										else
										{
											/*	Duplicate XON	*/
											ps->transmission_blocked = 0;
										}
										break;
									case DATA_NAK_0_XOFF:
										if( ps->TxSequence_number == 0 )
										{    	/*	Nack0 XOFF	*/
											ps->nack0received = 1;
											ps->transmission_blocked = 1;
										}
										else
										{
											/*	Duplicate XOFF	*/
											ps->transmission_blocked = 1;
										}
										break;
									case DATA_NAK_1_XOFF:
										if( ps->TxSequence_number == 1 )
										{    	/*	Nack0 XOFF	*/
											ps->nack1received = 1;
											ps->transmission_blocked = 1;
										}
										else
										{
											/*	Duplicate XOFF	*/
											ps->transmission_blocked = 1;
										}
										break;
									case DATA_NAK_0_XON:
										if( ps->TxSequence_number == 0 )
										{      /*	Nack0 XON	*/
											ps->nack0received = 1;
											ps->transmission_blocked = 0;
										}
										else
										{
											/*	Duplicate XON	*/
											ps->transmission_blocked = 0;
										}
										break;
									case DATA_NAK_1_XON:
										if( ps->TxSequence_number == 1 )
										{			/*	Nack1 XON	*/
											ps->nack1received = 1;
											ps->transmission_blocked = 0;
										}
										else
										{
											/*	Duplicate XON	*/
											ps->transmission_blocked = 0;
										}
										break;
									}
									ps->InactivityTimer = 0;
									ps->Rec_frame_state = RX_IDLE;
								//	tasks[ ps->base_task + PTP_TRANSMISSION ].status = READY;
									break;
								}
								else
								{
									if( ps->receive_frame_free )
									{
	/*									ps->receive_frame_free = 0;*/
	/*									ps->reception_blocked = Q_BLOCKED;*/
	/*
										if( ps->port )
											ps->rec_frame = &ReceiveFrame_1;
										else
											ps->rec_frame = &ReceiveFrame_0;
	*/
										ps->rec_frame->FrameType = ps->FrameType;
										ps->rec_frame->Length = ps->Length;
										if( ps->Length )
										{
											ps->DataCRC = 0x0ffff;
											ps->Index = 0;
											ps->DataBuffer = ps->rec_frame->Buffer;
											ps->Rec_frame_state = RX_DATA;
											
												
											break;
										}
										else
										{
											ps->received_valid_frame = 1;
	  										ps->rec_frame_ready = 1;
											ps->reception_blocked = Q_BLOCKED;
											ps->receive_frame_free = 0;
											ps->Rec_frame_state = RX_IDLE;
						        /*  if( ps->FrameType <= DISCONNECT_RESPONSE && ps->FrameType >= CONNECT_REQUEST )
												tasks[ ps->base_task + PTP_CONNECTION ].status = READY;
	                    			else if( ps->PTP_connection_state == CONNECTED )
											  {
												  tasks[ ps->base_task + PTP_RECEPTION ].status = READY;
											  }*/
											break;
										}
									}
/*
									else
									{
										ps->Rec_frame_state = RX_IDLE;
										ps->received_invalid_frame = 1;
										ps->rec_frame_ready = 1;
										if( ps->PTP_connection_state == CONNECTED )
										{
											tasks[ ps->base_task + PTP_RECEPTION ].status = READY;
										}
										else
										{
											tasks[ ps->base_task + PTP_CONNECTION ].status = READY;
										}
										break;
									}
*/
								}
								ps->Rec_frame_state = RX_IDLE;
								break;
							}
							else
							{
								if( ps->receive_frame_free )
								{
									ps->received_invalid_frame = 1;
									ps->rec_frame_ready = 1;
									ps->reception_blocked = Q_BLOCKED;
									ps->receive_frame_free = 0;
								//	tasks[ ps->base_task + PTP_RECEPTION ].status = READY;
	              				}
								ps->Rec_frame_state = RX_IDLE;
							}
							break;
						}
						break;
					}
				}
				else
				{
					/*Test[20 + tttt] = ps->Rx_work_byte;
					tttt++;
					if(tttt == 8) tttt = 0;					
					Test[10 + tttt] = trigger_sequence[tttt];
					Test[18] = ps->rec_trigger_sequence;*/
					if( ps->Rx_work_byte == trigger_sequence[ps->rec_trigger_sequence] )
					{ 					   	
						ps->rec_trigger_sequence++;
					}
					else
						ps->rec_trigger_sequence = 0;
				//	if( ps->rec_trigger_sequence >= 7 )
					//	tasks[ ps->base_task + PTP_CONNECTION ].status = READY;
				}
			}
			else
				ps->PTP_DLE_mask = 0x7F;
		}
	 	ps->SilenceTimer = 0;
} /* 	retcs !_handle_PTP_rx_interrupt */



void MSTP_rx_err( void )
{
	Protocol_parameters *ps;

	if( !port )
	{
		ps = Port_parameters;
	}
	else
	{
		ps = &Port_parameters[1];
	}

	ps->EventCount++;
	ps->SilenceTimer = 0;
 	if( ps->Rec_frame_state == RX_DATA )
	{
		ps->received_invalid_frame = 1;
		ps->rec_frame_ready = 1;
		ps->receive_frame_free = 0;
		//tasks[ ps->base_task ].status = READY;
		flag_Ready = 1;
	}

	ps->Rec_frame_state = RX_IDLE;

}  /* 	retcs !_handle_MSTP_rx_err_interrupt */



U8_T temp1 = 0;
U8_T temp2 = 0;
void handle_MSTP_RX( U8_T temp )
{
	bit f_error = 0;
	Protocol_parameters *ps;
	//if( !port )
	{
		ps = Port_parameters;
	}
	/*else
	{
		ps = &Port_parameters[1];
	}*/
	
 	ps->Rx_work_byte = temp;
	//RI0 = 0;
	
	ps->EventCount++;

	if( !ps->receive_frame_free ) return;

	if( ps->receive_frame_free )
	if( ps->SilenceTimer > TFRAME_ABORT )
	{
 		if( ps->Rec_frame_state == RX_DATA )
		{
			ps->received_invalid_frame = 1;
			ps->rec_frame_ready = 1;
			ps->receive_frame_free = 0;
		//	tasks[ ps->base_task ].status = READY;
			flag_Ready = 1;
		}

		ps->Rec_frame_state = RX_IDLE;
		
	}
	ps->SilenceTimer = 0;
#if 1
	if( ps->Rec_frame_state ==  RX_IDLE)
	{
 	
		//	Test[20] = ps->Rx_work_byte;
	 		if( ps->Rx_work_byte == 0x55 )
				ps->Rec_frame_state = RX_PREAMBLE;
			else
				ps->Rec_frame_state = RX_IDLE;
			return;
	}
	if( ps->Rec_frame_state ==  RX_PREAMBLE)
	{ 
		//	Test[21] = ps->Rx_work_byte;
	 		if( ps->Rx_work_byte == 0x55 )				return;
			if( ps->Rx_work_byte == 0x0ff )
			{
				ps->HeaderCRC = 0x0ff;
				ps->Length = 0;
				ps->Index = 0;
				ps->Rec_frame_state = RX_HEADER;
				return;
			}
			else
				ps->Rec_frame_state = RX_IDLE;
			return;
	}
	if( ps->Rec_frame_state ==  RX_HEADER)
	{ 	
		//	Test[ps->Index + 22] = ps->Rx_work_byte;
			ps->HeaderCRC = crc8_table[ ps->Rx_work_byte ^ ps->HeaderCRC ];
			//ps->HeaderCRC = 0x55;
	/*	#asm
					movw	ax, [vp+27]     ; ax <- DataCRC
					xor		b, b    				; b <- 0
					mov		c, a    				; bc <- DataCRC >> 8
					mov		d, b    				; d <- 0
					mov		e, x    				; de <- DataCRC & 0x0ff
					mov		a, [vp+31]      ; a <- Rx_work_byte
					xor		e, a    				; de <- ( DataCRC & 0x0ff ) ^ Rx_work_byte
					addw	de, de
					movw	ax, _crc16_table[de]
					xor		x, c
					movw	[vp+27], ax     ; DataCRC <- ax
				#endasm*/
		
			ps->Index++;
			if( ps->Index - 1 ==  0)
			{
					if( ps->receive_frame_free )
					{
						ps->FrameType = ps->Rx_work_byte;
						return;
					}
					ps->Rec_frame_state = RX_IDLE;
					return;
			}
			if( ps->Index - 1 ==  1)
			{
					ps->rec_frame->Destination = ps->Rx_work_byte;
 					ps->Destination = ps->Rx_work_byte;
					return;
			}
			if( ps->Index - 1 ==  2)
			{
					ps->rec_frame->Source = ps->Rx_work_byte;
					ps->Source = ps->Rx_work_byte;
					return;
			}
			if( ps->Index - 1 ==  3)
			{
					ps->Length = ps->Rx_work_byte;
					ps->Length <<= 8;
					ps->rec_frame->Length = ps->Rx_work_byte;
					ps->Length = ps->Rx_work_byte;
					ps->Length <<= 8;	
					return;
			}
			if( ps->Index - 1 ==  4)
			{
					ps->Length += ps->Rx_work_byte;
					ps->rec_frame->Length = ps->Length;
					return;
			}
			if( ps->Index - 1 ==  5)			
			{				
					if( ps->HeaderCRC != 0x55 )
					{
	 					ps->Rec_frame_state = RX_IDLE;
						Test[41]++;
	 					return;
					}
				
					/* At this point the CRC is OK so I can continue processing the frame */
	 				if( ps->FrameType == Token )
					{
	 					if( ps->Source < 9 )
							panel_net_info.active_panels[0] |= active_panel[ps->Source-1];
						else if( ps->Source < 17 )
							panel_net_info.active_panels[1] |= active_panel[ps->Source-9];
						else if( ps->Source < 25 )
							panel_net_info.active_panels[2] |= active_panel[ps->Source-17];
						else if( ps->Source < 32 )
							panel_net_info.active_panels[3] |= active_panel[ps->Source-25];
					}
			/* If the frame is not addressed to this panel or not a broadcast we can discard it   */
					if( ps->Destination != Station_NUM && ps->Destination != 0x0FF )
					{
						ps->Rec_frame_state = RX_IDLE;
						return;
	 				}
					if( ps->receive_frame_free )
					{
						if( ps->Length < MAXFRAMEBUFFER )
						{
							if( ps->port )
								ps->rec_frame = &ReceiveFrame_1;
							else
								ps->rec_frame = &ReceiveFrame_0;
		
							ps->rec_frame->Destination = ps->Destination;
							ps->rec_frame->Source = ps->Source;
							ps->rec_frame->FrameType = ps->FrameType;
							ps->rec_frame->Length = ps->Length;
		
							if( ps->Length )
							{
								ps->DataCRC = 0x0ffff;
								ps->Index = 0;
								ps->DataBuffer = ps->rec_frame->Buffer;
								ps->Rec_frame_state = RX_DATA;
								return;
							}
							else
							{
								ps->received_valid_frame = 1;
								ps->rec_frame_ready = 1;
							  	ps->receive_frame_free = 0;
								ps->Rec_frame_state = RX_IDLE;
								//tasks[ ps->base_task ].status = READY;
								flag_Ready = 1;
								return;
							}
						}
						else
						{
							ps->received_invalid_frame = 1;
							ps->rec_frame_ready = 1;
							ps->receive_frame_free = 0;
							ps->Rec_frame_state = RX_IDLE;
						//	tasks[ ps->base_task ].status = READY;
							flag_Ready = 1;
							return;
						}
					}
					else
			        {
						return;
					}
				
			}
			return;
	}
	if( ps->Rec_frame_state ==  RX_DATA) 
	{
			ps->DataCRC = ( ps->DataCRC >> 8 )^crc16_table[ ( ps->DataCRC & 0x0ff ) ^ ps->Rx_work_byte ];
			
			//Test[ps->Index + 28] = ps->Rx_work_byte;
			
			
			if( ps->Index < ps->Length )
			{
				*ps->DataBuffer = ps->Rx_work_byte;
		       	ps->DataBuffer++;
				ps->Index++;
				return;
			}
			if( ps->Index == ps->Length )
			{
				ps->Index++;
				return;
			}
			else
			{
				if( ps->DataCRC != 0x0f0b8 )
				{
					ps->received_invalid_frame = 1;
					ps->rec_frame_ready = 1;
				//	uart1_PutChar('Y'); 
					Test[40]++;
				}
				else
				{
					ps->received_valid_frame = 1;
					ps->rec_frame_ready = 1;
				}
				ps->receive_frame_free = 0;
				ps->Rec_frame_state = RX_IDLE;
			//	tasks[ ps->base_task ].status = READY;
				flag_Ready = 1;
			}

			return;
	}
	
#endif	
		

}  /* 	retcs !_handle_MSTP_rx_interrupt */




void Handle_MSTP_Task(void)	reentrant
{
	//U8_T tempSBUF;
	U8_T loop = 0;
	for(;;)
	{
		if( cQueueReceive( xReadyQueue, &tempSBUF, ( portTickType ) 10 ) == pdPASS )
		{
			//if(MstpDataReady == 1)
			{	
			/*	Test[loop + 20] = tempSBUF;
				if(loop < 8)	loop++;
				else loop = 0;
			*/
				handle_MSTP_RX(tempSBUF);
				MstpDataReady = 0;
			}
		}
	}
}


#endif