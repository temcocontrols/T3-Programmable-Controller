

#include "main.h"


#ifdef BACNET


#define TRUE      1

//xQueueHandle	xPTPconn;	/* transmit data from serial interrupt to PTPconnection task */
//xQueueHandle	xPTPrece;	/* transmit data from serial interrupt to PTPreception task */
//xQueueHandle	xPTPtran; 	/* transmit data from serial interrupt to PTPtransmission task */

void Send_Buffer(U8_T *buffer,S16_T length, U8_T port);
void PTP_rx_err( void );

S16_T init_idle_state( S16_T r );

/*
void init_communication_structures( void )
{
	int i;
	Protocol_parameters *ptr;
  	FRAME_ENTRY *pframe;

	memset( SendFrame, 0, sizeof( FRAME_ENTRY )* MAX_SEND_FRAMES );
	pframe= &SendFrame[0];
	for( i=0; i<MAX_SEND_FRAMES; i++, pframe++ )
  		pframe->number = i;

  	Using_send_frame = 0;

//	set_baudrate( 0 );
//	set_baudrate( 1 );
	memset( Routing_table, '\0', MAX_Routing_table*sizeof( Routing_Table ) );
	memset( NL_PARAMETERS, '\0', 2*sizeof( UNITDATA_PARAMETERS ) );
	NL_PARAMETERS[0].primitive = DL_INVALID;
	NL_PARAMETERS[1].primitive = DL_INVALID;
	
	memset( Port_parameters, '\0', 2*sizeof( Protocol_parameters ) );
	//ReceiveFrame_0 = 0;
	ptr = &Port_parameters[0];

	//for( i=0; i<2; i++, ptr++ )
	{
		ptr->port = 0;

		ptr->link_type = SERIAL_LINK;		

		//if( !i )
				ptr->rec_frame = &ReceiveFrame_0;
	//	else
	//			ptr->rec_frame = &ReceiveFrame_1;

		ptr->tx_end = 1;
		ptr->tx_wake_up = 0x0ff;

		ptr->PTP_DLE_mask = 0x0FF;
		ptr->reception_blocked = Q_NOT_BLOCKED;
		ptr->receive_frame_free = 1;
		ptr->send_frame_free = 1;
		ptr->transmission_blocked = 1;

		ptr->PTP_transmission_state = TR_IDLE;
		ptr->PTP_reception_state = REC_IDLE;
		ptr->PTP_connection_state = DISCONNECTED;
		ptr->Rec_frame_state = RX_IDLE;
		ptr->rec_trigger_sequence = 0;

		ptr->InactivityTimer = 0;   // 60s
		ptr->ResponseTimer = 0;		// 5s 
		ptr->HeartbeatTimer = 0;  	// 15s

		ptr->MSTP_MASTER_state = MSTP_MASTER_IDLE;
	}
	password_needed = 0;
	RemoveReceivedEntry(ptr);


	Station_NUM = 1;
	panel_net_info.panel_type = MINI_T3000;
	panel_net_info.network_number = 9999;
	panel_net_info.panel_number = Station_NUM;
	strcpy( panel_net_info.network_name, "TEMCO_CONTROLS" );
	strcpy( panel_net_info.panel_name, "T3000 Mini" );

}
*/



/*
 * ----------------------------------------------------------------------------
 * Function Name: ReceiveFrameAvailable
 * Purpose: chech the frame is available, and return the result
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
S16_T ReceiveFrameAvailable( Protocol_parameters *ps )
{
	if( ps->receive_frame_free )
		return 0;
	else
		if( ps->rec_frame_ready || ps->received_valid_frame ||	ps->received_invalid_frame )	return 1;
		else return 0;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: RemoveReceivedEntry
 * Purpose: 
 * Params:   
 * Returns:
 * Note: when the frame is invailable, remove the frame enter
 * ----------------------------------------------------------------------------
 */
void RemoveReceivedEntry( Protocol_parameters *ps )
{
		ps->received_valid_frame = 0;
		ps->received_invalid_frame = 0;
		ps->rec_frame_ready = 0;
		ps->reception_blocked = Q_NOT_BLOCKED;
		ps->receive_frame_free = 1;
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: SendFreeEntry
 * Purpose: 
 * Params:   
 * Returns:
 * Note:  get FRAME_ENTRY 
 * ----------------------------------------------------------------------------
 */
FRAME_ENTRY *SendFreeEntry( S16_T port, S16_T reply )
{
	FRAME_ENTRY xdata *frame_ptr;
	S16_T i = 0;

	//if( no_of_send_frame_used >= MAX_SEND_FRAMES )   return NULL;
	//vSemaphoreCreateBinary((xSemaphoreHandle)Using_send_frame);
  	//no_of_send_frame_used++;
	frame_ptr = SendFrame;

  	do
	{
		if( /*!GetByteBit(frame_ptr->flag,0,1)*/frame_ptr->being_used == 0)
		{
			/*SetByteBit(&frame_ptr->flag,1,0,1);*/ frame_ptr->being_used = 1;
			/*SetByteBit(&frame_ptr->flag,1,1,1);*/ frame_ptr->locked = 1;
			/*SetByteBit(&frame_ptr->flag,port,2,1);*/ frame_ptr->port = port;
			/*SetByteBit(&frame_ptr->flag,reply ,3,1);*/frame_ptr->reply_flag = reply;
			//cSemaphoreTake((xSemaphoreHandle)Using_send_frame,0);
			return frame_ptr;
    	}
    	i++;
		frame_ptr++;
	}
 	while( i < MAX_SEND_FRAMES );

	//cSemaphoreTake(Using_send_frame,0);
 	return NULL;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: SendFrameAvailable
 * Purpose: 
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
extern bit flag_test;
FRAME_ENTRY *SendFrameAvailable( S16_T port, S16_T reply )
{
	register FRAME_ENTRY *frame_ptr;
	register S16_T i = 0;
//	Protocol_parameters *ps;
	
	//ps = Port_parameters;
	//frame_ptr = Port_parameters
	frame_ptr = SendFrame;
	
	do
	{
		if( frame_ptr->being_used == 1 && frame_ptr->locked == 0 && frame_ptr->port == port )
		//if(GetByteBit(frame_ptr->flag,0,1) && !GetByteBit(frame_ptr->flag,1,1) && GetByteBit(frame_ptr->flag,2,1) == port)
		{
			if( reply < 0 )	return frame_ptr;
			else
				if( /*GetByteBit(frame_ptr->flag,3,1) == reply*/frame_ptr->reply_flag == reply )
					return frame_ptr;
		}
		i++;
		frame_ptr++;
	}
	while( i < MAX_SEND_FRAMES );	
	return NULL;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: RemoveSentEntry
 * Purpose: 
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
void RemoveSentEntry( FRAME_ENTRY *frame_ptr )
{
	if(frame_ptr)
	{
		/*SetByteBit(&frame_ptr->flag,0,0,1);*/ frame_ptr->being_used = 0;	
		/*SetByteBit(&frame_ptr->flag,0,1,1);*/ frame_ptr->locked = 0;
		/*SetByteBit(&frame_ptr->flag,0,3,1);*/ frame_ptr->reply_flag = 0;
		/*SetByteBit(&frame_ptr->flag,0,6,2);*/ frame_ptr->delay = 0;
		
		//no_of_send_frame_used--;
	}
}

void reset_tx_port( S16_T port )
{
	if( port )
	{
		Port_parameters[1].tx_end = 1;
		Port_parameters[1].tx_wake_up = 0xff;
	}
	else
	{
		Port_parameters[0].tx_end = 1;
		Port_parameters[0].tx_wake_up = 0xff;
	}
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: Send_frame
 * Purpose: 
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
 /* PTP frame
 	Preamble	frameType	FrameLength		HeaderCRC	Data		DataCRC
	0X55 0XFF		1byte		2bytes		1 byte		n bytes		2 bytes 

	MSTP FRAME
	Premable	FrameType	DestAddr	SourceAdrr	FrameLength		HeaderCRC	Data	DataCRC	 padding
 	0X55 0XFF		1byte	1byte		1byte			2bytes		1byte		nbytes	2byte		1byte
 */

U8_T ttt = 0;
 
void Send_frame( FRAME_ENTRY *frame, int frame_type, int dest,Protocol_parameters *ps )
{
	U32_T Time_frame;
	U8_T HeaderCRC;
	U16_T Send_index;
	U8_T work_byte;
	U16_T i;
	U8_T *send_buffer;

	if( frame == NULL && ( ps->link_type == SERIAL_LINK || ps->link_type == MODEM_LINK ) )
	{
		ps->SendFrameTimer = 5;
	    Time_frame = 0;
		send_buffer = (char*)&frame_array[frame_type][1];
		Send_index = (int)frame_array[frame_type][0];
	}
	else
	{
		if( !ps->port )
			send_buffer = send_frame_buffer0;
		else
			send_buffer = send_frame_buffer1;
   
		if(frame_type!=-1)
   		{
			Send_index = 2;
			*send_buffer = 0x55;
			send_buffer++;
			*send_buffer = 0x0ff;
			send_buffer++;
	
			HeaderCRC = 0x0ff;
				/* Frame Type */
			if( ps->link_type != RS485_LINK )
			{
				if( frame_type == DATA_0 )
				{
					if( ps->TxSequence_number )
					{
						frame_type = DATA_1;
						frame->FrameType = frame_type;
					}
				}
			}

			work_byte = frame_type;
			HeaderCRC = crc8_table[ work_byte ^ HeaderCRC ];
			Send_index += send_octet( (int)work_byte, &send_buffer, (int)ps->link_type );
	
			if( ps->link_type == RS485_LINK )
			{

				/* Destination Address  */
				*send_buffer = dest;
				send_buffer++;
				Send_index++;
				HeaderCRC = crc8_table[ dest ^ HeaderCRC ];
				/* Source Address  */
				if(!ps->nack0received)         /* panelOff for RS485 */
				{
					*send_buffer = Station_NUM;
					HeaderCRC = crc8_table[ Station_NUM ^ HeaderCRC ];
	      		}
				else
				{
				 	*send_buffer = ps->PTP_reception_state; /* OS - original station for RS485 */
					HeaderCRC = crc8_table[ ps->PTP_reception_state ^ HeaderCRC ];
      			}
	/*			*send_buffer = Station_NUM;*/
				send_buffer++;
				Send_index++;
	/*			HeaderCRC = crc8_table[ Station_NUM ^ HeaderCRC ];*/
			}

			if( frame )
				i = frame->Length;
			else
				i = 0;
			/* MSB of frame->Length */
			work_byte = i >> 8;
			HeaderCRC = crc8_table[ work_byte ^ HeaderCRC ];
			Send_index += send_octet( (int)work_byte, &send_buffer, (int)ps->link_type );
	
			/* LSB of frame->Length */
			work_byte = i & 0x0ff;
			HeaderCRC = crc8_table[ work_byte ^ HeaderCRC ];
			Send_index += send_octet( (int)work_byte, &send_buffer, (int)ps->link_type );
	
			work_byte = ~HeaderCRC;
			Send_index += send_octet( (int)work_byte, &send_buffer, (int)ps->link_type );
	
			if( i )
			{
				frame->DataCRC = 0x0ffff;
				frame->DataCRC = CalcBlockDataCRC( (unsigned char *)frame->Buffer,frame->Length, frame->DataCRC );

				for( i=0; i<frame->Length; i++ )
				{
					Send_index += send_octet( (int)frame->Buffer[i], &send_buffer, (int)ps->link_type );
				}
				frame->DataCRC = ~frame->DataCRC;
				i = frame->DataCRC;
				/* MSB of frame->DataCRC */
				work_byte = i & 0x0ff;
				Send_index += send_octet( (int)work_byte, &send_buffer, (int)ps->link_type );

				/* LSB of frame->DataCRC */
				work_byte = i >> 8;
				Send_index += send_octet( (int)work_byte, &send_buffer, (int)ps->link_type );
			}

			if( !ps->port )
				send_buffer = send_frame_buffer0;
			else
				send_buffer = send_frame_buffer1;			
		
		}
	   	else
	   	{
    		for(Send_index=0;Send_index<6;Send_index++)
        		send_buffer[Send_index] = 0x55;
    		send_buffer[Send_index++] =0x15;

   		}
	}
	if( ps->link_type == RS485_LINK )
	{
		send_buffer[Send_index] = 0x0FF; /*  add padding byte */
		Send_index++;
	}
 /*	else
  	{
    	if( Send_index<30 )		    Time_frame=0;
  	}*/

	//ps->tx_end = 0;

	if( ps->link_type != RS485_LINK )
	{
		ps->ResponseTimer = 0;
		ps->HeartbeatTimer = 0;
	}
  	else
	{
	
	}
	ps->SilenceTimer = 0;

	//55 FF 07 00 00 23
	//55 FF 06 00 00 BB
/*	if(send_buffer[2] == 0x06)
	{
		send_buffer[0] = 0x55;send_buffer[1] = 0xff;send_buffer[2] = 0x06;
		send_buffer[3] = 0x00;send_buffer[4] = 0x00;send_buffer[5] = 0xbb;
		Send_index = 6;
	}
	else if ( send_buffer[2] == 0x07)
	{
		send_buffer[0] = 0x55;send_buffer[1] = 0xff;send_buffer[2] = 0x07;
		send_buffer[3] = 0x00;send_buffer[4] = 0x00;send_buffer[5] = 0x23;
		Send_index = 6;
	}
	else*/
  		Send_Buffer(send_buffer,Send_index,ps->port);

/*	if( !ps->tx_end )
	{
 		reset_tx_port( ps->port );
	}
*/
//	ps->SilenceTimer = 0;

	if( ps->link_type != RS485_LINK )
	{
		ps->ResponseTimer = 0;
		ps->HeartbeatTimer = 0;
	}
	else
	{
		ps->UsedToken = TRUE;
  	}
}

#if 0
void Send_frame( FRAME_ENTRY *frame, S16_T frame_type, S16_T dest,Protocol_parameters *ps )
{
//	U32_T Time_frame;
	U8_T HeaderCRC;
	U16_T Send_index;
	U8_T work_byte;
	U16_T i;
	char *send_buffer;

	if( !ps->port )
		send_buffer = send_frame_buffer0; // get a buffer
	else
		send_buffer = send_frame_buffer1;

	if(frame_type!=-1)
	{
/* send Preamble 0x55 0xff */
		Send_index = 2;
		*send_buffer = 0x55;
		send_buffer++;
		*send_buffer = 0x0ff;
		send_buffer++;

/* send FrameType */			
		HeaderCRC = 0x0ff; // initial SendHeaderCRC 0XFF			
		if( ps->link_type != RS485_LINK )
		{
			if( frame_type == DATA_0 )
			{
				if( ps->TxSequence_number )
				{
					frame_type = DATA_1;
					frame->FrameType = frame_type;
				}
			}
		}
		work_byte = frame_type;	   
		HeaderCRC = crc8_table[ work_byte ^ HeaderCRC ]; 
		Send_index += send_octet( (int)work_byte, &send_buffer, (int)ps->link_type );
	
		if( ps->link_type == RS485_LINK )
		{	
		/* Destination Address  */
			*send_buffer = dest;
			send_buffer++;
			Send_index++;
			HeaderCRC = crc8_table[ dest ^ HeaderCRC ];
		/* Source Address  */
			if(!ps->nack0received)         /* panelOff for RS485 */
			{
			 	*send_buffer = Station_NUM;
			 	HeaderCRC = crc8_table[ Station_NUM ^ HeaderCRC ];
      		}
			else
			{
			 	*send_buffer = ps->PTP_reception_state; /* OS - original station for RS485 */
			 	HeaderCRC = crc8_table[ ps->PTP_reception_state ^ HeaderCRC ];
      		}
/*			*send_buffer = Station_NUM;*/
			send_buffer++;
			Send_index++;
/*			HeaderCRC = crc8_table[ Station_NUM ^ HeaderCRC ];*/
		}

/* send Frame Lenght */			
		if( frame )
			i = frame->Length;
		else
			i = 0;			
		/* MSB of frame->Length */
		work_byte = i >> 8;
		HeaderCRC = crc8_table[ work_byte ^ HeaderCRC ];
		Send_index += send_octet( (S16_T)work_byte, &send_buffer, (S16_T)ps->link_type );	
		/* LSB of frame->Length */
		work_byte = i & 0x0ff;
		HeaderCRC = crc8_table[ work_byte ^ HeaderCRC ];
		Send_index += send_octet( (S16_T)work_byte, &send_buffer, (S16_T)ps->link_type );
/* send datas , if length is 0 , finish sending.
else	send headeroctet and send octect  */
/* send HeaderCRC */	
		work_byte = ~HeaderCRC;
		Send_index += send_octet( (S16_T)work_byte, &send_buffer, (S16_T)ps->link_type );

		if( i )
		{
			frame->DataCRC = 0x0ffff;				
			frame->DataCRC = CalcBlockDataCRC( (U8_T *)frame->Buffer,frame->Length, frame->DataCRC );				
			for( i=0; i<frame->Length; i++ )
			{
				Send_index += send_octet( (S16_T)frame->Buffer[i], &send_buffer, (S16_T)ps->link_type );
			}
			frame->DataCRC = ~frame->DataCRC;
			i = frame->DataCRC;
			/* MSB of frame->DataCRC */
			work_byte = i & 0x0ff;
			Send_index += send_octet( (S16_T)work_byte, &send_buffer, (S16_T)ps->link_type );
			
			/* LSB of frame->DataCRC */
			work_byte = i >> 8;
			Send_index += send_octet( (S16_T)work_byte, &send_buffer, (S16_T)ps->link_type );
		}

		if( !ps->port )
			send_buffer = send_frame_buffer0;
		else
			send_buffer = send_frame_buffer1;

		if( ps->link_type == RS485_LINK )  /* for MSTP FRAME, adding padding */
		{
			send_buffer[Send_index] = 0x0FF; /*  add padding byte */
			Send_index++;
		}
	}
	else
	{
	    for(Send_index=0;Send_index<6;Send_index++)        send_buffer[Send_index] = 0x55;
	    send_buffer[Send_index++] =0x15;
	}

	ps->tx_end = 0;

	if( ps->link_type != RS485_LINK )
	{
		ps->ResponseTimer = 0;
		ps->HeartbeatTimer = 0;
	}

	Send_Buffer(send_buffer,Send_index,ps->port);

	if( !ps->tx_end )  		 reset_tx_port( ps->port );	

	ps->SilenceTimer = 0;
	if( ps->link_type != RS485_LINK )
	{
		ps->ResponseTimer = 0;
		ps->HeartbeatTimer = 0;
	}
	else
	{
		ps->UsedToken = TRUE;
  	}
}
#endif


/*
 * ----------------------------------------------------------------------------
 * Function Name: send_octet
 * Purpose: send octect procedure
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
S16_T send_octet( S16_T octet, U8_T **buffer, S16_T link_type )
{
	if( ( link_type != RS485_LINK ) &&( octet == 0x10 || octet == 0x11 || octet == 0x13 ) )
	{
		**buffer = 0x10;
		(*buffer)++;
		**buffer = octet | 0x80;
		(*buffer)++;
		return 2;
	}
	**buffer = (U8_T)octet;
	(*buffer)++;
	return 1;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: init_idle_state
 * Purpose: initial idle status
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
S16_T init_idle_state( S16_T r )
{
	Protocol_parameters *ps;
	/* PORT_STATUS_variables *ps; */
	if( !port )
	{
	 	ps = Port_parameters;
	}
	else
	{
	 	ps = &Port_parameters[1];
	}

	if(r)
	{
		router( N_UNITDATArequest, Initialize_Routing_Table, NULL, 0, ps, 1);
	}	
	Routing_table[port].status = PTP_INSTALLED;
	ps->reception_blocked = Q_NOT_BLOCKED;
	ps->receive_frame_free = 1;
	ps->send_frame_free = 1;
	ps->transmission_blocked = 1;
	
	NL_PARAMETERS[port].primitive = DL_INVALID;
	ps->PTP_transmission_state = TR_IDLE;
	ps->PTP_reception_state = REC_IDLE;
	ps->PTP_connection_state = DISCONNECTED;
	ps->Rec_frame_state = RX_IDLE;
	ps->rec_trigger_sequence = 0;
	ps->MSTP_MASTER_state = MSTP_MASTER_IDLE;
	memset( Routing_table[port].Port.networks_list, 0, sizeof(Routing_table[port].Port.networks_list));
/*	if( ps->link_type==SERIAL_LINK || ps->link_type == MODEM_LINK )
	 	outputd( "ATZ\r", 4, ps->port);*/

		/*SET COMM PORT*/
}


void vStartPTPTask(void)
{
	sTaskCreate(PTP_connection_sm, (const signed portCHAR * const)"ptp_connection",portMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY+ 2, (xTaskHandle *)&xHandlePTPconnection); 
	sTaskCreate(PTP_reception_sm, (const signed portCHAR * const)"ptp_reception",portMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, (xTaskHandle *)&xHandlePTPreception); 
	sTaskCreate(PTP_transmission_sm, (const signed portCHAR * const)"ptp_transmission",portMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, (xTaskHandle *)&xHandlePTPtransmission); 

}

/*
 * ----------------------------------------------------------------------------
 * Function Name: PTP_conn_term_sm
 * Purpose: PTP connect state machine
 * Params:   
 * Returns:
 * Note:  PTP connect state machine have 5 state : DISCONNECTED, INBOUND, OUTBOUND, CONNECTED, DISCONNECTING
 * ----------------------------------------------------------------------------
 */
void PTP_connection_sm(void )
{
	FRAME_ENTRY *rec_frame, *frame;
	Protocol_parameters *ps;
	U8_T physical_connection_state;
	U16_T PTP_connection_sleep;
	portTickType xDelayPeriod = ( portTickType ) 200 / portTICK_RATE_MS;
	bit flag_test =1;
	physical_connection_state = 1;
	
	for( ;; )
	{
		if( !port )
		{			
			ps = Port_parameters;
			//rec_frame = &ReceiveFrame_0;
			rec_frame = ps->rec_frame;    // modify by chelsea 2010/8/6
		}
		else
		{
			rec_frame = &ReceiveFrame_1;
			ps = &Port_parameters[1];
		}
		vTaskDelay(xDelayPeriod);		
		//if( cSemaphoreTake( xPTPconn, 1000 ) == pdTRUE )
		//if( cQueueReceive( xPTPconn, &Port_parameters, ( portTickType ) 0 ) == pdPASS )
		//if( ps->rec_frame->HeaderCRC != 0)
		#if 1
		{			
			//printf("ok\r\n");
			PTP_connection_sleep = 0;
			switch( ps->PTP_connection_state )
			{
				case DISCONNECTED:
					/* connect Outbound
						if a DL-CONNECT.request is received, establish a physical connection
					*/
					if( NL_PARAMETERS[port].primitive == DL_CONNECT_REQUEST )  // if a DL-CONNECT.request is received, establish a physical connection
					{
						/* start sending */
					//	while( !ps->tx_end );
						ps->SendFrameTimer = 12;
						Send_Buffer(trigger_sequence, 7,ps->port);   /* send trigger squence "BACnet<CR>"*/
					//	while( !ps->tx_end && ps->SendFrameTimer );
						ps->RetryCount = 0;
						ps->ResponseTimer = 0;  
						ps->PTP_connection_state = OUTBOUND;
	/*					PTP_connection_sleep =  T_CONN_REQ;*/
		        		physical_connection_state = 1;
						break;
					}

					/*	connect inbound
						if a physical layer connection has been made and the "BACnet<CR>" trigger sequence is receive
						transmit ConnectRequestFrame
					*/
					/* for test */
					if( ps->rec_trigger_sequence >= 7 &&  ps->rec_trigger_sequence != 255)
					{
					//	flag_test = 0;
						Test[40] = trigger_sequence[0];
						Test[41] = trigger_sequence[1];
						Test[42] = trigger_sequence[2];
						Test[43] = trigger_sequence[3];
						Test[44] = trigger_sequence[4];
						Test[45] = trigger_sequence[5];
						Test[46] = trigger_sequence[6];

						ps->PTP_connection_state = INBOUND;
						Send_frame( NULL, CONNECT_REQUEST, 0, ps );  // 	transmit ConnectRequestFrame
						ps->rec_trigger_sequence = 0;
	/*					PTP_connection_sleep = T_CONN_RSP;*/
		        		physical_connection_state = 1;
	          			ps->RetryCount = 0;
						ps->ResponseTimer = 0;  
						break;
					}

					if( ps->received_valid_frame )
					{
						/*	Unwanted frame received */
						RemoveReceivedEntry( ps );
						PTP_connection_sleep = 0;
						break;
					}
				//	suspend( ps->base_task + PTP_CONNECTION );	
				//	vTaskSuspend(xHandlePTPconnection);
	        		Routing_table[port].status = PTP_INSTALLED;
					break;
	
				case OUTBOUND:
				/* Connect Request Received */	
				//	msleep(T_CONN_REQ);		
					if( ps->received_valid_frame ) //if ReceiveValidFrame is TRUE and FrameType is equal to Connect Reques		
					{
						if( rec_frame->FrameType == CONNECT_REQUEST )
						{
							Send_frame( NULL, CONNECT_RESPONSE, 0, ps ); // transmit a Connect Response frame
							Routing_table[port].status = PTP_ACTIVE;
							ps->TxSequence_number = 0;
							ps->RxSequence_number = 0;
						//	vTaskResume(xHandlePTPreception);
						//	vTaskResume(xHandlePTPtransmission);
						//	resume( ps->base_task + PTP_RECEPTION );
						//	resume( ps->base_task + PTP_TRANSMISSION );
						//	cQueueSendFromISR( xPTPrece, ( void * )&Port_parameters, 0);
						//	cQueueSendFromISR( xPTPtran, ( void * )&Port_parameters, 0);
						//	cQueueSend( xPTPrece, ( void * )&Port_parameters, 0);
						//	cQueueSend( xPTPtran, ( void * )&Port_parameters, 0);

							// issue a DL_CONNECT.confirm to notify the network layer that a connection has been established
							router( N_UNITDATArequest, I_Am_Router_To_Network, NULL, 0, ps, 2);
							NL_connect_ind( ps, rec_frame->Buffer, rec_frame->Length ); 
							RemoveReceivedEntry( ps );
							ps->PTP_connection_state = CONNECTED;
							break;
						}
					}
				
					if( ps->ResponseTimer >= T_CONN_REQ )
					{
						if( ps->RetryCount < N_RETRIES )
						{
						/* Connect Request Timeout */
							ps->RetryCount++;  
							ps->ResponseTimer = 0;
							while( !ps->tx_end );
							ps->SendFrameTimer = 12;
							Send_Buffer(trigger_sequence, 7,ps->port);   /* send trigger squence "BACnet<CR>"*/
							while( !ps->tx_end && ps->SendFrameTimer );
							PTP_connection_sleep = T_CONN_REQ;
							ps->PTP_connection_state = OUTBOUND;  /*enter OUTBOUND status */
 							break;
						}
						else
						{
						/*	Connect Request Failure	*/
							/* signal network layer	*/
							/* issue a DL-CONNECT.confirm to notify the network layer of the failure */

							NL_connect_failed( ps );
							ps->PTP_connection_state = DISCONNECTED;
							PTP_connection_sleep = 0;
							break;
						}
					}
					break;
	
				case INBOUND:
				/*	The net layer has recognized that the calling device wishes to
				establish a BACnet connection, and the local device is waiting for
				a Connect Response frame from the calling device	*/

				/*	Valid Connect Response Received	*/
					if( ps->received_valid_frame )
					{
						if( rec_frame->FrameType == CONNECT_RESPONSE )
						{
							RemoveReceivedEntry( ps );
							if( !password_needed || password_OK )  /* if password is not need or a valid password is present in the data field of the frame */
							{
							//	ps->received_valid_frame = 0;
								ps->TxSequence_number = 0;
								ps->RxSequence_number = 0;
								Routing_table[port].status = PTP_ACTIVE;
								Routing_table[port].Port.network = 0;							
								ps->PTP_connection_state = CONNECTED;	
								
								//vTaskResume(xHandlePTPreception);
							//	vTaskResume(xHandlePTPtransmission);
								//resume( ps->base_task + PTP_RECEPTION );
								//resume( ps->base_task + PTP_TRANSMISSION );
								//cQueueSendFromISR( xPTPrece, ( void * )&Port_parameters, 0);
								//cQueueSendFromISR( xPTPtran, ( void * )&Port_parameters, 0);
								//cQueueSend( xPTPrece, ( void * )&Port_parameters, 0);
								//cQueueSend( xPTPtran, ( void * )&Port_parameters, 0);

								while( !Routing_table[port].Port.network && ps->InactivityTimer < 100 ) ;	
								/* issue a DL-CONNECT.indication to notify the network layer of the connection */
								router( N_UNITDATArequest, I_Am_Router_To_Network_Prop, NULL, 0, ps, 1);
								ps->InactivityTimer = 0;	
						//		msleep(120);     /* 6 sec*/
							//	DELAY_Ms(6000);
							/*	DELAY_Us(6000);DELAY_Us(6000);DELAY_Us(6000);DELAY_Us(6000);DELAY_Us(6000);
								DELAY_Us(6000);DELAY_Us(6000);DELAY_Us(6000);DELAY_Us(6000);DELAY_Us(6000);*/
								break;
							}
							else  /* if password is need and a valid password is not present */
							{
	                			frame = SendFreeEntry( ps->port, 0 );
								if( frame )
								{
									frame->FrameType = DISCONNECT_REQUEST;
									frame->Length = 1;
									frame->Buffer[0] = '2';  //  password is wrong 
									Send_frame( frame, DISCONNECT_REQUEST, 0, ps );
									RemoveSentEntry( frame );
									ps->PTP_connection_state = DISCONNECTING;
									PTP_connection_sleep = T_CONN_RSP;
	              					ps->ResponseTimer=0;
									break;
								}
							}
						}
						if( rec_frame->FrameType == DISCONNECT_REQUEST )
						{
							RemoveReceivedEntry( ps );
							Send_frame( NULL, DISCONNECT_RESPONSE, 0, ps );
							ps->PTP_connection_state = DISCONNECTED;
							PTP_connection_sleep = 0;
							break;
						}
					}
					if( ps->ResponseTimer >= T_CONN_RSP )
					{ /* connect response timeout */
						if( ps->RetryCount >= N_RETRIES )
						{
							ps->ResponseTimer = 0;
							ps->PTP_connection_state = DISCONNECTED;
							init_idle_state( 0);
							break;
						}
						else
						{ /*connect Reponse Failure */
							ps->RetryCount++;
							Send_frame( NULL, CONNECT_REQUEST, 0, ps );  /* transmit a Connect Request Frame */
							ps->PTP_connection_state = INBOUND;
							break;
						}
					} 
					break;
	
				case CONNECTED:
				/*	The connection procedure has been completed and the two devices
				are exchanging BACnet PDUs. The data link remains in this
				PTP_connection_state until termination	*/
				//	vTaskSuspend(xHandlePTPconnection);
				//  suspend( ps->base_task + PTP_CONNECTION );  TBD:
					/*	Network disconnect	*/
					if( NL_PARAMETERS[port].primitive == DL_DISCONNECT_REQUEST )
					{
						Send_frame( NULL, DISCONNECT_REQUEST, 0, ps );
						ps->PTP_connection_state = DISCONNECTING;
						PTP_connection_sleep = T_RESPONSE;
	          			ps->ResponseTimer=0;
						break;
					}
				
					if( ps->received_valid_frame )
					{
						if( rec_frame->FrameType == DISCONNECT_REQUEST )
						{	/*	Disconnect request received	*/
							RemoveReceivedEntry( ps );
							Send_frame( NULL, DISCONNECT_RESPONSE, 0, ps );
							ps->PTP_connection_state = DISCONNECTED;
							init_idle_state(1);
							/* issue a DL-CONNECT.indication to notify the network layer of the connection */
							router(N_UNITDATArequest, I_Am_Router_To_Network_Prop, NULL, 0, ps ,1);
							break;
						}
						if( rec_frame->FrameType == CONNECT_REQUEST )
						{	/*	Connect request received	*/
							RemoveReceivedEntry( ps );
							Send_frame( frame, CONNECT_RESPONSE, 0, ps );
							ps->PTP_connection_state = CONNECTED;
							/* issue a DL-DISCONNECT.indication to notify the network layer of the connection */
							router(N_UNITDATArequest, I_Am_Router_To_Network_Prop, NULL, 0, ps ,1 );
							break;
						}
						/*	Unwanted frame received */
					//	RemoveReceivedEntry( ps );
						}
					if( ps->received_invalid_frame )
					{
						/*	Unwanted frame received */
						RemoveReceivedEntry( ps );
					}
	
					/* Inactivity Timeout	*/
					if( ps->InactivityTimer > T_INACTIVITY_SEC )
					{
						ps->PTP_connection_state = DISCONNECTED;
						init_idle_state( 1);
						/*issue a DL-DISCONNECT.indicaion to notify the network layer of the disconnection */
						router(N_UNITDATArequest, I_Am_Router_To_Network_Prop, NULL, 0, ps ,1);
						break;
					}

					/*	Connection Lost	*/
					if( !physical_connection_state )
					{
						ps->PTP_connection_state = DISCONNECTED;
						init_idle_state( 1);
						/*issue a DL-DISCONNECT.indicaion to notify the network layer of the disconnection */
						router(N_UNITDATArequest, I_Am_Router_To_Network_Prop, NULL, 0, ps ,1 );
						break;
					}				
					break;
				case DISCONNECTING:
				/*	The network layer has requested termination of the data link. The
				device is waiting for a Disconnect Response frame from the peer device*/
				//	msleep(T_RESPONSE);
					if( ps->received_valid_frame )
					{
						if( rec_frame->FrameType == DISCONNECT_RESPONSE )
						{  /*	Disconnect response received */
							RemoveReceivedEntry( ps );
							ps->PTP_connection_state = DISCONNECTED;
							break;
						}
						else if( rec_frame->FrameType == DISCONNECT_REQUEST )
						{  /*	Disconnect request received */
							RemoveReceivedEntry( ps );
							Send_frame( NULL, DISCONNECT_RESPONSE, 0, ps );
							ps->PTP_connection_state = DISCONNECTED;
							break;
						}
						else
						{	/* Unwanted Frame Received */
						//	ps->received_valid_frame = 0;
							ps->PTP_connection_state = DISCONNECTED;
							break;
						}
					}
					else
					{
						if( ps->ResponseTimer > T_RESPONSE )
						{  
							if( ps->RetryCount < N_RETRIES )
							{	/*Disconnect Response Timeout*/
								/*	Disconnect response timeout	*/
								ps->ResponseTimer = 0;
								ps->RetryCount++;
								Send_frame( NULL, DISCONNECT_REQUEST, 0, ps );
								PTP_connection_sleep = T_RESPONSE;
								ps->PTP_connection_state = DISCONNECTED;
								break;
							}
							else
							{	/*Disconnect Response failure */
								ps->PTP_connection_state = DISCONNECTED;
								break;
							}
						}						
					}
					init_idle_state( 1);
			}	
		}
		#endif
	}
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: PTP_reception_sm
 * Purpose: PTP reception state machine
 * Params:   
 * Returns:
 * Note:  PTP reception state machine have 5 state : REC_IDLE, REC_READY, DATA, DATA_ACK, DATA_NAK
 * ----------------------------------------------------------------------------
 */
void PTP_reception_sm( void)
{
	FRAME_ENTRY *rec_frame/*, *frame*/;
//	U8_T ttframe[520];
	FRAME_ENTRY *frame;
	Protocol_parameters *ps;
	U8_T FrameType;
	U16_T loop=0 ;
	portTickType xDelayPeriod = ( portTickType ) 200 / portTICK_RATE_MS;
	
	for( ; ; ) 
	{
		/*if( !port )
		{
			//frame = &ttframe[0];
			//rec_frame = &ReceiveFrame_0;
			ps = Port_parameters;
			rec_frame = Port_parameters->rec_frame;
			//memcpy(frame, rec_frame, sizeof(FRAME_ENTRY));
			frame = Port_parameters->rec_frame;
		}
		else
		{
			frame = &ReceiveFrame_1_1;
			rec_frame = &ReceiveFrame_1;
			ps = &Port_parameters[1];
		}*/
		vTaskDelay(xDelayPeriod);	
		
		//if( cQueueReceive( xPTPrece, &Port_parameters, ( portTickType ) 0 ) == pdPASS )
		//if( ps->rec_frame->HeaderCRC != 0)
		#if 1
		//if( cSemaphoreTake( xPTPrece, 1000 ) == pdTRUE )
		{	
			ps = Port_parameters;			
			rec_frame = &ps->rec_frame[0];
			frame = &ps->rec_frame[0];
			switch( ps->PTP_reception_state )
			{
				case REC_IDLE:
				/*	The receiver is waiting for the data link to be established
				 between the local device and the peer device. The receiver waits
					to be notified that a peer device is ready to communicate	*/
					/*	Connection Established	*/
					if( ps->PTP_connection_state == CONNECTED )
					{
						ps->RxSequence_number = 0;
						ps->reception_blocked = Q_NOT_BLOCKED;
						ps->PTP_reception_state = REC_READY;
						break;
					}
					break;
				case REC_READY:
				/*	The device is ready to receive frames from the peer device	*/
					if( ps->received_valid_frame )
					{	
						//memcpy(frame, rec_frame, sizeof(FRAME_ENTRY));
						//for(loop = 0;loop < sizeof(FRAME_ENTRY);loop++ )
						//frame[loop] =  rec_frame[loop];//memcpy(frame, rec_frame, sizeof(FRAME_ENTRY));
						RemoveReceivedEntry( ps );
						//ps->received_valid_frame = 0;
						ps->InactivityTimer = 0;
						//memset(frame, '\0', sizeof(FRAME_ENTRY));
						//memcpy(frame, rec_frame, sizeof(FRAME_ENTRY));
						//memcpy(frame, rec_frame, sizeof(FRAME_ENTRY));
						/* Data Received */
						if( frame->FrameType == DATA_0 || frame->FrameType == DATA_1 )
						{
							ps->PTP_reception_state = DATA;
							continue;
						}
						/*	Data ACK */
						if( DATA_ACK_0_XOFF <= frame->FrameType &&
								frame->FrameType <= DATA_ACK_1_XON )
						{
							ps->PTP_reception_state = DATA_ACK;
							continue;
						}
					   	/* Data NCK */
						if( DATA_NAK_0_XOFF <= frame->FrameType &&
								frame->FrameType <= DATA_NAK_1_XON )
						{
							ps->PTP_reception_state = DATA_NAK;
							continue;
						}
						if( HEARTBEAT_XON <= frame->FrameType &&
								frame->FrameType <= HEARTBEAT_XOFF )
						{
							ps->PTP_reception_state = DATA_NAK;
							continue;
						}
						/* test request */
						if( frame->FrameType == TEST_REQUEST )
						{
							ps->InactivityTimer = 0;
							frame = SendFreeEntry( ps->port, 0 );
							if( frame )
							{
								frame->FrameType = TEST_RESPONSE;
								frame->Length = rec_frame->Length;
								//memcpy( frame->Buffer, rec_frame->Buffer, frame->Length );
								RemoveReceivedEntry( ps );
								Send_frame( frame, frame->FrameType, 0, ps );
								RemoveSentEntry( frame );
								ps->PTP_reception_state = REC_READY;
								break;
							}
						}
						/* test reponse */
						if( frame->FrameType == TEST_RESPONSE )
						{
							/* issue a DL_UNITDATA.indication conveying the test_reponse data */

							NL_unitdata_ind( ps, rec_frame->Buffer, rec_frame->Length, rec_frame->Source  );
							RemoveReceivedEntry( ps );
							Send_frame( NULL, HEARTBEAT_XON, 0, ps );
							ps->InactivityTimer = 0;
							ps->PTP_reception_state = REC_READY;
							break;

						}
						break;
					}
					if( ps->received_invalid_frame )
					{
						/*	Bad Data0 / Full buffers	*/	
						//memcpy(frame, rec_frame, sizeof(FRAME_ENTRY));
						RemoveReceivedEntry( ps );	 /* Discard Frame */	
						ps->InactivityTimer = 0;
						if( frame->FrameType == DATA_0 )
						{
							if( ps->reception_blocked == Q_BLOCKED)
									FrameType = DATA_NAK_0_XOFF;
							else   /* NOT_BLOCKED or ALMOST_BLOCKED */
									FrameType = DATA_NAK_0_XON;
							Send_frame( NULL, FrameType, 0, ps );
							PTP_rx_err();
							break;
						}
						/*	Bad Data1  /  Full buffers	*/
						if( frame->FrameType == DATA_1 )
						{								
							if( ps->reception_blocked == Q_BLOCKED )
									FrameType = DATA_NAK_1_XOFF;
							else	/* NOT_BLOCKED or ALMOST_BLOCKED */
									FrameType = DATA_NAK_1_XON;
							Send_frame( NULL, FrameType, 0, ps );
							PTP_rx_err();
							break;
						}
						/* other bad frames */
						ps->PTP_reception_state = REC_READY;
						break;
					}
					/* disconnected */
					if( ps->PTP_connection_state == DISCONNECTED )
					{
						ps->PTP_reception_state = REC_IDLE;
						break;
					}
				//	vTaskSuspend(xHandlePTPreception);
				//	suspend( ps->base_task + PTP_RECEPTION );
	        		break;
	
				case DATA:
				/*	In this state the device has received a Data frame for processing */
					ps->PTP_reception_state = REC_READY;
					if( rec_frame->FrameType == DATA_0 )
					{
						RemoveReceivedEntry( ps );
						if( ps->RxSequence_number == 1 )  
						{ /*  duplication0 fullbuffers	/ duplication 0*/
								/*Discard frame */	
						//	if( ps->reception_blocked == Q_BLOCKED )
						//		FrameType = DATA_ACK_0_XOFF;
						//	else	/* NOT_BLOCKED or ALMOST_BLOCKED */
								FrameType = DATA_ACK_0_XON;
							Send_frame( NULL, FrameType, 0, ps );
						}
						else
						{	/* data0 fullbuffer / newdata0*/
						//	if( ps->reception_blocked == Q_BLOCKED )
						//	{   //	Last Data0_Full_Buffers									
						//			FrameType = DATA_NAK_0_XOFF;
						//	}
						//	else
						//	{   /*	New Data0	*/
								/*	DL_UNITDATA.indication */
							 	ps->RxSequence_number = 1;
						//	 	if( ps->reception_blocked == Q_NOT_BLOCKED )					
								FrameType = DATA_ACK_0_XON;
								Send_frame( NULL, FrameType, 0, ps );
						//	 	if( ps->reception_blocked == Q_ALMOST_BLOCKED )					FrameType = DATA_ACK_0_XOFF;
							 	NL_unitdata_ind( ps, frame->Buffer, frame->Length, frame->Source ); // convey NPDU( or frame->Buffer)
	             		//	}
						}
					}
	        		else if( rec_frame->FrameType == DATA_1 )
					{
						RemoveReceivedEntry( ps );
						if( ps->RxSequence_number == 0 )
						{
							/*Discard frame */
						//	if( ps->reception_blocked == Q_BLOCKED )
						//			FrameType = DATA_ACK_1_XOFF;
						//	else
									FrameType = DATA_ACK_1_XON;
							Send_frame( NULL, FrameType, 0, ps );
						}
						else
						{
						//	if( ps->reception_blocked == Q_BLOCKED )
						//	{
						//		RemoveReceivedEntry( ps );
						//		FrameType = DATA_NAK_1_XOFF;
						//	}
						//	else
						//	{  /*	New Data1	*/
								ps->RxSequence_number = 0;
						//		if( ps->reception_blocked == Q_NOT_BLOCKED )		
								FrameType = DATA_ACK_1_XON;
								Send_frame( NULL, FrameType, 0, ps );
						//		if( ps->reception_blocked == Q_ALMOST_BLOCKED )			FrameType = DATA_ACK_1_XOFF;
							  	NL_unitdata_ind( ps, frame->Buffer, frame->Length, frame->Source  );
								
						 // }
						}
				  	}
				//	Send_frame( NULL, FrameType, 0, ps );
					ps->PTP_reception_state = REC_READY;
	        		break;
				case DATA_ACK:
					ps->PTP_reception_state = REC_READY;
					break;
				case DATA_NAK:
					/*	In this state the device has received a Data Nak frame for processing */
				  	ps->PTP_reception_state = REC_READY;
	        break;
			}
		}
		#endif
	}
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: PTP_transmission_sm
 * Purpose: PTP transmission state machine
 * Params:   
 * Returns:
 * Note:  PTP transmission state machine have 5 state : TR_IDLE, TR_PENDING, TR_READY, TR_BLOCKED
 * ----------------------------------------------------------------------------
 */
 //void handle_PTP_rx_interrupt( Protocol_parameters *ps );

void PTP_transmission_sm(void )
{
	FRAME_ENTRY *frame;
	Protocol_parameters *ps;
    S16_T ResponseTimer;
	portTickType xDelayPeriod = ( portTickType ) 200 / portTICK_RATE_MS;

	ps->HeartbeatTimer = 0;
	for( ; ; ) 
	{
		if( !port )
		{
			ps = Port_parameters;
		}
		else
		{
			ps = &Port_parameters[1];
		}
	
	
	//	ps->transmission_blocked = 1;

		vTaskDelay(xDelayPeriod);
	//	if( cQueueReceive( xPTPtran, &Port_parameters, ( portTickType ) 0 ) == pdPASS )
		//if( ps->rec_frame->HeaderCRC != 0)
		#if 1
		//if( cSemaphoreTake( xPTPtran, 1000 ) == pdTRUE )
		{
			switch( ps->PTP_transmission_state )
			{
				case TR_IDLE:
					/*	In this state the transmitter is waiting for the data link to be
					established between the local device and the peer device. The
					transmitter waits to be notified that a peer device is ready to
					communicate	*/
					if( ps->PTP_connection_state == CONNECTED )
					{
						if( ps->reception_blocked == Q_NOT_BLOCKED )
							Send_frame( NULL, HEARTBEAT_XON, 0, ps );
						else
							Send_frame( NULL, HEARTBEAT_XOFF, 0, ps );
						ps->TxSequence_number = 0;
						ps->PTP_transmission_state = TR_BLOCKED;
						break;
					}				
					break;
				case TR_BLOCKED:
				/*	In this state the peer device has indicated that it is not ready
				to receive data frames. The local device may have data ready to transmit.
				The local device periodically transmits a Heartbeat frame to maintain
				the data link, and waits for the peer device to become ready to receive
				data or for the termination of the data link.	*/
					/*	Send Request	*/
					/*
					if a DL-UNITDATA.request promitive is received


					
					*/
					/*	Peer Receiver Ready	*/
					if( !ps->transmission_blocked )
					{
						ps->PTP_transmission_state = TR_READY;
						break;
					}
					/* Disconnected */
					if( ps->PTP_connection_state == DISCONNECTED )
					{
						ps->PTP_transmission_state = TR_IDLE;
						break;
					}
					/* HeartbearTimer Expired */
					if( ps->HeartbeatTimer >= T_HEARTBEAT_SEC )
					{
						ps->HeartbeatTimer = 0;
						if( ps->reception_blocked == Q_BLOCKED )
							Send_frame( NULL, HEARTBEAT_XOFF, 0, ps );
						else
							Send_frame( NULL, HEARTBEAT_XON, 0, ps );
					   /* transmission state dont change */
						break;
					}
					break;
				case TR_READY:
				/*	The peer device has indicated its readiness to receive data frames
				but the local device has no data ready to transmit. The local device
				periodically transmits a Heartbeat frame to maintain the data link, and
				waits for a local request to transmit data or for the termination of
				the data link	*/

					/* Disconnected */
					if( ps->PTP_connection_state == DISCONNECTED )
					{
						ps->PTP_transmission_state = TR_IDLE;
						break;
					}
					/*	Send Request	*/
					/*
					if a DL-UNITDATA.request promitive is received


					
					*/

					/*	Transmit Message */
					if( !ps->transmission_blocked )
					{
						 if( ps->reception_blocked == Q_NOT_BLOCKED )
						 {	/*	if transimission queue is not empty and transmissionblocked is equal to false */
							frame = SendFrameAvailable( ps->port, -1 );
							if( frame )
							{
									ps->RetryCount = 0;
									ps->HeartbeatTimer = 0;
									ps->ack0received = 0;
									ps->ack1received = 0;
									ps->nack0received = 0;
									ps->nack1received = 0;
									ps->sending_frame_now = 1;
									Send_frame(frame, 2, 0, ps );
									ps->PTP_transmission_state = TR_PENDING;
								 	ResponseTimer = T_RESPONSE;
									break;
							}
						 }
					}
					/* Remote Busy */
			        else 
			        { /* if transmissionBlocked is equal to Ture  */
						 ps->PTP_transmission_state = TR_BLOCKED;
						 break;
			        }
					/* 	Heart Beart Expired */
					if( ps->HeartbeatTimer >= T_HEARTBEAT_SEC )
					{
						 ps->HeartbeatTimer = 0;
						 /* dont change transmission state */
						if( ps->reception_blocked == Q_BLOCKED )
							Send_frame( NULL, HEARTBEAT_XOFF, 0, ps );
						else
							Send_frame( NULL, HEARTBEAT_XON, 0, ps );
						break;
					}

					if( ps->reception_blocked == Q_NOT_BLOCKED )
						;//suspend( ps->base_task + PTP_TRANSMISSION ); TBD:
					//	vTaskSuspend(xHandlePTPtransmission);	
	        		else
	          			;//msleep(1);	TBD:
					//	DELAY_Us(6000);
					break;
	
				case TR_PENDING:
				/* in this state, the local devie has transmitted a data frame to the peer device
				and is waiting for an acknowlodement from the peer device */
					/*	Disconnected	*/
					if( ps->PTP_connection_state == DISCONNECTED )
					{
						RemoveSentEntry( frame );
						ps->PTP_transmission_state = TR_IDLE;
						break;
					}
					/*	Send Request	*/
					/*
					if a DL-UNITDATA.request promitive is received


					
					*/

					/*	Receive Acknowledgement	*/
					if( ( ps->ack0received && ps->TxSequence_number == 0 ) ||
						( ps->ack1received && ps->TxSequence_number == 1 ) )
					{
	
						RemoveSentEntry( frame );
	          			frame=NULL;
						ps->sending_frame_now = 0;
						ps->TxSequence_number = 1 - ps->TxSequence_number;
						ps->ack0received = 0;
						ps->ack1received = 0;
						ps->PTP_transmission_state = TR_READY;
						break;
					}	
					if( !ResponseTimer )
	        		{ 
						if( ps->RetryCount < N_RETRIES )
						{
							/*	Retry	*/
							ps->RetryCount++;
							ps->PTP_transmission_state = TR_PENDING;
							ps->sending_frame_now = 1;
							Send_frame( frame, 0, 0, ps );
							ResponseTimer = T_RESPONSE;
							break;
						}
						else
						{
							/*	Retries failed	*/
							RemoveSentEntry( frame );
	            			frame=NULL;
							ps->RetryCount = 0;
							ps->sending_frame_now = 0;
							ps->ResponseTimer = 0;
							ps->PTP_transmission_state = TR_READY;
							break;
						}
					}
					break;
			}
		}
		#endif
	}
}




U16_T CalcBlockDataCRC( U8_T *dat,U16_T length , U16_T crcValue )
{
	U16_T crcLow, crcHigh;
	S16_T i;
	for( i=0; i<length; i++ )
	{
		crcHigh = crcValue >> 8;
		crcLow = ( crcValue & 0x0ff ) ^ dat[i];
		crcValue = crcHigh ^ crc16_table[crcLow];
	}
	return crcValue;
}


#endif
