S16_T NL_unitdata_ind( Protocol_parameters *ps, S8_T *npdu, U16_T length_npdu, U8_T Source );
S16_T NL_unitdata_req( Protocol_parameters *ps, TSMTable *PTRtable );
S16_T NL_connect_ind( Protocol_parameters *ps, S8_T *npdu, U16_T length_npdu );
S16_T NL_connect_failed( Protocol_parameters *ps );
S16_T router( S16_T service, S16_T command, S8_T *dat, U16_T length,Protocol_parameters *ps, S16_T send );
