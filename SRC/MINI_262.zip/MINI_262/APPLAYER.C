#define _APPLAYER_DOT_C

#include "main.h"

#ifdef BACNET


#define ON   	1
#define OFF  	0
#define FALSE   0
#define TRUE   1

bit f_test;

void ServerTSM_task( void );
/*
void vStartSeverTSMTask(void)
{
	sTaskCreate(ServerTSM_task, (const signed portCHAR * const)"SeverTSM",portMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, (xTaskHandle *)&xHandleSeverTSM); 
}*/

/*
 * ----------------------------------------------------------------------------
 * Function Name: TSM_resetsegments
 * Purpose: 
 * Params:
 * Returns:
 * Note: this function is called in when command is STSM_SEGMENTING_RESPONSE
 * ----------------------------------------------------------------------------
 */
void TSM_resetsegments( TSMTable *PTRtable )
{
	PTRtable->length += PTRtable->last_length;
	PTRtable->dat -= PTRtable->last_length;
	PTRtable->noseq -= PTRtable->windowsize;
	PTRtable->nosegment = 0;
	PTRtable->last_length = 0;
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: TSM_init
 * Purpose: initial PTRtable
 * Params:
 * Returns:
 * Note: this function is called in ClientTransactionStateMachine and TSM_lookid
 * ----------------------------------------------------------------------------
 */
void TSM_init( TSMTable *PTRtable, UNITDATA_PARAMETERS *NL_parameters )
{
	memset( PTRtable, 0, sizeof( TSMTable ) );

	if( NL_parameters )
	{
		PTRtable->DNET = NL_parameters->DNET;
		PTRtable->SNET = NL_parameters->SNET;
		PTRtable->SLEN = NL_parameters->SLEN;
		memcpy( PTRtable->S_MAC_ADR, NL_parameters->S_MAC_ADR, 6 );
		PTRtable->DLEN = NL_parameters->DLEN;
		memcpy( PTRtable->D_MAC_ADR, NL_parameters->D_MAC_ADR, 6 );
	}
	PTRtable->state = STSM_IDLE;
	PTRtable->noseq = 1;
	PTRtable->timeout = 220;
	PTRtable->windowsize  = 1;
	PTRtable->reply_flag = 1;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: TSM_lookid
 * Purpose: initial PTRtable
 * Params:  client_server = 0 ::> use Server_TSM_table
 *			client_server = 1 ::> use Client_TSM_table
 * Returns:
 * Note: this function is called in ServerTransactionStateMachine 
 * ----------------------------------------------------------------------------
 */
S16_T TSM_lookid( UNITDATA_PARAMETERS *NL_parameters, S16_T id,S16_T client_server )
{ // put NL_parameters to Server_TSM_table or Client_TSM_table
	S16_T i, j;
	TSMTable *PTRtable;

	j = -1;
	for( i=0; i<MAXServerTSMTable; i++ )
	{
		
		if( !client_server )	
			PTRtable = &Server_TSM_table[i];
		else
			PTRtable = &Client_TSM_table[i];
		
		if( PTRtable->state != STSM_ILLEGAL )
		{				
			if(PTRtable->invokeID == id )
			{				
				if( PTRtable->DNET ==  NL_parameters->DNET && PTRtable->D_MAC_ADR[0] == NL_parameters->D_MAC_ADR[0] && PTRtable->S_MAC_ADR[0] == NL_parameters->S_MAC_ADR[0] )
					return i;
			}
		}
		else
		{	
			if( j < 0 )		j = i;
		}
	}	
	
/*	if(j==-1) 
	{
		uart1_PutChar('3');			
	}*/
	if( ( i == MAXServerTSMTable ) && ( j >= 0 ) )
	{
		if( !client_server )
			PTRtable = &Server_TSM_table[j];
		else
			PTRtable = &Client_TSM_table[j];
		TSM_init( PTRtable, NL_parameters ); // put NL_parameters to PTRtable
		PTRtable->invokeID = id;
		return j;
	}


	return STSM_ILLEGAL;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: TSM_free
 * Purpose: initial PTRtable
 * Params:  client_server = 0 ::> use Server_TSM_table
 *			client_server = 1 ::> use Client_TSM_table
 * Returns:
 * Note: this function is called in ServerTransactionStateMachine 
 * ----------------------------------------------------------------------------
 */
void TSM_free( S16_T entry, S16_T id, S16_T client_server )
{
	TSMTable *PTRtable;
	S16_T max_entry;
	
	if( !client_server )	
		max_entry = MAXServerTSMTable;	
	else
		max_entry = MAXClientTSMTable;
	if( entry < 0 )
	{
		if( !client_server )
			PTRtable = Server_TSM_table;
		else
			PTRtable = Client_TSM_table;

		entry = 0;
		do
		{
			if( PTRtable->state != STSM_ILLEGAL )
			{
				if( PTRtable->invokeID == id )			 	break;
			}
			entry++;
			PTRtable++;
		}
		while( entry < max_entry );
	}
	if( entry >= 0 && entry < max_entry )
	{
		if( !client_server )
			PTRtable = &Server_TSM_table[entry];
		else
			PTRtable = &Client_TSM_table[entry];
	
		PTRtable->state = STSM_ILLEGAL;
		PTRtable->reply_flag = 0;
	}
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: buildservice
 * Purpose: build service
 * Params:  
 * Returns:
 * Note: this function is called in ServerTransactionStateMachine 
 * ----------------------------------------------------------------------------
 */
// U8_T tt[500];
 //U8_T tt1[500];
S16_T buildservice( TSMTable *ptrtable )
{
	if( !ptrtable->special )
	{
		if( ptrtable->length > MAXASDUSIZE )
		 	ptrtable->length_asdu = (U16_T)ptrtable->entities_per_frame * ptrtable->entitysize;
		else
			ptrtable->length_asdu = ptrtable->length;
		/*	 if( !ptrtable->compressed )*/
		//ptrtable->asdu = ptrtable->dat;
		
//		memcpy( tt, ptrtable->dat, ptrtable->length_asdu );
		memcpy( ptrtable->asdu, ptrtable->dat, ptrtable->length_asdu );			
//		memcpy( tt1, ptrtable->asdu, ptrtable->length_asdu );
		/* else
		 NL_parameters.length_asdu = compressdata(NL_parameters.asdu, NL_parameters.length_asdu, ptrtable->data, ptrtable->length, &l);
		*/
		ptrtable->dat += ptrtable->length_asdu;
	}
	else
		server_data( ptrtable );

	ptrtable->last_length += ptrtable->length_asdu;
	ptrtable->length -= ptrtable->length_asdu;
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: encodetag
 * Purpose: 
 * Params:   
 * Returns:
 * Note:  
 * ----------------------------------------------------------------------------
 */
S16_T encodetag(S8_T cl, S8_T t, S8_T *tag, U8_T length)
{
	U16_T n=0;
	if( length <= 4 )
	{
		tag[0] = (t<<4) + (cl<<3) + length;
		n = 1;
	}
	if( length >= 5 && length <= 253 )
	{
		tag[0] = ( t << 4 ) + ( cl << 3 ) + 0x05;
		tag[1] = length;
		n = 2;
	}
	if( length >= 254 && length <= 65535L )
	{
		tag[0] = ( t << 4 ) + ( cl << 3 ) + 0x05;
		tag[1] = 254;
		tag[2] = ( length >> 8 );
		tag[3] = length & 0x00FF;
		n=4;
	}
	return n;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: decodetag
 * Purpose: 
 * Params:   
 * Returns:
 * Note:  
 * ----------------------------------------------------------------------------
 */
S16_T decodetag(S8_T *tag, U16_T *length)
{
	U16_T n=0, l=0;

	l = (unsigned S8_T)tag[0] & 0x07;
	if( l <= 4 )		n=1;
	if( l==5 )
	{
		n=2;
		l = (unsigned S8_T)tag[1];
		if( l==254 )
		{
			n=4;
			l = ( ( (U16_T)tag[2] ) << 8 ) + (unsigned S8_T)tag[3];
		}
	}
	*length = l;
	return n;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: serverBACnet
 * Purpose: 
 * Params:   
 * Returns:
 * Note:  it is called back in ServerTransactionStateMachine
 * ----------------------------------------------------------------------------
 */
S16_T serverBACnet( TSMTable *ptrtable )
{
	BACnetObjectIdentifier obj;
	T3000PropertyIdentifier property;
	U16_T i;
	union
	{
		long little_indian;
  		S8_T big_indian[4];
  	} lval;

 	if( ptrtable->service==WriteProperty )
	{
/*	buf[0] = 0x0B;              /* Context Tag 0(L=3) */
		memcpy( &obj, ptrtable->asdu+1, 3);
/*	buf[4] = 0x1A;              /* Context Tag 1(L=2) */
		memcpy(&property, ptrtable->asdu+5, 2);
/*	buf[7] = 0x3E;              /* Opening Tag 3 */
		i = 8;
		switch( property )
		{
			case property_value:			
			/*			buf[l++] = 0x34;        /* Application Tag 3(L=4) */
				i++;
				lval.big_indian[3] = *(ptrtable->asdu+i);
				i++;
				lval.big_indian[2] = *(ptrtable->asdu+i);
				i++;
				lval.big_indian[1] = *(ptrtable->asdu+i);
				i++;
				lval.big_indian[0] = *(ptrtable->asdu+i);
				i++;
				writepropertyvalue( &obj, lval.little_indian ); 
				break;
			
			case property_auto_manual:			
			/*			buf[l++] = 0x31;       /* Application Tag 3(L=1) */
			i++;
			writepropertyauto( &obj, ( (S16_T)*(ptrtable->asdu+i)) );  
			i++;
			break;			
		}
/*	buf[l++] = 0x3F;           /* Closing Tag 3 */
	}
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: serverprocedure
 * Purpose: 
 * Params:   
 * Returns:
 * Note:  it is called back in ServerTransactionStateMachine
 * ----------------------------------------------------------------------------
 */
S16_T serverprocedure( TSMTable *ptrtable )
{
	U8_T comm_code;
	U16_T n, i;
	S8_T comm_type;
	
	comm_type = 0;  /* read command */
	n = 0;
	if( ptrtable->service==ConfirmedPrivateTransfer || ptrtable->service==UnconfirmedPrivateTransfer )
	{
		n += decodetag( ptrtable->asdu, &i);  /*vendorid */
		ptrtable->vendorID = ptrtable->asdu[n];
		n += i;
		n += decodetag( ptrtable->asdu+n, &i);  /*service Number */
		comm_code = ptrtable->asdu[n]; // comm_code is service Number
		if( comm_code==50 || comm_code==50+100)
		{
			/*			bank = *(unsigned S8_T*)(&NL_parameters.asdu[n+1]);
			extralow  = bank;*/
			ptrtable->arg[0] = ptrtable->asdu[n+1];
		}
		ptrtable->command = comm_code;
		/* parameters*/
		n += i;
		n += decodetag( (S8_T*)ptrtable->asdu+n, &i);   /* asdu length */
		if( comm_code!=50 && comm_code!=50+100)
		{
			memcpy(&ptrtable->arg, &ptrtable->asdu[n], 3);
		/*			bank = *(U16_T*)(&NL_parameters.asdu[n]);
		tbank = *(Bank_Type *)(&bank);
		extralow  = NL_parameters.asdu[n];
		extrahigh = NL_parameters.asdu[n+1]; */
		}
		else
		{
		/*				extrahigh = NL_parameters.asdu[n];*/
			ptrtable->arg[1] = ptrtable->asdu[n];
			ptrtable->arg[2] = ptrtable->asdu[n+2]; /* res */
		}
		
		/* end parameters*/
		if(comm_code > 100)
		{
			comm_type = 1;  /* write command*/
			comm_code -= 100;
		}
		ptrtable->start_data = n + 3;  /*return*/
		ptrtable->asdu += ptrtable->start_data;
		ptrtable->length_asdu -= ptrtable->start_data;
	}

	if( ptrtable->event == CONF_SERVindication )
	{
		switch (ptrtable->service)
		{
		 	case ConfirmedPrivateTransfer:
				server_data( ptrtable );
				if( comm_type )
				{
					ptrtable->length = 0;
		/*				if( ptrtable->accepted_length < NL_parameters.length_asdu ) )
					return REJECTrequest;	*/
				}
			 	break;
		}
		return CONF_SERVresponse;
	}
	if( ptrtable->event==UNCONF_SERVindication )
	{
		switch (ptrtable->service)
		{
		 case UnconfirmedPrivateTransfer:
		/*			ptrtable->command = 0;   /*not a usual write */
		/*			ptrtable->asdu += (n+3);*/
				server_data( ptrtable );
				break;
		}
		return 1;
	}
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: ServerTransactionStateMachine
 * Purpose: 
 * Params:   
 * Returns:
 * Note:  it is called back in TSM_task
 * 1. decode apdu
 * 2. explain Server Transaction State Machine
 * ----------------------------------------------------------------------------
 */
bit f,f2;
void ServerTransactionStateMachine( S16_T entrytimeout, S8_T *apdu,U16_T length_apdu, Protocol_parameters *ps )
{
	volatile S8_T next;
	S8_T s1, s, postponed;
	S16_T  n, l, current, STSM_Event;
	S8_T STSM_SEG, STSM_MOR, STSM_SA, STSM_MaxResp, STSM_InvokeID;
	S8_T STSM_NoSeq=1, STSM_WinSize, STSM_Service, STSM_SRV;
	S8_T STSM_State;
	UNITDATA_PARAMETERS *NL_parameters;
	TSMTable *PTRtable;
	U8_T i;

	NL_parameters = &NL_PARAMETERS[ps->port];
	
	if( entrytimeout < 0 )
	{
		if( STSMremoveflag ) return;
		STSM_Event = apdu[0]>>4;
		
	/* there are 8 BACnetPDU : */
	/*	apdu[0] apdu data type ,range is 0 ~ 15	 */
		switch ( STSM_Event )
		{			
			case BACnetConfirmedRequestPDU: // 0
			//	f2 = 1;
		/*				7		6		5		4		3		2		1		0
		PCI	  apdu[0]       PDU Type = B'0000'		   SEG		MOR		SAR 	0		 	
			  apdu[1]	0 		0		0		0			Max Resp(bit3~0)
			  apdu[2]						Invoke ID (1 byte)
						sequence Number(when SEG is 1)
						Proposed Window Size(when SEG is 1)
						service	choice

	user data			serviec requeset
		*/
			
				 STSM_SEG      = (apdu[0]&0x08)?1:0;
				 STSM_MOR      = (apdu[0]&0x04)?1:0;
				 STSM_SA       = (apdu[0]&0x02)?1:0;
				 STSM_MaxResp  = apdu[1];
				 STSM_InvokeID = apdu[2];
				 if( STSM_SEG )  STSM_NoSeq   = apdu[3];
				 if( STSM_SEG )  STSM_WinSize = apdu[4];
				 if( STSM_SEG ) { STSM_Service = apdu[5]; n=6; }
				 else           { STSM_Service = apdu[3]; n=4; }; /* n is the length of PCI*/
				 break;
			case BACnetUnconfirmedRequestPDU: // 1
		/*				7		6		5		4		3		2		1		0
		PCI	  apdu[0]       PDU Type = B'0001'		   0		0		0	 	0			
			  apdu[1]		service	choice					

	user data			serviec requeset
		*/
				 STSM_Service = apdu[1];
				 STSM_InvokeID = 255;
				 n=2;	/* n is the length of PCI*/
				 break;
			case BACnetSegmentACKPDU:  // 4
		/*				7		6		5		4		3		2		1		0
		PCI	  apdu[0]       PDU Type = B'0100'		   0		0		NAK 	SRV		 	
			  apdu[1]			original Invoke ID
			  apdu[2]		sequence Number						
			  apdu[3]		Proposed Window Size
			
		note: this type dont have USER DATA
		*/
				 STSM_SRV      = (apdu[0]&0x01)?1:0;
				 STSM_InvokeID = apdu[1];
				 STSM_NoSeq    = apdu[2];
				 STSM_WinSize  = apdu[3];
				 n=4;
				 if( STSM_SRV == TRUE )
				 {
					/*
					LengthReceivedClientAPDU = NL_parameters.length_apdu;
					PTRReceivedClientAPDU = NL_parameters.apdu;
					*/
					return;
				 }
				 break;
			 case BACnetRejectPDU: // 6

				 STSM_SRV      = (apdu[0]&0x01)?1:0;
				 STSM_InvokeID = apdu[1];
				 n=3;
				 break;
			 case BACnetAbortPDU: // 7
				 STSM_SRV      = (apdu[0]&0x01)?1:0;
				 STSM_InvokeID = apdu[1];
				 n=3;
				 break;
			default:
				 return;
		}	
/* check if the status of the current InvokeID is iliegal */
/* TSM_lookid --- put "NL_PARAMETERS" to "Server_TSM_table" */

		if( ( current = TSM_lookid( NL_parameters, STSM_InvokeID, 0 ) ) == STSM_ILLEGAL )
		{	
			PTRtable = Server_TSM_table;
			for( i=0; i<MAXServerTSMTable; i++, PTRtable++ )
				PTRtable->state = STSM_ILLEGAL;		
			return;   /* reject PDU */
		}

		if ( ServerTSM_flag == current )
		{	
		
		 	return;
		}
		Server_TSM_table[current].port = ps->port;
 	}
	else
	{
		current = entrytimeout;
		/*
		ps = &Port_parameters[Server_TSM_table[current].port];
		ps->port = Server_TSM_table[current].port;
		*/
	}
	ServerTSM_flag = current;
	PTRtable = &Server_TSM_table[current];
	
	if(entrytimeout < 0)
	{
		PTRtable->asdu = &apdu[n];   // PTRtable->asdu -- user data
		PTRtable->length_asdu = length_apdu - n;  // PTRtable->length_asdu -- length of the user data
		PTRtable->apdu = apdu;    // added by chelsea
	}
	if( PTRtable->state >= 16 )
	{
		if( PTRtable->state >= 32 )
		{
			PTRtable->state -= 32;
			entrytimeout=-1;
			postponed=1;
			STSM_Event = CONF_SERVresponse;
			
			s1=STSM_IDLE;			
		}
		else
		{
		 	PTRtable->state = STSM_IDLE;			
		}
	}
	STSM_State = PTRtable->state;
	next = 1;
	while(next)
	{ /* STSM_State : STSM_IDLE, STSM_SEGMENTING_REQUEST,STSM_AWAIT_RESPONSE, STSM_SEGMENTING_RESPONSE 
		the following is Service Status Machine */
		switch ( STSM_State )
		{
			case STSM_IDLE:
				if( PTRtable->timeout<=0 && entrytimeout>=0	)
				{     /* something wrong */
					if( PTRtable->special )
						server_data( PTRtable );
					TSM_free( current, 0, 0 );
					STSM_State=STSM_IDLE;
					next=0;
	/*				PTRtable->reject = 0;*/					
					break;
				}
				if (STSM_Event == BACnetAbortPDU )
				{
					TSM_free( current, 0, 0 );
					STSM_State=STSM_IDLE;
					next=0;
	/*				PTRtable->reject = 0;*/
					break;
				}
				
				/*	receive BACnetUnconfirmedRequestPDU from network layer, send UNCONF_SERVindication primitive to application,
				then go to idle status.	*/
				if (STSM_Event == BACnetUnconfirmedRequestPDU)
				{ 
					PTRtable->event = UNCONF_SERVindication; // send UNCONF_SERVindication primitive to application
					PTRtable->service = STSM_Service;
					STSM_Event = serverprocedure( PTRtable );
					
					if( PTRtable->command == 100+20 )
	        		{
						if( PTRtable->accepted_length >= PTRtable->length )
						{
								write_received_frame( PTRtable );
						}
	        		}
					TSM_free( current, 0, 0 );
					next=0;
					break;
				}
				/*	receive Unsegment BACnetConfirmedRequestPDU from network layer, send UNCONF_SERVindication primitive to application,
				then go to idle status.	*/
				
				if (STSM_Event == BACnetConfirmedRequestPDU && STSM_SEG == FALSE)
				{	
			 		if( STSM_Service == ConfirmedPrivateTransfer )
       				{
				// enter			
						PTRtable->event = CONF_SERVindication;
						PTRtable->service = STSM_Service;
						STSM_Event = serverprocedure( PTRtable );
						
						if(STSM_Event != CONF_SERVresponse )
						{
							STSM_State=STSM_IDLE;
							PTRtable->state = STSM_IDLE;
							break;
						}
						if( PTRtable->command < 100 )
						{                 /* reading */
							STSM_State = STSM_AWAIT_RESPONSE;
							s1 = STSM_IDLE;
						}
						else
						{    				 /* writing */
/*
					PTRtable->asdu += PTRtable->start_data;
					PTRtable->length_asdu -= PTRtable->start_data;
*/							
					// enter
							PTRtable->total_length = PTRtable->length_asdu;
							if( PTRtable->accepted_length >= ( PTRtable->length + PTRtable->length_asdu ) )
							{
								if( !PTRtable->special )
								{
									
									write_received_frame( PTRtable );
								}
								else
								{
									
									server_data( PTRtable );
								
								}
								STSM_Event = CONF_SERVresponse;
								STSM_State=STSM_AWAIT_RESPONSE;
								s1=STSM_SEGMENTING_REQUEST;
								PTRtable->reject = 1;
								
							}
							else
							{//  delete it by chelsea for test 
								STSM_Event = BACnetAbortPDU;
								STSM_State = STSM_IDLE;
							  	PTRtable->timeout = 300;
								s1=STSM_IDLE;
								PTRtable->reject = 1;
								break;
							}
							PTRtable->length_asdu = 0;
							if( PTRtable->special )
								server_data( PTRtable );
							PTRtable->special = 0;
						} // end PTRtable->command > 100 
						
						break;
       				}// end STSM_Service == ConfirmedPrivateTransfer 
					else
					{	
						PTRtable->service = STSM_Service;
						STSM_Event = serverBACnet( PTRtable );
						PTRtable->apci[0] = (BACnetSimpleACKPDU<<4);
						PTRtable->apci[1] = STSM_InvokeID;
						PTRtable->apci[2] = STSM_Service;
						PTRtable->length_apci = 3;
		        		PTRtable->length_asdu = 0;
						PTRtable->asdu = NULL;
					  	PTRtable->data_expecting_reply = BACnetDataNotExpectingReply;
	/*
						n = BACnetDataNotExpectingReply;
						networklayer( N_UNITDATArequest, NORMALmessage, network, source, destination,
													NULL, 0, apci, length_apci, n);
	*/					
					  	NL_unitdata_req( ps, PTRtable );
						
	/*					ServerTSMTable.free(  current);  */
						TSM_free( current, 0, 0 );
						
						next = 0;
						break;
	       			}// end STSM_Service != ConfirmedPrivateTransfer 
				}//end if (STSM_Event == BACnetConfirmedRequestPDU && STSM_SEG == FALSE)
	/*
				if (Event == Conf_req PDU with segmented_msg=TRUE
				{                              more_follows=TRUE)
					if(able to accept segment)
					{
					send SegmentACK PDU with server=TRUE
					STSM_State=STSM_SEGMENTED_REQUEST;
					}
					if(not able to accept segment)
					{
					send Abort PDU with server=TRUE
					STSM_State=STSM_IDLE;
					}
				}
	*/
				if(STSM_Event == BACnetConfirmedRequestPDU && STSM_SEG == TRUE && STSM_MOR==TRUE)
				{
					PTRtable->windowsize=STSM_WinSize;
					PTRtable->event = CONF_SERVindication;
					PTRtable->service = STSM_Service;
					STSM_Event = serverprocedure( PTRtable );
					if(STSM_Event != CONF_SERVresponse )
					{
						STSM_State = STSM_IDLE;
						s1=STSM_IDLE;
						break;
					}
	/*
					PTRtable->asdu += PTRtable->start_data;
					PTRtable->length_asdu -= PTRtable->start_data;
	*/				
					PTRtable->total_length = mGetPointWord2(*( (U16_T *)PTRtable->asdu));  // the length is U16_T, must inverse high byte and low byte
									
					PTRtable->asdu += 2;
					PTRtable->length_asdu -= 2;
					if( PTRtable->accepted_length >=  PTRtable->total_length)
					{
						if( PTRtable->accepted_length >= ( PTRtable->length + PTRtable->length_asdu ) )
						{
							if( !PTRtable->special )
							{	
								write_received_frame( PTRtable );
							}
							else
								server_data( PTRtable );
						}
						PTRtable->length_asdu = 0;
					}
					else
					{
						STSM_State=STSM_IDLE;
						PTRtable->state = STSM_IDLE;
						STSM_Event = BACnetAbortPDU;
						PTRtable->reject = 1;
						break;
					}
					if(++PTRtable->nosegment >= PTRtable->windowsize)
					{
						 PTRtable->apci[0] = (BACnetSegmentACKPDU<<4)|1;  //  test
						 PTRtable->apci[1] = STSM_InvokeID;
						 PTRtable->apci[2] = PTRtable->noseq;
						 PTRtable->apci[3] = PTRtable->windowsize;
						 PTRtable->apci[4] = 0x21;            /* Application Tag 2( Unsigned, Length=1)*/
						 PTRtable->apci[5] = PTRtable->vendorID;
						 PTRtable->apci[6] = 0x22;            /* Application Tag 2( Unsigned, Length=2)*/
						 PTRtable->apci[7] = PTRtable->command;
						 PTRtable->apci[8] = *((U8_T*)&PTRtable->arg);
						 PTRtable->length_apci = 9;
						 PTRtable->timeout  = 470;
						 PTRtable->retrycount = 0;
						 PTRtable->data_expecting_reply = BACnetDataNotExpectingReply;
						 PTRtable->asdu = NULL;
						 PTRtable->length_asdu = 0;
						
						 NL_unitdata_req( ps, PTRtable ); // create NPDU
						 
						 PTRtable->nosegment=0;
					}
					STSM_State=STSM_SEGMENTING_REQUEST;
					PTRtable->state = STSM_SEGMENTING_REQUEST;
					PTRtable->reject = 1;
			
					next=0;
					break;
				}
				if( STSM_Event == REJECTrequest )
				{
					PTRtable->apci[0] = (BACnetRejectPDU<<4);
					PTRtable->apci[1] = STSM_InvokeID;
					PTRtable->apci[2] = 0;
					PTRtable->length_apci = 3;
					PTRtable->asdu = NULL;
					PTRtable->length_asdu = 0;
					NL_unitdata_req( ps, PTRtable );
					TSM_free( current, 0, 0 );
/*					PTRtable->reject = 1;*/
					next=0;
					break;
				}
				if( STSM_Event == ReplyPostponed )
				{			
					PTRtable->length_apci = 0;
					if( (Routing_table[ps->port].status & RS485_ACTIVE ) == RS485_ACTIVE )
					{
						PTRtable->data_expecting_reply = ReplyPostponed;
	/*					PTRtable->apci = NULL;*/
						PTRtable->asdu = NULL;
						PTRtable->length_asdu = 0;
						NL_unitdata_req( ps, PTRtable );
					}
					PTRtable->state = STSM_AWAIT_RESPONSE+16;
					next=0;
					PTRtable->reject = 1;
					break;
				}
	/*
				if (Event == Abort PDU)
				{
					discard PDU
					STSM_State=STSM_IDLE;
				}
	*/
	/*
				if (Event == SegmentACK PDU)
				{
					send Abort PDU with server=TRUE
					STSM_State=STSM_IDLE;
					next=0;
				}
	*/
				if( STSM_Event == BACnetSegmentACKPDU || STSM_Event == BACnetAbortPDU )
				{					
					
					PTRtable->apci[0] = (BACnetAbortPDU<<4)|1;  //
					PTRtable->apci[1] = STSM_InvokeID;
					PTRtable->apci[2] = INVALIDAPDUINTHISSTATE;
					PTRtable->length_apci = 3;
	
					PTRtable->data_expecting_reply = BACnetDataNotExpectingReply;
					PTRtable->asdu = NULL;
					PTRtable->length_asdu = 0;
					NL_unitdata_req( ps, PTRtable );
					TSM_free( current, 0, 0 );
					next=0;
					break;
				}		
				next = 0;				
				break;  // end case STSM_IDLE
	 		case STSM_SEGMENTING_REQUEST:
/*			if (Event == Conf_req PDU with segmented_msg=TRUE
			{                              more_follows=TRUE)
				if(able to accept segment)
				{
				send SegmentACK PDU with server=TRUE
				}
				if(not able to accept segment)
				{
				send Abort PDU with server=TRUE
				STSM_State=STSM_IDLE;
				}
			}
*/
/*
			if (Event == Conf_req PDU with segmented_msg=TRUE
			{                              more_follows=FALSE)
				send SegmentACK PDU with server=TRUE
				send CONF_SERV.indication
				STSM_State=STSM_IDLE;
			}
*/
			#if 1 // maybe delete it 
			if	(PTRtable->timeout<=0 && entrytimeout>=0	)
			{     /*timeout*/
				if( PTRtable->special )
					server_data( PTRtable );
				PTRtable->special = 0;
				TSM_free( current, 0, 0 );
				STSM_State=STSM_IDLE;
				next=0;
/*				PTRtable->reject = 0;*/
				break;
			}
			#endif
			if (STSM_Event == BACnetAbortPDU )
			{
				TSM_free( current, 0, 0 );
				STSM_State=STSM_IDLE;
				next=0;
/*				PTRtable->reject = 0;*/
				break;
			}
			
			if (STSM_Event == BACnetConfirmedRequestPDU && STSM_SEG == TRUE)  // tested by chelsea
			{
				
				if( STSM_NoSeq < PTRtable->noseq-(PTRtable->nosegment?PTRtable->nosegment-1:PTRtable->windowsize-1) || STSM_NoSeq > PTRtable->noseq+1)
				{
					next=0;
					break;
				}
/*
				if( STSM_NoSeq < PTRtable->noseq || STSM_NoSeq > PTRtable->noseq+1)
				{
				 next=0;
				 break;
				}
*/
        		s=0;
/*
				if( STSM_NoSeq == PTRtable->noseq-(PTRtable->nosegment?PTRtable->nosegment-1:PTRtable->windowsize-1 ) )   // client resent last segment(s)
				{
				 PTRtable->data -= PTRtable->last_length;
				 PTRtable->length -= PTRtable->last_length;
				 PTRtable->nosegment = 0;
				 PTRtable->last_length = 0;
				}
*/
				if( STSM_NoSeq == PTRtable->noseq )    /* client resent last segment(s)*/
				{
			        if(PTRtable->noseq==1)    /* resent first segment*/
					{
						PTRtable->special = 0;
						
						STSM_Event = serverprocedure( PTRtable );
						if(STSM_Event != CONF_SERVresponse )
						{
							STSM_State = STSM_IDLE;
							s1=STSM_IDLE;
							break;
						}
						PTRtable->asdu += 2;             /* data length - in first segment*/
						PTRtable->length_asdu -= 2;
			           	s=1;
					}
					else
			        {
						PTRtable->dat -= PTRtable->last_length;
						PTRtable->length -= PTRtable->last_length;
			        }
					PTRtable->nosegment = 0;
					PTRtable->last_length = 0;
				}

				if( STSM_NoSeq == PTRtable->noseq+1 && !PTRtable->nosegment ) /* next segment*/
					 PTRtable->last_length = 0;
				PTRtable->noseq = STSM_NoSeq;
        		if(!s)
				{
					 n = decodetag( PTRtable->asdu, (U16_T*)&l);  /*vendorid*/
					 n += l;
					 n += decodetag( PTRtable->asdu+n, (U16_T*)&l);  /*service*/
					 n += l;
					 n += decodetag( PTRtable->asdu+n, (U16_T*)&l);
					 PTRtable->asdu += n;   /*asdu length*/
					 PTRtable->length_asdu -= n;
        		}
				if( PTRtable->accepted_length >= ( PTRtable->length + PTRtable->length_asdu ) )
				{
					if( !PTRtable->special )
					{
						write_received_frame( PTRtable );
					}
					else
						server_data( PTRtable );
				}
				else
				{
					STSM_Event = BACnetAbortPDU;
					STSM_State = STSM_IDLE;
					s1 = STSM_IDLE;
					PTRtable->reject = 1;
					break;
				}
				PTRtable->length_asdu = 0;
/*				execservice( current );*/
        		if(!s)
				 	if( PTRtable->special )		server_data( PTRtable );
				if(STSM_MOR==TRUE)
				{
					if(++PTRtable->nosegment >= PTRtable->windowsize)
					{
						PTRtable->apci[0] = (BACnetSegmentACKPDU<<4)|1;
						PTRtable->apci[1] = STSM_InvokeID;
						PTRtable->apci[2] = PTRtable->noseq;
						PTRtable->apci[3] = PTRtable->windowsize;
						PTRtable->apci[4] = 0x21;            /* Application Tag 2( Unsigned, Length=1) */
						PTRtable->apci[5] = PTRtable->vendorID;
						PTRtable->apci[6] = 0x22;            /* Application Tag 2( Unsigned, Length=2)*/
						PTRtable->apci[7] = PTRtable->command;
						PTRtable->apci[8] = *((U8_T*)&PTRtable->arg);
						PTRtable->length_apci = 9;
						PTRtable->timeout = 470;
						PTRtable->retrycount = 0;
						PTRtable->data_expecting_reply = BACnetDataNotExpectingReply;
						PTRtable->asdu = NULL;
						PTRtable->length_asdu = 0;
						NL_unitdata_req( ps, PTRtable );
						PTRtable->nosegment = 0;
					}
				 	next=0;
				}
				else
				{
				 PTRtable->special = 0;
				 STSM_Event = CONF_SERVresponse;
				 
				 STSM_State=STSM_AWAIT_RESPONSE;
				 s1=STSM_SEGMENTING_REQUEST;
				}
				break;
			}
/*
			if (Event == Abort PDU)
			{
				send ABORT.indication
				STSM_State=STSM_IDLE;
			}
*/
/*
			if (unexpected PDU from client)
			{
/*         send Abort PDU with server = TRUE*/
/*				STSM_State=STSM_IDLE;
				next=0;
			}
*/
			next = 0;
			break;  // end case  STSM_SEGMENTING_REQUEST
	 case STSM_AWAIT_RESPONSE:
/*			if (STSM_Event == CONF_SERV.response(+))
				if(APDU <= max_APDU_length_supported)
				{
				 send Simple_ACK PDU or
				 send Complex_ACK PDU with
						segmented_msg = FALSE
				 STSM_State=STSM_IDLE;
				}
				if(APDU > max_APDU_length_supported)
				{
				 send Complex_ACK PDU with
						segmented_msg = TRUE
						more_follows = TRUE
				 STSM_State=STSM_SEGMENTING_RESPONSE;
				}
*/
			if	(PTRtable->timeout<=0 && entrytimeout>=0	)
			{     /*timeout*/
				TSM_free( current, 0, 0 );
				STSM_State=STSM_IDLE;
				next=0;
/*				PTRtable->reject = 0;*/
				break;
			}
			if (STSM_Event == BACnetAbortPDU )
			{ /* receive abortPDU , go to idle*/
				TSM_free( current, 0, 0 );
				STSM_State=STSM_IDLE;
				next=0;
/*				PTRtable->reject = 0;*/
				break;
			}
			if (STSM_Event == CONF_SERVresponse)
			{
				if( s1 == STSM_IDLE )
				{				 
				 buildservice( PTRtable );
				 if(PTRtable->length)
					PTRtable->apci[0] = (BACnetComplexACKPDU<<4)|0x0c;
				 else
					PTRtable->apci[0] = (BACnetComplexACKPDU<<4)|0x08;
				 PTRtable->apci[1] = STSM_InvokeID;
				 PTRtable->apci[2] = PTRtable->noseq++;
				 PTRtable->apci[3] = PTRtable->windowsize;
				 PTRtable->apci[4] = STSM_Service;
				 PTRtable->apci[5] = 0x21;    /* Application Tag 2( Unsigned, Length=1)*/
				 PTRtable->apci[6] = PTRtable->vendorID;
				 PTRtable->apci[7] = 0x22;    /* Application Tag 2( Unsigned, Length=2)*/
				 PTRtable->apci[8] = PTRtable->command;
				
			//	if(PTRtable->command == 1) 
			//			PTRtable->apci[8] = 3;	
			//	if(PTRtable->command == 3) 
			//			PTRtable->apci[8] = 1;

				 PTRtable->apci[9] = (U8_T)PTRtable->arg[0];
				 if(PTRtable->length)
				 {
					n = 10+encodetag(0, 6,	&PTRtable->apci[10], PTRtable->length_asdu+2+PTRtable->para_length);
					l = PTRtable->length+PTRtable->length_asdu;
					memcpy(&PTRtable->apci[n], &l, 2);
					PTRtable->length_apci = n+2;
				 }
				 else
				 {
					PTRtable->length_apci = 10+encodetag(0, 6, &PTRtable->apci[10], PTRtable->length_asdu+PTRtable->para_length);
				 }
				 if( PTRtable->add_para )
				 {
					 memcpy( &PTRtable->apci[PTRtable->length_apci], PTRtable->para.string, PTRtable->para_length );
					 PTRtable->length_apci += PTRtable->para_length;
/*						 PTRtable->para_length = 0;
					 PTRtable->add_para = 0;*/
				 }
				 /*compressed in one frame*/
/*
				 if( PTRtable->compressed )
				 {
					if( !PTRtable->length)
					{
					 PTRtable->apci[0] = (BACnetSimpleACKPDU<<4);
					 PTRtable->apci[1] = STSM_InvokeID;
					 PTRtable->apci[2] = STSM_Service;
					 PTRtable->apci[3] = 0x21;   /* Application Tag 2( Unsigned, Length=1)*/
/****
					 PTRtable->apci[4] = PTRtable->vendorID;
					 PTRtable->apci[5] = 0x22;   /* Application Tag 2( Unsigned, Length=1)*/
/****
					 PTRtable->apci[6] = PTRtable->command;
					 PTRtable->apci[7] = (U8_T)PTRtable->arg[0];
					 n = 8+encodetag(0, 6, &PTRtable->apci[8], PTRtable->last_length);
					 PTRtable->length_apci = n+2;
					 n = BACnetDataNotExpectingReply;
					 s=STSM_IDLE;
					}
				 }
************/
				 n = BACnetDataNotExpectingReply;
				 if( PTRtable->length )
				 {
					STSM_Event = BACnetSegmentACKPDU;
					STSM_SRV = FALSE;
					PTRtable->timeout = 220;
					PTRtable->retrycount = 0;
					PTRtable->reject = 1;
					s = STSM_SEGMENTING_RESPONSE;
			
				 }
				 else
					 s=STSM_IDLE;
				}
				else
				{
					PTRtable->apci[0] = (BACnetSimpleACKPDU<<4);
					PTRtable->apci[1] = STSM_InvokeID;
					PTRtable->apci[2] = STSM_Service;
					PTRtable->apci[3] = 0x21;            /* Application Tag 2( Unsigned, Length=1)*/
					PTRtable->apci[4] = PTRtable->vendorID;
					PTRtable->apci[5] = 0x22;            /* Application Tag 2( Unsigned, Length=1)*/
					
					PTRtable->apci[6] = PTRtable->command;
					PTRtable->apci[7] = (U8_T)PTRtable->arg[0];
					PTRtable->length_apci = 8;
					PTRtable->length_asdu = 0;
					PTRtable->asdu = NULL;
					n = BACnetDataNotExpectingReply;
					s=STSM_IDLE;
				}
				PTRtable->data_expecting_reply = n;
				NL_unitdata_req( ps, PTRtable );
				PTRtable->nosegment++;
				STSM_State = s;

				if( s == STSM_IDLE )
				{
					TSM_free( current, 0, 0 );
					STSM_State=STSM_IDLE;
				/*				PTRtable->reject = 0;*/
				}
				else
				{
					PTRtable->state = s;
				}
				break;
			}
/*
			if (CTSM_Event == CONF_SERV.response(-))
			{
				send Error PDU
				STSM_State=STSM_IDLE;
			}
*/
/*
			if (CTSM_Event == AbortPDU)
			{
				send ABORT.indication
				STSM_State=STSM_IDLE;
			}
*/
/*
			if (unexpected PDU from client)
			{
				 send Abort PDU with server = TRUE
				STSM_State=STSM_IDLE;
			}
*/
/*
			if (timeout waiting for PDU)
			{
				send Abort PDU with server = TRUE
				STSM_State=STSM_IDLE;
			}
*/
			next = 0;
			break; //end case STSM_AWAIT_RESPONSE
	 case STSM_SEGMENTING_RESPONSE:
/*       if (timeout waiting for PDU)
			{
				if(retry count not exceed )
				{
				 resend previous ComplexACK PDU segment(s)
				}
				if(retry count exceed )
				{
				STSM_State=STSM_IDLE;
				next=0;
				}
			}
*/
			if	(PTRtable->timeout<=0 && entrytimeout>=0	)/*timeout waiting for PDU*/
			{                            		 
				if(	PTRtable->retrycount++ < 1 )  /*retry count not exceed*/
				{   
					/* resend previous ComplexACK PDU segment(s) */                            
					TSM_resetsegments( PTRtable );
					while( ++PTRtable->nosegment <= PTRtable->windowsize && STSM_State==STSM_SEGMENTING_RESPONSE)
					{
					 	if(PTRtable->length)
					 	{
							buildservice( PTRtable );
		/*					if(PTRtable->length > MAXASDUSIZE)*/
							if(PTRtable->length )
								PTRtable->apci[0] = (BACnetComplexACKPDU<<4)|0x0c;
							else
								PTRtable->apci[0] = (BACnetComplexACKPDU<<4)|0x08;

								PTRtable->apci[1] = PTRtable->invokeID;
								PTRtable->apci[2] = PTRtable->noseq++;
								PTRtable->apci[3] = PTRtable->windowsize;
								PTRtable->apci[4] = PTRtable->service;
								PTRtable->apci[5] = 0x21;            /* Application Tag 2( Unsigned, Length=1)*/
								PTRtable->apci[6] = PTRtable->vendorID;
								PTRtable->apci[7] = 0x22;            /* Application Tag 2( Unsigned, Length=1)*/
								PTRtable->apci[8] = PTRtable->command;
								PTRtable->apci[9] = (U8_T)PTRtable->arg[0];
							if( PTRtable->noseq == 2 )
							{
								n = 10+encodetag(0, 6,	&PTRtable->apci[10], PTRtable->length_asdu+2);
								l = PTRtable->length + PTRtable->length_asdu;
								memcpy(&PTRtable->apci[n], &l, 2);
								PTRtable->length_apci = n+2;
							}
							else
							{
								n = 10+encodetag(0, 6, &PTRtable->apci[10], PTRtable->length_asdu);
								PTRtable->length_apci = n;
							}
							if( PTRtable->add_para )
							{
							 	memcpy( &PTRtable->apci[PTRtable->length_apci], PTRtable->para.string, PTRtable->para_length );
							 	PTRtable->length_apci += PTRtable->para_length;
			/*					PTRtable->para_length = 0;
							 	PTRtable->add_para = 0; */
							}
							PTRtable->timeout = 220;
							PTRtable->data_expecting_reply = BACnetDataNotExpectingReply;
							NL_unitdata_req( ps, PTRtable );
					 	}
						else       /* no more APDU segments */
						{
							TSM_free( current, 0, 0 );
							STSM_State=STSM_IDLE;
						/*					PTRtable->reject = 0;*/
						}
					}
					PTRtable->nosegment = 0;
				}
				else                             /* retry count exceed */
				{
					TSM_free( current, 0, 0 );
					STSM_State=STSM_IDLE;
				/*				PTRtable->reject = 0;*/
				}
				next=0;
				break;
			}
			if( entrytimeout >=0 )
			{
			 	next=0; break;
			}
			if (STSM_Event == BACnetAbortPDU )
			{
				TSM_free( current, 0, 0 );
				STSM_State=STSM_IDLE;
				next=0;
/*				PTRtable->reject = 0;*/
				break;
			}
			
			/*if (STSM_Event != BACnetSegmentACKPDU )	
			{
				print_dat(STSM_Event);
			}*/	
			
			if (STSM_Event == BACnetSegmentACKPDU && STSM_SRV==FALSE)
			{
				PTRtable->para_length = 0;
				PTRtable->add_para = 0;
			 	if(PTRtable->nosegment == 0 )		PTRtable->last_length = 0;
			 	while( ++PTRtable->nosegment <= PTRtable->windowsize && STSM_State == STSM_SEGMENTING_RESPONSE )
			 	{
					if(PTRtable->length)
					{
						buildservice( PTRtable );
	/*				if(PTRtable->length > MAXASDUSIZE)*/
						if(PTRtable->length)
							 PTRtable->apci[0] = (BACnetComplexACKPDU<<4)|0x0c;
						else
							 PTRtable->apci[0] = (BACnetComplexACKPDU<<4)|0x08;
						PTRtable->apci[1] = PTRtable->invokeID;
						PTRtable->apci[2] = PTRtable->noseq++;
						PTRtable->apci[3] = PTRtable->windowsize;
						PTRtable->apci[4] = PTRtable->service;
						PTRtable->apci[5] = 0x21;            /* Application Tag 2( Unsigned, Length=1)*/
						PTRtable->apci[6] = PTRtable->vendorID;
						PTRtable->apci[7] = 0x22;            /* Application Tag 2( Unsigned, Length=1)*/
						PTRtable->apci[8] = PTRtable->command;
						PTRtable->apci[9] = (U8_T)PTRtable->arg[0];
						n = 10+encodetag(0, 6,	&PTRtable->apci[10], PTRtable->length_asdu);
						PTRtable->length_apci = n;
						PTRtable->timeout = 220;
						PTRtable->retrycount = 0;
						PTRtable->data_expecting_reply = BACnetDataNotExpectingReply;
						NL_unitdata_req( ps, PTRtable );
					}
					else       /* no more APDU segments*/
					{
						TSM_free( current, 0, 0 );
						STSM_State=STSM_IDLE;
	/*					PTRtable->reject = 0;*/
					}
			 	}
				PTRtable->nosegment = 0;
				next = 0;
				break;
			}
/*
			if( Abort PDU with server = FALSE)
			{
				 send ABORT.indication
/*			    STSM_State=STSM_IDLE;*/
/*				 next=0;
			}
*/
/*
			if (unexpected PDU from client)
			{
/*         send Abort PDU with server = TRUE*/
/*				STSM_State=STSM_IDLE;
				next=0;
			}
*/
				next = 0;
				break;  // end STSM_SEGMENTING_RESPONSE
	 		default:
			TSM_free( current, 0, 0 );
			STSM_State=STSM_IDLE;
			next=0;
/*			PTRtable->reject = 0;*/
			break;
		} /* end switch*/
 	}  /* end while */
	ServerTSM_flag = -1;
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: checkTSMtimeout
 * Purpose: check timeout of TSM
 * Params:   
 * Returns:
 * Note:  1. it is used in TSM_task
 *			2. it is used in ServerTransactionStateMachine
 * ----------------------------------------------------------------------------
 */
S16_T checkTSMtimeout( S16_T update_timeout )
{
	S16_T i, n;
	register TSMTable *PTRtable;
	
	n = 10000;
	PTRtable = Server_TSM_table;
	
	for( i=0; i<MAXServerTSMTable; i++, PTRtable++ )
	{
		if( PTRtable->state != STSM_ILLEGAL )
		{
			if( PTRtable->timeout < n )		n = PTRtable->timeout;
		}
	}
	if( update_timeout > 0 )
	{
		if( n != 10000 )
		{
		  	PTRtable = Server_TSM_table;
			for( i=0; i<MAXServerTSMTable; i++, PTRtable++ )
			{
				if( PTRtable->state != STSM_ILLEGAL )
				{
					PTRtable->timeout -= n;
		      		if( PTRtable->timeout < 0 ) PTRtable->timeout = 0 ;
				}
			}
	  		n=0;
		}
	}
	return n;
}


void SPI_Roution(void);
void Update_InputLed(void);
void control_logic( void );
extern bit flag_int;
/*
 * ----------------------------------------------------------------------------
 * Function Name: checkTSMtimeout
 * Purpose: Server TSM task
 * Params:   
 * Returns:
 * Note:  
 * ----------------------------------------------------------------------------
 */
void ServerTSM_task( void )
{
	S16_T i, n;
  	TSMTable *PTRtable;  
	portTickType xDelayPeriod = ( portTickType ) 200 / portTICK_RATE_MS;
	static char count = 0;
	static char count1 = 0;
	PTRtable = Server_TSM_table;
	for( i=0; i<MAXServerTSMTable; i++, PTRtable++ )
		PTRtable->state = STSM_ILLEGAL;

/*  PTRtable = Client_TSM_table;
	for( i=0; i<MAXClientTSMTable; i++, PTRtable++ )
		PTRtable->state = STSM_ILLEGAL;*/
	//vTaskSuspend(xHandleSeverTSM);
	for( ; ; ) 
	{
	//	if(flag_int) return;
		vTaskDelay(xDelayPeriod);

		/*
		
		communicated with top board task 
		
		*/

		SPI_Roution();
		Update_InputLed();
		control_logic();
#if 0
		PTRtable = Server_TSM_table;
		STSMremoveflag=1;
		n = checkTSMtimeout( 1 );
		STSMremoveflag=0;	
		
		if(!n)
		{
			for( i=0; i<MAXServerTSMTable; i++, PTRtable++ )
			{
				
				STSMremoveflag=1;
			//	ServerTransactionStateMachine( i, NULL, 0, &Port_parameters[PTRtable->port] );
				#if 1
				if( PTRtable->state != STSM_ILLEGAL )
				{
					if( PTRtable->timeout <= 0 )
					{
						PTRtable->reply_flag = 0;
						//if(PTRtable->flag_TSM == 0)
						{
						//f_test = 0;
						
							
						ServerTransactionStateMachine( i, NULL, 0, &Port_parameters[PTRtable->port] );
						//PTRtable->flag_TSM = 1;
						}
					}
				}
				#endif
				STSMremoveflag=0;
		 	}
			
			STSMremoveflag=1;
		 	n = checkTSMtimeout( -1 );
			STSMremoveflag=0;
		}
				
#endif		
	//	if (n>0) break;
		
	}
}


#endif