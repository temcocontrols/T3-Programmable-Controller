/**********************************************************************

						COM port housekeeping routines

**********************************************************************/

#define _COM_AUX_DOT_C

#include "reg80390.h"
#include "base_str.h"
#include "bacnet.h"
#include "control.h"
#include "const.h"
#include "basic.h"
#include <stdio.h>
#include <string.h>
#include "projdefs.h"
#include "portable.h"
#include "errors.h"
#include "task.h"
#include "list.h"
#include "queue.h"
#include "minitask.h"
#include "data.h"
#include "point.h"
#include "mstp.h"
#include "ptp.h"
#include "int.h"


xTaskHandle Handle_PTP_TRANSMISSION_0;
xTaskHandle Handle_PTP_RECEPTION_0;
xTaskHandle Handle_PTP_CONNECTION_0;
xTaskHandle Handle_RS485_DATA_0;
xTaskHandle Handle_PTP_TRANSMISSION_1;
xTaskHandle Handle_PTP_RECEPTION_1;
xTaskHandle Handle_PTP_CONNECTION_1;
xTaskHandle Handle_RS485_DATA_1;


#define MHz24_576

/*
 * ----------------------------------------------------------------------------
 * Function Name: empty_routine
 * Purpose: 
 * Params:   
 * Returns:
 * Note:  
 * ----------------------------------------------------------------------------
 */
void empty_routine( void )
{
// tbd: changed by chelsea
// suspend the current task
#if 0
	U8_T task;

	task = current_task();

	while( 1 )
	{
		suspend( task );
	}
#endif
}


void async0_task( void )
{
	int i;

	i = comm_info[0].prg_number;

	while( 1 )
	{
	// TBD: changed by chelsea
	vTaskDelay(( portTickType ) 100 / portTICK_RATE_MS);
	//	msleep(100);
	}
}

void async1_task( void )
{
	int i;

	i = comm_info[1].prg_number;

	while( 1 )
	{
/*
		run program
*/
/*
		if( i )
		{
			if( programs[i-1].bytes )
			{
				if( program_address[i-1] )
				{
					if( programs[i-1].on_off )
					{
						exec_program( i-1, program_address[i-1], 1 );
					}
				}
			}
		}
*/
	// TBD: changed by chelsea
	vTaskDelay(( portTickType ) 100 / portTICK_RATE_MS);
	//	msleep(100);
	}
}

void set_baudrate( S16_T port )
{
	U8_T control_code;

	switch( comm_info[port].baudrate )
	{
#ifdef MHz12_288
		case 1200:
			control_code = BAUD12;
			break;
		case 2400:
			control_code = BAUD24;
			break;
		case 4800:
			control_code = BAUD48;
			break;
		case 9600:
			control_code = BAUD96;
			break;
		case 19200:
			control_code = BAUD192;
			break;
		case 38400L:
			control_code = BAUD384;
			break;
		case 57600L:
			control_code = BAUD576;
			break;
		case 76800L:
			control_code = BAUD768;
			break;
		default:
			control_code = BAUD96;
			break;
#endif
#ifdef MHz24_576
		case 1200:
			control_code = BAUD06;
			break;
		case 2400:
			control_code = BAUD12;
			break;
		case 4800:
			control_code = BAUD24;
			break;
		case 9600:
			control_code = BAUD48;
			break;
		case 19200:
			control_code = BAUD96;
			break;
		case 38400L:
			control_code = BAUD192;
			break;
		case 57600L:
			control_code = BAUD576_2;
			break;
		case 76800L:
			control_code = BAUD384;
			break;
		case 115200L:
			control_code = BAUD1152;
			break;
		default:
			control_code = BAUD48;
			break;
#endif
	}
	char_period[port] = 1000000L / comm_info[port].baudrate;						/* the result is in 1/100 milisec*/
	if( !port )
	{

#if 0 // tbd: changed by chelsea
		BRGC  = control_code; /* set serial port 0 to the new baudrate */
#endif
	}
	else
	{
#if 0 // tbd: changed by chelsea

		BRGC2 = control_code; /* set serial port 0 to the new baudrate */

#endif
	}
}


void reset_tx_port( S16_T port )
{
	if( port )
	{
		Port_parameters[1].tx_end = 1;
		Port_parameters[1].tx_wake_up = 0xff;
#if 0 // tbd: changed by chelsea
		P3 &= 0x0F7;   /* enable RS485 receiver P3.3 - T/R_EN_1 = 0*/
		STIC2 = 0x43;
#endif
	}
	else
	{
		Port_parameters[0].tx_end = 1;
		Port_parameters[0].tx_wake_up = 0xff;
#if 0 //tbd: changed by chelsea

		P3 &= 0x0FB; /*enable RS485 receiver - P3.2 - T/R_EN_0 = 0*/
		STIC = 0x43;
#endif
	}
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: init_communication_structures
 * Purpose: initial 
 * Params:   
 * Returns:
 * Note:  
 * ----------------------------------------------------------------------------
 */
void init_communication_structures( void )
{
	int i;
	Protocol_parameters *ptr;
  	FRAME_ENTRY *pframe;

  /* check for  comm_info's integrity  */
	if( comm_info[0].media_type != RS485_LINK && comm_info[0].media_type != SERIAL_LINK && comm_info[1].media_type != RS485_LINK && comm_info[1].media_type != SERIAL_LINK)
  	{
  		comm_info[0].media_type = RS485_LINK;
		comm_info[0].baudrate = 19200;
  	}
	switch( comm_info[0].baudrate )
	{
		case   300:
		case  1200:
		case  2400:
		case  4800:
		case  9600:
		case 19200:
		case 38400:
		case 57600:		break;
		default:	  	comm_info[0].baudrate = 19200; 	break;
	}
  	switch( comm_info[1].baudrate )
	{
		case   300:
		case  1200:
		case  2400:
		case  4800:
		case  9600:
		case 19200:
		case 38400:
		case 57600:    	break;
		default:		comm_info[1].baudrate = 19200; 	break;
			
	}

	memset( SendFrame, 0, sizeof( FRAME_ENTRY )* MAX_SEND_FRAMES );
	pframe= &SendFrame[0];
	for( i=0; i<MAX_SEND_FRAMES; i++, pframe++ )
  		pframe->number = i;

  	Using_send_frame = 0;

	set_baudrate( 0 );
	set_baudrate( 1 );
	memset( Routing_table, '\x0', MAX_Routing_table*sizeof( Routing_Table ) );
	memset( NL_PARAMETERS, '\x0', 2*sizeof( UNITDATA_PARAMETERS ) );
	NL_PARAMETERS[0].primitive = DL_INVALID;
	NL_PARAMETERS[1].primitive = DL_INVALID;

	memset( Port_parameters, '\x0', 2*sizeof( Protocol_parameters ) );

	ptr = &Port_parameters[0];

	for( i=0; i<2; i++, ptr++ )
	{
		ptr->port = i;
		if( comm_info[i].media_type == RS485_LINK )
		{
			ptr->link_type = RS485_LINK;
			if( !i )
			{
				ptr->base_task = RS485_DATA_0;
      		}
			else
			{
				ptr->base_task = RS485_DATA_1;
      		}
		}
		else
		{
			ptr->link_type = SERIAL_LINK;
			if( !i )
			{
				ptr->base_task = PTP_RECEPTION_0;
      		}
			else
			{
				ptr->base_task = PTP_RECEPTION_1;
      		}
		}
		if( !i )
				ptr->rec_frame = &ReceiveFrame_0;
		else
				ptr->rec_frame = &ReceiveFrame_1;

		ptr->tx_end = 1;
		ptr->tx_wake_up = 0x0ff;

		ptr->PTP_DLE_mask = 0x0FF;
		ptr->reception_blocked = Q_NOT_BLOCKED;
		ptr->receive_frame_free = 1;
		ptr->send_frame_free = 1;
		ptr->transmission_blocked = 1;

		ptr->PTP_transmission_state = TR_IDLE;
		ptr->PTP_reception_state = REC_IDLE;
		ptr->PTP_connection_state = DISCONNECTED;
		ptr->Rec_frame_state = RX_IDLE;
		ptr->rec_trigger_sequence = 0;
		ptr->MSTP_MASTER_state = MSTP_MASTER_IDLE;
	}
	password_needed = 0;
}

void activate_com1( void )
{


}

void activate_com2( void )
{



}

void deactivate_com1( void )
{


}

void deactivate_com2( void )
{




}


S16_T outputd( S8_T* adr, S16_T num, S16_T port)
{
	Protocol_parameters *ps;
	S32_T time;

	if( num > MAXFRAMEBUFFER )		num = MAXFRAMEBUFFER;

	if( port != COM0 )
	{
		ps = &Port_parameters[port];
		time = num;
		time *= char_period[ps->port];
		time *= 10;  /*  5 times more than is needed */
		time /= 100;  /* milisec per total no of S8_Ts */
		time++; /* up rounding */
		ps->SendFrameTimer = time + 1;
		time /= 50; /* number of ticks */
		ps->tx_end = 0;
		
// tbd: changed by chelsea
// dont understand 		
	#if 0  
		if( time )
			ps->tx_wake_up = current_task();
		else
			ps->tx_wake_up = 0x0ff;

		if( port == COM1 )
		


			tx1_macro_init( adr, num );

		else

			tx2_macro_init( adr, num );


		if( time )
		{
			msleep( time + 1 );
		//	vTaskDelay(time + 1); 
			while( tasks[ps->tx_wake_up].sleep && !ps->tx_end )
				msleep( tasks[ps->tx_wake_up].sleep );
		}
		else
			while( !ps->tx_end && ps->SendFrameTimer );

		if( !ps->tx_end )
		{
			reset_tx_port( ps->port );
		}
	#endif
	}
	return num;
}

void reset_active_panels( S16_T n, Protocol_parameters *ps )
{
	if( n > 32 )	return;
	ps->need_info &= ~( 1L << ( n - 1 ) );
	if( n < 9 )
		panel_net_info.active_panels[0] &= ~active_panel[n-1];
	else if( n < 17 )
		panel_net_info.active_panels[1] &= ~active_panel[n-9];
	else if( n < 25 )
		panel_net_info.active_panels[2] &= ~active_panel[n-17];
	else if( n < 33 )
		panel_net_info.active_panels[3] &= ~active_panel[n-25];

	memset(&station_list[n-1],0,sizeof(Station_point));
/*
	station_list[n-1].state = 0;
	station_list[n-1].des_length = 0;
	station_list[n-1].panel_type = 0;
	station_list[n-1].version=0;
*/
}

void init_active_panels( void )
{
	memset( panel_net_info.active_panels, 0 , 4 );
/*  set_active_panel( Station_NUM );*/
	if( Station_NUM < 9 )
		panel_net_info.active_panels[0] |= active_panel[Station_NUM-1];
	else if( Station_NUM < 17 )
		panel_net_info.active_panels[1] |= active_panel[Station_NUM-9];
	else if( Station_NUM < 25 )
		panel_net_info.active_panels[2] |= active_panel[Station_NUM-17];
	else
		panel_net_info.active_panels[3] |= active_panel[Station_NUM-25];
	memset( station_list, 0 , sizeof(station_list) );
 	strcpy(station_list[Station_NUM-1].name,panel_net_info.panel_name);
  	station_list[Station_NUM-1].state = 1;
	station_list[Station_NUM-1].panel_type = MINI_T3000;
  	station_list[Station_NUM-1].des_length = panel_net_info.desc_length;
  	station_list[Station_NUM-1].version = panel_net_info.version_number;
  	memcpy( station_list[Station_NUM-1].tbl_bank,table_bank,TABLE_BANK_LENGTH);
}


void rs_485_task_0( void )
{
	Routing_table[0].Port.network = panel_net_info.network_number;
	Routing_table[0].Port.address = Station_NUM;
	Routing_table[0].status = RS485_ACTIVE;
	MSTP_Master_node( 0 );
}


void rs_485_task_1( void )
{
	Routing_table[1].Port.network = panel_net_info.network_number;
	Routing_table[1].Port.address = Station_NUM;
	Routing_table[1].status = RS485_ACTIVE;
	MSTP_Master_node( 1 );
}


