/*
the source code have so many bits defintion, Asix chip only have 128bit,
so change the old definition to current one.
*/

#include "bacnetflag.h"



void SetWordBit(unsigned int* c,unsigned int vb,unsigned char pos,char len)   
{
	unsigned int  temp,i;
	for(i = pos;i < pos + len;i++)
	{
		temp = 0x01;
		temp <<= i;

		if(vb & ((0x01) << (i - pos)))//set /*/*(bit)*/*/ 
		{	
			*c |= temp;
		}
		else
		{//clear /*/*(bit)*/*/
			temp = ~temp ;	 
			*c &= temp ;
		}
	}
}

unsigned int GetWordBit(unsigned int c,unsigned char pos,unsigned char len)   
{
	unsigned int  temp1,temp2,i;
	temp1 = temp2 = i = 0;
	for(i = pos;i < len + pos;i++)
	{
		temp1 = 0x01;
		temp1 <<= i;
		temp2 += temp1; 
	}
	temp2 = temp2 & c;
	temp2 >>= pos;
	return temp2;
}

void SetByteBit(unsigned char* c,unsigned char vb,unsigned char pos,char len)   
{
	unsigned int  temp,i;
	for(i = pos;i<pos + len;i++)
	{
		temp = 0x01;
		temp <<= i;
		if(vb & ((0x01) << (i - pos)))//set /*/*(bit)*/*/ 
		{	
			*c |= temp;
		}
		else
		{//clear /*/*(bit)*/*/
			temp = ~temp ;	 
			*c &= temp ;
		}
	}
}

unsigned char GetByteBit(unsigned char c,unsigned char pos,unsigned char len)   
{
	unsigned char  temp1,temp2,i;
	temp1 = temp2 = i = 0;
	for(i = pos;i < len + pos;i++)
	{
		temp1 = 0x01;
		temp1 <<= i;
		temp2 += temp1; 
	}
	temp2 = temp2 & c;
	temp2 >>= pos;
	return temp2;
}

