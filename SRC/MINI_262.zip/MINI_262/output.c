#include "base_str.h"


void Initial_Output(void)
{

}

void
