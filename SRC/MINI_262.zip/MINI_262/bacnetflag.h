
#include "types.h"




/* Point_info */

typedef enum
{
	info_auto_manual = 0,		/* 0=auto, 1=manual*/
	info_digital_analog = 1,		/* 0=digital, 1=analog*/
	info_description_label = 2,	/* 0=display description, 1=display label*/
	info_security = 5,			/* 0-3 correspond to 2-5 access level*/
	info_decomisioned = 7		/* 0=normal, 1=point decommissioned*/
}Point_info_flag;

typedef enum
{
	out_auto_manual = 0, 		/* (1 bit; 0=auto, 1=manual)*/
	out_digital_analog = 1,  	/* (1 bit; 0=digital, 1=analog)*/
	out_access_level = 2, 		/* (3 bits; 0-5)*/
	out_control = 5,     		/* (1 bit; 0=off, 1=on)*/
	out_digital_control = 6,	/* (1 bit)*/
	out_decom = 7				/* (1 bit; 0=ok, 1=point decommissioned)*/
}Str_out_point_flag;

typedef enum
{
	in_filter = 0,				/* (3 bits; 0=1,1=2,2=4,3=8,4=16,5=32, 6=64,7=128,)*/
	in_decom = 3,				/* (1 bit; 0=ok, 1=point decommissioned)*/
	in_sen_on = 4,  			/* (1 bit)*/
	in_sen_off = 5,  			/* (1 bit)*/
	in_control = 6, 			/*  (1 bit; 0=OFF, 1=ON)*/
	in_auto_manual = 7 		/* (1 bit; 0=auto, 1=manual)*/

}Str_in_point_flag1;

typedef enum
{
	in_digital_analog = 0, 	/* (1 bit; 1=analog, 0=digital)*/
	in_calibration_sign = 1,	/* (1 bit; sign 0=positiv 1=negative )*/
	in_calibration_increment = 2,/* (1 bit;  0=0.1, 1=1.0)*/
	in_unused = 3  			/* (5 bits - spare )*/

}Str_in_point_flag2;


typedef enum
{
	var_auto_manual = 0,  		/*  (1 bit; 0=auto, 1=manual)*/
	var_digital_analog = 1, 	/*  (1 bit; 1=analog, 0=digital)*/
	var_control = 2,  			/* 3 bits	*/
	var_unused	= 5, 			/* 3 bits	*/

}Str_variable_point_flag; 


typedef enum
{
	con_auto_manual = 0, 		/* (1 bit; 0=auto, 1=manual)*/
	con_action = 1, 			/* (1 bit; 0=direct, 1=reverse)*/
	con_repeats_per_min = 2, 	/* (1 bit; 0=repeats/hour,1=repeats/min)*/
	con_unused = 3, 			/* (1 bit)	*/
	con_prop_high = 4 			/* (4 bits; high 4 bits of proportional bad)*/

}Str_controller_point_flag;


typedef enum
{
	weekly_value = 0,  			/* (1 bit; 0=off, 1=on)*/
	weekly_auto_manual = 1,  		/* (1 bit; 0=auto, 1=manual)*/
	weekly_override_1_value = 2,  	/* (1 bit; 0=off, 1=on)*/
	weekly_override_2_value = 3,  	/* (1 bit; 0=off, 1=on)*/
	weekly_off = 4,
	weekly_unused = 5, 			/* (11 bits)*/
} Str_weekly_routine_point_flagInt; 


typedef enum
{
	annual_value = 0,				/* (1 bit; 0=off, 1=on)*/
	annual_auto_manual = 1,  		/* (1 bit; 0=auto, 1=manual)*/
	annual_unused = 2				/* ( 12 bits)*/

}Str_annual_routine_point_flagInt; 


typedef enum
{
	prg_on_off = 0,				/* (1 bit; 0=off; 1=on)*/
	prg_auto_manual	= 1,		/* (1 bit; 0=auto; 1=manual)*/
	prg_com_prg = 2,			/* (1 bit; 0=normal use, 1=com program)*/
	prg_errcode	= 3				/* (1 bits; 0=normal end, 1=too S32_T in program)*/

}Str_program_point_flag;



typedef enum
{
	mon_num_inputs = 0, 		/* total number of points */
	mon_an_inputs = 4,	 		/* number of analog points */

}Str_monitor_point_flag1; 

typedef enum
{
	mon_unit = 0, 				/* 2 bits - minutes=0, hours=1, days=2	*/
	mon_ind_views = 2, 			/* number of views */
	mon_wrap_flag = 4,			/* (1 bit ; 0=no wrap, 1=data wrapped)*/
	mon_status	= 5,			/* monitor status 0=OFF / 1=ON */
	mon_reset_flag	= 6, 		/* 1 bit; 0=no reset, 1=reset	*/
	mon_double_flag	= 7 		/* 1 bit; 0= 4 bytes data, 1= 1(2) bytes data */
}Str_monitor_point_flag2; 



typedef enum
{
	monaux_priority = 0, 			/* 1-low, 2-medium, 3-high */
	monaux_start = 1, 				/* 1 bit	*/
	monaux_saved = 2, 				/* 1 bit	*/
	monaux_active =3 				/* 1 bit - 0=inactive, 1=active	*/

}Mon_aux_flag; 	


typedef enum
{				
	Monitor_Block_monitor	= 0, 			/* monitors' number */
	Monitor_Block_no_points = 4			/* number of points in block */
}Monitor_Block_flag1;


typedef enum
{
	Monitor_Block_priority = 0, 			/* 0-block empty, 1-low, 2-medium, 3-high */
	Monitor_Block_first_block = 2, 		/* 1 - this block is the first in the chain */
	Monitor_Block_last_block = 3, 		/* 1 - this block is the last in the chain */
	Monitor_Block_analog_digital = 4, 	/* 0 - analog, 1 - digital */
	Monitor_Block_block_state  = 5, 		/* 0 = unused, 1 = used */
	Monitor_Block_fast_sampling  = 6, 	/* 0 = normal sampling 1 = fast sampling */
	Monitor_Block_wrap_around    = 7 		/* 1 - wrapped  */
}Monitor_Block_flag2;


typedef enum
{
    Monitor_Block_last_digital_state = 0,  /* 14 bits */
    Monitor_Block_not_used           = 14
}Monitor_Block_flag3Int;




typedef enum
{
	Monitor_Block_Header_monitor	  = 0, 			/* monitors' number */
	Monitor_Block_Header_no_points    = 4 		/* number of points in block */
}Monitor_Block_Header_flag1;


typedef enum
{
	Monitor_Block_Header_priority = 0, 			/* 0-block empty, 1-low, 2-medium, 3-high */
	Monitor_Block_Header_first_block = 2, 		/* 1 - this block is the first in the chain */
	Monitor_Block_Header_last_block  = 3, 		/* 1 - this block is the last in the chain */
	Monitor_Block_Header_analog_digital = 4, 	/* 0 - analog, 1 - digital */
	Monitor_Block_Header_block_state = 5, 		/* 0 = unused, 1 = used */
	Monitor_Block_Header_fast_sampling   = 6, 	/* 0 = normal sampling 1 = fast sampling */
	Monitor_Block_Header_wrap_around     = 7 	/* 1 - wrapped  */
} Monitor_Block_Header_flag2;	

typedef enum
{
   Monitor_Block_Header_last_digital_state  = 0,		//14bits
   Monitor_Block_Header_not_used  = 14
}Monitor_Block_Header_flag3Int;


typedef enum
{
	Monitor_element_digital_analog  = 0,  	/* 0-analog monitor, 1-digital monitor*/
	Monitor_element_unused = 1,				/* 3 bits */
	Monitor_element_two_or_4_bytes = 4,  	/* 0=2 bytes per analog sample, 1=4 bytes*/
	Monitor_element_not_used = 5			/* 3 bits */
}Monitor_element_flag;



typedef enum
{
	totalizer_digital_analog = 0,   	/* 0-digital monitor, 1-analog monitor */
	totalizer_active = 1,				/* 1=ACTIVE, 0=INACTIVE */
	totalizer_reset = 2,				/* 1=RESET, 0=DON'T CARE */
	totalizer_last_state  = 3,		/* 1=ON, 0=OFF */
	totalizer_rate   = 4,				/* 2bis */
	totalizer_unused  = 6,			/* 2bis */
}Str_totalizer_point_flag;



typedef enum
{
	grp_auto_manual	  = 0,		/* 0=auto, 1=manual*/
	grp_digital_analog = 1,		/* 0=digital, 1=analog*/
	grp_description_label  = 2,	/* 0=display description, 1=display label*/
	grp_security	 = 5,  		/* 0-3 correspond to 2-5 access level*/
	grp_decomisioned	 = 7	/* 0=normal, 1=point decommissioned*/
}Str_grp_element_flag1;


typedef enum
{
	grp_show_point = 0,		   	/* 1 bits */
	grp_icon_name_index = 1		/* 7 bits */
}Str_grp_element_flag2;


typedef enum
{
	grp_graphic_y_coordinate = 0,/* 10 bis */
	grp_off_low_color = 10,		 /* 4 bits */
	grp_type_icon = 14,	         /* 2 bits */
}Str_grp_element_flag3Int;

typedef enum
{
	grp_graphic_x_coordinate = 0,	/* 10 bits */
	grp_on_high_color = 10,			/* 4 bits */
	grp_display_point_name = 14,	/* 1 bit */
	grp_default_icon	= 15		/* 1 bit */
}Str_grp_element_flag4Int;

typedef enum
{
	grp_text_x_coordinate = 0,    /* 7 bits */
	grp_modify = 7,               /* 1 bit */
	grp_absent = 8,               /* 1 bit 1 = absent 0= present */
	grp_location = 9,             /* 2 bits  where is located Local or Remote */
	grp_text_y_coordinate = 11    /* 5 bits */
}Str_grp_element_flag5Int;

typedef enum
{
	grp_xicon   = 0,         		/* 10 bits */
	grp_text_place = 10,			/* 4 bits */
	grp_text_present = 14,			/* 1 bit */
	grp_icon_present = 15			/* 1 bit */
}Str_grp_element_flag6Int;

typedef enum
{
	grp_yicon   = 0,          		/* 10 bits */
	grp_text_size = 10,				/* 2 bits */
	grp_normal_color = 12	  		/* 4 bits */
}Str_grp_element_flag7Int;




typedef enum
{
	group_mode  = 0,     				/* 1 bit text / graphic */
	group_xcur_grp	 = 1			/* 15 bits */
}Control_group_point_flagInt;

typedef enum
{
	alarm_modem = 0,     	 /* 1 bit */
	alarm_printer	= 1,	 /* 1 bit */
	alarm_alarm = 2,			/* 1 bit */
	alarm_restored = 3,   /* 1 bit */
	alarm_acknowledged = 4,/* 1 bit */
	alarm_ddelete	= 5,	   /* 1 bit */
	alarm_type = 6,        /* 2 bit */
	
}Alarm_point_flag1;

typedef enum
{
	alarm_cond_type = 0,   /* 4bit */
	alarm_level = 4        /* 4bit */
}Alarm_point_flag2;


typedef enum
{
	alarm_panel_type = 0,    /* 4bit */
	alarm_dest_panel_type = 4 /* 4bit */
}Alarm_point_flag3;


typedef enum
{
	alarm_where_state1 = 0,	      /* (1 bit ; panel# to send alarm to, 255 = all)	*/
	alarm_where_state2 = 1,	      /* (1 bit ; panel# to send alarm to, 255 = all)	*/
	alarm_where_state3 = 2,	      /* (1 bit ; panel# to send alarm to, 255 = all)	*/
	alarm_where_state4 = 3,	      /* (1 bit ; panel# to send alarm to, 255 = all)	*/
	alarm_where_state5 = 4,	      /* (1 bit ; panel# to send alarm to, 255 = all)	*/
	alarm_change_flag  = 5,			/* 2 bits */
	alarm_original     = 7			/* 1 bit */
}Alarm_point_flag4;



typedef enum
{
	alarmstr_modem   = 0,   		/* 1 bit */
	alarmstr_printer = 1, 	 	/* 1 bit */
	alarmstr_screen  = 2, 		/* 1 bit */
	alarmstr_restored = 3,    	/* 1 bit */
	alarmstr_acknowledged = 4 	/* 1 bit */
}Alarm_struct_flag;



typedef enum
{
	REMOTE_auto_manual	 = 0,  		/* 1 bit 0=auto, 1=manual*/
	REMOTE_digital_analog	 = 1,  	/* 1 bit 0=digital, 1=analog*/
	REMOTE_description_label = 2, 	/* 3 bit 0=display description, 1=display label*/
	REMOTE_security	    = 5,  	/* 2 bit 0-3 correspond to 2-5 access level*/
	REMOTE_decomisioned = 7		/* 1 bit 0=normal, 1=point decommissioned*/
}REMOTE_POINTS_flag1;

typedef enum
{
	REMOTE_read = 0,			/* 2 bit */
	REMOTE_write = 2,			/* 2 bit */
	REMOTE_read_write = 4,	    /* 2 bit */
	REMOTE_change	= 6,		/* 2 bit */
}REMOTE_POINTS_flag2;



typedef enum
{
	NETWORK_auto_manual	 = 0, 		/* 1 bit 0=auto, 1=manual */
	NETWORK_digital_analog = 1, 	/* 1 bit 0=digital, 1=analog */
	NETWORK_description_label= 2, 	/* 3 bit 0=display description, 1=display label */
	NETWORK_security = 5, 			/* 2 bit 0-3 correspond to 2-5 access level */
	NETWORK_decomisioned = 7		/* 1 bit 0=normal, 1=point decommissioned */
}NETWORK_POINTS_flag;





