#include "types.h"

S16_T generatealarm(S8_T *mes, S16_T prg, S16_T panel, S16_T type, S8_T alarmatall,S8_T indalarmpanel,S8_T *alarmpanel,S8_T printalarm);
S32_T operand(S8_T **buf, U8_T *local);
S32_T veval_exp(U8_T *local, S16_T port);
U32_T popS32_T(void);
void pushS32_T(U32_T value);
S16_T phone(S8_T *message, S16_T n);
S16_T	print(S8_T *message);
void alarm(void);
S16_T	handup(void);
S16_T	call(void);
S16_T declare(void);
void dalarm(void);
void dalarmrestore(S8_T *mes, S16_T prg, S16_T panel);
void check_totalizers( void );
void push(S32_T value);
S32_T pop(void);
S16_T exec_program(S16_T current_prg, U8_T *prog_code, S16_T port);
S16_T get_ay_elem(S32_T *value, S8_T *local);
S32_T getvalelem(S32_T l, S32_T c, unsigned S8_T *local);
S32_T localvalue(unsigned S8_T *p, unsigned S8_T *local);
void put_local_var(unsigned S8_T *p, S32_T value, unsigned S8_T *local);
S16_T put_local_array(unsigned S8_T *p, S32_T value, S32_T v1, S32_T v2, unsigned S8_T *local );


