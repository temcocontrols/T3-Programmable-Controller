#ifdef _RX_INT_DOT_C

#define _RX_INT_DOT_C

void handle_PTP_rx_interrupt( void  );
void handle_MSTP_rx_interrupt( void );
void handle_PTP_rx_err_interrupt( void );
void handle_MSTP_rx_err_interrupt( void );
void handle_async_rx_interrupt( void );
void handle_async_rx_err_interrupt( void );


#endif

