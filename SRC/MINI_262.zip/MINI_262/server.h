#include "bacnet.h"


void write_received_frame( TSMTable *PTRtable );
void server_data( TSMTable *PTRtable );
void update_local_list( S8_T *prg_code, TSMTable *PTRtable );

//void infodatacommand( TSMTable *PTRtable );
void TSM_UpdateMonitor( TSMTable *PTRtable);
void TSM_ReadMonitor( TSMTable *PTRtable);



