#include "base_str.h"


void Initial_Input(void)
{
	
}


