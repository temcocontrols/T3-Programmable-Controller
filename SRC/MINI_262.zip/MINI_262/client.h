#include "types.h"

S16_T ClientTransactionStateMachine( ServicePrimitive Primitive,S8_T *dat, U16_T *data_length, Protocol_parameters *ps,S16_T destination, S16_T command, S16_T arg, S8_T bytearg);
