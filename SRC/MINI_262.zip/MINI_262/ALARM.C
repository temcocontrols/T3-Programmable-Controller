#define _ALARM_TASK_C

#if 0

#include "base_str.h"
#include "bacnet.h"
#include "basic.h"
#include "data.h"
#include "control.h"
#include "point.h"
#include "client.h"




int sendalarm(int arg, Alarm_point *ptr, int t)
{
 Protocol_parameters *ps;
 U16_T  i;
 int ret=0;
   	  ps = &Port_parameters[0];
			i = sizeof(Alarm_point);
			if(	ptr->where1==255 )
			{
				if( !ptr->where_state1 || t )
				{
/*					net_call(SEND_ALARM_COMMAND+100, arg, (char *)ptr, &i, 255, panel_net_info.network, BACnetUnconfirmedRequestPDU|NETCALL_NOTTIMEOUT);*/
          ClientTransactionStateMachine( UNCONF_SERVrequest,(char *)ptr, &i, ps, 255, SEND_ALARM_COMMAND+100, arg, 0);
					ptr->where_state1=1;
				}
			}
/*
			else
			{
			 if( ptr->where1 && !t )
			 {
				if( arg || !ptr->where_state1 )
				 if( panel_net_info.active_panels&(1<<(ptr->where1-1)) )
				 {
					if( net_call(SEND_ALARM_COMMAND+100, arg, (char *)ptr, &i, ptr->where1, panel_net_info.network, NETCALL_NOTTIMEOUT)==SUCCESS )
					 ptr->where_state1=1;
					else
					 ret=1;
				 }
				 else
					 ret=1;
				i = sizeof(Alarm_point);
				if( ptr->where2 )
				 if( arg || !ptr->where_state2 )
					if( panel_net_info.active_panels&(1<<(ptr->where2-1)) )
					{
					 if( net_call(SEND_ALARM_COMMAND+100, arg, (char *)ptr, &i, ptr->where2, panel_net_info.network, NETCALL_NOTTIMEOUT)==SUCCESS )
						 ptr->where_state2=1;
					 else
						ret=1;
					}
					else
					 ret=1;
				i = sizeof(Alarm_point);
				if( ptr->where3 )
				 if( arg || !ptr->where_state3 )
					if( panel_net_info.active_panels&(1<<(ptr->where3-1)) )
					{
					 if( net_call(SEND_ALARM_COMMAND+100, arg, (char *)ptr, &i, ptr->where3, panel_net_info.network, NETCALL_NOTTIMEOUT)==SUCCESS )
						 ptr->where_state3=1;
					 else
						ret=1;
					}
					else
					 ret=1;
				i = sizeof(Alarm_point);
				if( ptr->where4 )
				 if( arg || !ptr->where_state4 )
					if( panel_net_info.active_panels&(1<<(ptr->where4-1)) )
					{
					 if( net_call(SEND_ALARM_COMMAND+100, arg, (char *)ptr, &i, ptr->where4, panel_net_info.network, NETCALL_NOTTIMEOUT)==SUCCESS )
						 ptr->where_state4=1;
					 else
						ret=1;
					}
					else
					 ret=1;
				i = sizeof(Alarm_point);
				if( ptr->where5 )
				 if( arg || !ptr->where_state5 )
					if( panel_net_info.active_panels&(1<<(ptr->where5-1)) )
					{
					 if( net_call(SEND_ALARM_COMMAND+100, arg, (char *)ptr, &i, ptr->where5, panel_net_info.network, NETCALL_NOTTIMEOUT)==SUCCESS )
						 ptr->where_state5=1;
					 else
						ret=1;
					}
					else
					 ret=1;
			 }
			}
*/
 return ret;
 }


/* alarmtask(void) */
void misc_task(void)
{
 int j,ret, ret1, retry;
 U16_T  i;
 char alf;
 Alarm_point *ptr;
 Protocol_parameters *ps;
 ret = 0;
 ret1 = 0;

#ifdef TBD
 EI();
#endif


 ps = &Port_parameters[0];
 while(1)
 {

	alf = 0;
	while(1)
	{
	 if(ret1 || new_alarm_flag)
	 {
		alf |= new_alarm_flag;
		new_alarm_flag = 0;
    ret1 = 0;
		retry = 3;
		while(retry)
		{
		 alf |= new_alarm_flag;
		 ret = 0;
		 ptr = alarms;
		 for(j=0;j<MAX_ALARMS;ptr++,j++)
		 {
			if(	ptr->alarm_panel==Station_NUM )
			{
			 if( ptr->alarm )
			 {
				if( !ptr->restored && !ptr->acknowledged )
				{
				 if( alf == 0x04 )
				 {
						ret |= sendalarm(0, ptr, 1);
				 }
				 else
					ret |= sendalarm(0, ptr, 0);
        }
			 }
			 else
			 {
				if( alf&0x02 )
				{
				 if( ptr->ddelete )
				 {
					 if( sendalarm(1, ptr, 0) )  /*delete alarm*/
					 {        /*error*/
						 ret |= 1;
					 }
					 else   /*success*/
						 ptr->ddelete = 0;
				 }
				}
			 }
			}
			else
			{           /* sent to the panel originated from*/
			 if( alf&0x02 || alf&0x01 )
			 {
				i = sizeof(Alarm_point);
				if( ptr->alarm )
				{
				 if( !ptr->original )
				 {
/*
					if( net_call(SEND_ALARM_COMMAND+100, 0, (char *)ptr, &i, ptr->alarm_panel, panel_info->network, NETCALL_NOTTIMEOUT)==SUCCESS )
					{
					 ptr->original = 1;
					}
					else
*/
					{
					 if( retry==1 )
					 {
/*							 net_call(SEND_ALARM_COMMAND+100, 0, (char *)ptr, &i, 255, panel_info->network, BACnetUnconfirmedRequestPDU|NETCALL_NOTTIMEOUT);*/
        		  ClientTransactionStateMachine( UNCONF_SERVrequest,
            	  (char *)ptr, &i, ps, 255, SEND_ALARM_COMMAND+100, 0, 0);
								 ptr->original = 1;
					 }
					 else
							 ret |= 1;
					}
				 }
				}
				else
				 if( alf&0x02 )
				 {
					if( ptr->ddelete )
					{
					 if( !ptr->original )
					 {
/*
						if( net_call(SEND_ALARM_COMMAND+100, 1, (char *)ptr, &i, ptr->alarm_panel, panel_info->network, NETCALL_NOTTIMEOUT)==SUCCESS )
						{
						 ptr->original = 1;
						 ptr->ddelete = 0;
						}
						else
*/
						{
						 if( retry==1 )
						 {       /*broadcast*/
/*							 net_call(SEND_ALARM_COMMAND+100, 1, (char *)ptr, &i, 255, panel_info->network, BACnetUnconfirmedRequestPDU|NETCALL_NOTTIMEOUT);*/
        		  ClientTransactionStateMachine( UNCONF_SERVrequest,
            	  (char *)ptr, &i, ps, 255, SEND_ALARM_COMMAND+100, 1, 0);
							 ptr->original = 1;
							 ptr->ddelete = 0;
						 }
						 else
							ret |= 1;
						}
					 }
					}
				 }
			 }
			}
		 }
		 if (ret)
		 {
			retry--;
//			msleep(40);
		 }
		 else
			break;
		}  /* end while retry*/
		continue;
	 }
	 break;
	}
	if(ret)
	{
//		msleep(1200);       /*1 min*/
		ret1=1;
	}
	else
	{
/*		suspend(ALARMTASK);*/
//		msleep(5000);       /*4.5 min*/
		ret1=1;
		new_alarm_flag |= 0x04;
	}
 }
}

#endif
