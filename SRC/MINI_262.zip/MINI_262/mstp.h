#include "types.h"

void Delay( U16_T milisec, S16_T toggle );
void reset_active_panels( S16_T n, 	Protocol_parameters *ps );
S16_T MSTP_Master_node( S16_T port );
void rs_485_task_0( void );
void rs_485_task_1( void );
//		int sendpoints( Protocol_parameters *ps, int type );
/*    int sendpoints( char *asdu, char type);*/
/*		int sendinfo( int status, int panel, int dest, Protocol_parameters *ps );*/
/*    int sendinfo(char *Buffer, int status, int panel, Protocol_parameters *ps);*/
//   int sendinfo(int status, int panel, Protocol_parameters *ps);void rs_485_task_1( void );