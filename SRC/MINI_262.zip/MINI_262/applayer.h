#ifndef _APPLAYER_DOT_H

#define _APPLAYER_DOT_H				/* avoid recompilation */


//void ServerTSM_task( void );
//S16_T buildservice( TSMTable *ptrtable );
//S16_T serverprocedure( TSMTable *ptrtable );
void ServerTransactionStateMachine( S16_T entrytimeout, S8_T *apdu,U16_T length_apdu, Protocol_parameters *ps ); /*report to Netlayer.c*/
//S16_T TSM_lookid( UNITDATA_PARAMETERS *NL_parameters, U16_T id,S16_T client_server );
void TSM_free( S16_T entry, S16_T id, S16_T client_server );
void TSM_init( TSMTable *PTRtable, UNITDATA_PARAMETERS *NL_parameters );

//void TSM_resetsegments( TSMTable *PTRtable );
S16_T encodetag( S8_T cl, S8_T t, S8_T *tag, U8_T length ); /* report to mstp.c*/
//S16_T decodetag( S8_T *tag, U16_T *length );
//S16_T serverBACnet( TSMTable *ptrtable );
S16_T checkTSMtimeout( S16_T update_timeout );


#endif
