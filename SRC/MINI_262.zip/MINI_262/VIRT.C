
#include "main.h"

#ifdef BACNET 


S16_T isdelimit(S8_T c)
{
 if (strchr( "\x1\xFF\xFE" , c) )
			return 1;
	else
			return 0;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: exec_program
 * Purpose: execute program_address[i]
 * Params:
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
S16_T exec_program(S16_T current_prg, U8_T *prog_code, S16_T port)
{
	Point p_var;
	Point_Net point_net;
	S16_T val1, val2, step;
	S16_T nbytes;
	// S32_T *i_stack, *idecl_stack;
	// S16_T  ind, i, j;
	S16_T i;
	S16_T id, len, /*nprog, ndeclare ,*/nitem, lvar;
	S8_T then_else;
	S8_T ana_dig;
	S8_T *return_pointer, /**decl_prog,*/ *p_buf, *p, *q;
	U32_T r;
	U8_T type_var;
	S32_T value, v1, v2;
	U8_T *local;
	// S16_T r_ind_remote;
	Program_remote_points /**r_remote,*/ *remote_local_list;
	S16_T ind_remote_local_list;

	S32_T tempval = 0;


	then_else = alarm_flag = error_flag = 0;
	prog = (U8_T *)prog_code;
	
	if (called_program)
	{
		if (*(prog+2+3)!=DECLARE)		 return 1;
	}
	else
	 	index_stack = stack;
	
	memcpy(&nbytes, prog, 2);	
	nbytes = mGetPointWord2(nbytes);  // add by chelsea	
	prog += nbytes+2+3;

	memcpy(&nbytes, prog, 2);       /*LOCAL VARIABLES*/	
	nbytes = mGetPointWord2(nbytes);  // add by chelsea	
	local = (prog+2);

	prog += 2 + nbytes;
	memcpy(&nbytes, prog, 2);	
	nbytes = mGetPointWord2(nbytes);	// add by chelsea
	prog += 2;	
	p_buf = (S8_T*)prog + nbytes;

	time_buf = (S8_T*)prog;

	memcpy(&ind_remote_local_list,prog+nbytes,2);
	ind_remote_local_list = mGetPointWord2(ind_remote_local_list);
	remote_local_list = (Program_remote_points*)(prog+nbytes+2);
/*	memcpy(remote_local_list,prog+nbytes+2,ind_remote_local_list*sizeof(Remote_local_list));*/
	
	while( (S8_T*)prog < p_buf)
	{
		cond = (int)veval_exp( local, port );
		pn = (S32_T *)(prog+1);
		if (cond)
		{
			if(*prog++)
			{
				if(just_load) *pn = 0;
				(*pn) += miliseclast_cur;
			}
			else
			{
			 	*(prog-1) = 1;
			 	*pn = 0;
			}
		}
		else if(*prog++)
		{
		 	*(prog-1) = 0;
		 	*pn = 0;
		}
		else 
		{
			if(just_load) *pn = 0;
			(*pn) += miliseclast_cur;
		}		
	 	prog += 4;
 	}

	prog = (U8_T *)prog_code;
	p_buf = (S8_T*)prog;
	memcpy(&nbytes, prog, 2);
	nbytes = mGetPointWord2(nbytes);	// add by chelsea

	g_ind_remote_local_list = ind_remote_local_list;
//	g_remote_local_list = remote_local_list;

	p_buf += 2;
	prog += 2;

	//Test[2] = *(prog + nbytes + 1);
	prog = prog + *(prog + nbytes + 1);

	alarm_at_all = OFF;
	ind_alarm_panel = 0;
	timeout = 0;
	while(*prog!=0xfe)
	{
		
	 	if (timeout==8)
	 	{
			//programs[current_prg].errcode = 1;  tested by chelsea
			break;
	 	}
		 lvar = 0;
		 if(!then_else)
	 	{
			if (*prog!=0x01)
			{
			/*			printf("ERROR!!!!!!Virtual!!!!!!!!!!!!!!\n"); */
			/*			exit(1);*/
				return -1;
			}
			prog++;			/* step over 01*/
			/*		 memcpy(&cur_line, prog, 2);*/
			prog += 2;
	 	}
	 	else if (*prog==0x01)
		{
			then_else = 0;
			continue;
		}

 	switch (*prog++) 
		{
		case ASSIGN:
		case ASSIGNAR:
		case ASSIGNARRAY_1:
		case ASSIGNARRAY_2:
		case STARTPRG:
		case OPEN:
		case ENABLEX:
		case STOP:
		case CLOSE:
		case DISABLEX:
			id = *(prog-1);
			if (id == ASSIGN || id == ASSIGNAR)
					 ana_dig=ANALOG;
			else
					 ana_dig=DIGITAL;

			if (*prog >= LOCAL_VARIABLE && *prog <= STRING_TYPE_ARRAY)
			{
				type_var = LOCAL;
				p = prog;
				prog++;
				prog += 2;
			}
			else if (*prog == LOCAL_POINT_PRG)
			{
				  prog++;
				  type_var = LOCAL_POINT_PRG;
				  p_var = *((Point *)prog);
				  prog += sizeof(Point);
			}
			else
			{
				if (*prog == REMOTE_POINT_PRG)
				{
						prog++;
						type_var = REMOTE_POINT_PRG;
						point_net = *((Point_Net *)prog);
						prog += sizeof(Point_Net);
				}
			}
			if ( id==OPEN )
			{
				 if (type_var == LOCAL_POINT_PRG)
				 {
					if ( p_var.point_type - 1 == GRP )
					{
						*((Point *)&localopenscreen) = p_var;
						localopenscreen.panel = Station_NUM-1;
						localopenscreen.network_number = 0xFFFF;      /*NetworkAddress;*/
						break;
					}
				 }
				 if (type_var == REMOTE_POINT_PRG)
				 {
					if ( point_net.point_type - 1 == GRP )
					{
						localopenscreen = point_net;
				    break;
					}
				 }
			}
			if (id==STARTPRG || id==OPEN || id==ENABLEX) value = 1000L;
			if (id==STOP || id==CLOSE || id==DISABLEX) value = 0L;
			if (id==ASSIGN)
			{
				
				 value = veval_exp(local,port);
				 if (type_var == LOCAL)
				 {
					put_local_var(p,value,local);
				}

						
			}
			else if (id==ASSIGNARRAY_1)
			{
				v2 = 0;
				v1 = 1;
				v2 = veval_exp(local,port);
				value=veval_exp(local,port);
				put_local_array(p,value,v1,v2/1000L,local);
			}
			else if (id==ASSIGNARRAY_2)
			{
				v2 = 0;
				v1 = veval_exp(local,port);
				v2 = veval_exp(local,port);
				value=veval_exp(local,port);
				put_local_array(p,value,v1/1000L,v2/1000L,local);
			}
				else
				{
					if( id==ASSIGNAR )
					{
							ana_dig = (int)(veval_exp(local,port)/1000)-1;
							value=veval_exp(local,port);
					}
					else
					{
						 if (type_var == LOCAL)
								put_local_var(p,value,local);
					}
				}
			if (type_var == LOCAL_POINT_PRG)
			{	
			//	Test[2] = value;					
				put_point_value( &p_var, &value, ana_dig, PROGR );
			
			}
			break;
		case PHONE:
								len = *prog++;
								i=0;
								while(*prog!='\x1' && i<len) message[i++] = *prog++;
								message[i]=0;
								phone(message,i);
								break;
		case REM:
		case DIM:
		case INTEGER_TYPE:
		case BYTE_TYPE:
		case STRING_TYPE:
		case LONG_TYPE:
		case FLOAT_TYPE:
								len = *prog++;
								prog += len;
								break;
		case PRINT:
								break;
		case CLEARX:              /* clear all local variables to zero*/
	/*
								for(ind=0;ind<MAX_VAR;ind++)
										local[ind]=0;
	*/
								break;
		case CLEARPORT:
						 if( port >= 0 )
						 {
							Port_parameters[port].Length = Port_parameters[port].Index;
						 }
						 break;
		case ENDPRG:	return 1;      /* end program*/
		case RETURN:	          r = popS32_T();
								prog = (S8_T *)r;
								break;
		case HANGUP:
								handup();      /* end phone call*/
								break;
		case SET_PRINTER:
								break;
		case RUN_MACRO:
								break;
		case ON:
								nitem = veval_exp(local,port);
								if (nitem < 1 || nitem > *(prog+1))
										{
										 while(*prog!='\x1') prog++;
										 break;
										}
								if (*prog==GOSUB)   /*gosub*/
									 {
										return_pointer =  (S8_T *)prog + 2 + *(prog+1)*2;
										pushS32_T((S32_T)return_pointer);
									 }
								memcpy(&i, prog + 2 + (nitem-1)*2, 2);
								i = mGetPointWord2(i);
								prog = (U8_T *)p_buf + i - 2;
								break;
		case GOSUB:
	
								return_pointer =  (S8_T*)prog + 2 ;
								memcpy(&i, prog, 2);
								i = mGetPointWord2(i);
								prog = (U8_T *)p_buf + i - 2;
								pushS32_T((S32_T)return_pointer);
								break;
	
		case ON_ALARM:
								if (alarm_flag)
								{
									memcpy(&i, prog, 2);
									i = mGetPointWord2(i);
									prog = (U8_T *)p_buf + i - 2;
									alarm_flag=0;
								}
								else
								 prog += 2;
								break;
		case ON_ERROR:
								if (error_flag)
								{
									memcpy(&i, prog, 2);
									i = mGetPointWord2(i);
									prog = (U8_T *)p_buf + i - 2;
									error_flag=0;
								}
								else
								 	prog += 2;
								break;
		case GOTOIF:
		case GOTO:
								memcpy(&i, prog, 2);
								i = mGetPointWord2(i);
								prog = (U8_T *)p_buf + i - 2;
								
								break;
		case Alarm:
								break;
		case ALARM_AT:
								if (*prog==0xFF)
								{
									 alarm_at_all = ON;
									 prog++;
								}
								else
								{
									 while(*prog)
										 alarm_panel[ind_alarm_panel++]=*prog++;
									 prog++;
								}
								break;
								break;
		case PRINT_AT:
								if (*prog==0xFF)
								{
									alarm_at_all = ON;
									prog++;
								}
								else
								{
									while(*prog)
										 print_panel[ind_print_panel++]=*prog++;
									prog++;
								}
								break;
								break;
		case CALLB:
								break;
		case DALARM:
							 {
								alarm_flag = 0;
								cond = veval_exp(local,port);  /* condition  */
								memcpy(&value,prog,4);    /* delay time */
								value = DoulbemGetPointWord2(value);
								prog += 4;
	
								len = *prog++;
	
								if (cond)         /* test condition*/
								{
									memcpy(message, prog, len);
									message[len]=0;
									prog += len;
									if(just_load)
									{
										memcpy(prog,&value,4);
									}
									memcpy(&v1,prog,4);
									v1 = DoulbemGetPointWord2(v1);
									if( v1 > 0 )
									{
									 	v1 -= miliseclast_cur;
									 	memcpy(prog, &v1, 4);
									}
									if (v1<=0)      /* delayed time elapsed */
									{
	
									#if 0 // TBD:
								 i=generatealarm(message, current_prg+1, Station_NUM, VIRTUAL_ALARM, alarm_at_all, ind_alarm_panel, alarm_panel, 0); /*printAlarms=1*/
									#endif 
						 	 		if ( i > 0 )    /* new alarm message*/
									 {
										 alarm_flag = 1;
									 }
									}
								}
								else
								{      /* condition is false*/
									memcpy(&v1,prog+len,4);
									v1 = DoulbemGetPointWord2(v1);
									if (v1<=0)   /* test for restore*/
									{
									 memcpy(message, prog, len);
									 message[len]=0;
									 dalarmrestore(message,current_prg+1,Station_NUM);
									 new_alarm_flag |= 0x01;  /* send the alarm to the destination panels*/
									 #if 0 // TBD: 
									 resume(ALARMTASK);
									 #endif
									}
									prog += len;
									memcpy(prog,&value,4);
								}
								prog += 4;
						 }
						 break;
		case DECLARE:
								break;
		case REMOTE_GET:
							 {
							 }
							break;
	
		case REMOTE_SET:
								break;
		case FOR:
								p = prog;
								prog += 3;
								val1 = veval_exp(local,port);
								val2 = veval_exp(local,port);
								step = veval_exp(local,port);
								if(val2>=val1)
								{
								 put_local_var(p,val1,local);
								 prog += 2;
	/*											interpret(); */
								}
								else
								{
								 memcpy(&lvar, prog, 2);
								 lvar = mGetPointWord2(lvar);
								 prog = p_buf + lvar - 2;
								}
								break;
		case NEXT:
							 {
								memcpy(&lvar, prog, 2);
								lvar = mGetPointWord2(lvar);
								prog = p_buf + lvar - 2 + 4;
	          					p = prog;
								prog += 3;
								val1 = veval_exp(local,port);
								val2 = veval_exp(local,port);
								step = veval_exp(local,port);
								q = prog;
								prog = p;
								value=operand(NULL,local);    /*	veval_exp(local);*/
								value += step;
								put_local_var(p,value,local);
								prog = q;
								if(value<=val2)
								{
								 prog += 2;
								}
								else
								{
								 	memcpy(&lvar, prog, 2);
									lvar = mGetPointWord2(lvar);
								 	prog = p_buf + lvar - 2;
								}
							 }
							 break;
		case IF:
								then_else = 1;
								cond = veval_exp(local,port);
								if (cond)
								{
									prog++; prog++;
								}
								else
								{
									prog = (U8_T *)p_buf + mGetPointWord2(*((S16_T *)prog)) -2;
									if( *prog == 0x01 || *prog == 0xFE)      /*TEST DACA EXISTA ELSE*/
										then_else = 0;
								}
								break;
		case IFP:
								cond = veval_exp(local,port);
								if (cond)
								 if (!*prog++)
								 {
									*(prog-1) = 1;
									prog++; prog++;
								 }
								else
								 {
									prog = (U8_T *)p_buf + mGetPointWord2(*((S16_T *)prog)) -2;
								 }
								else
								 {
									*prog++ = 0;
									prog = (U8_T *)p_buf + mGetPointWord2(*((S16_T *)prog)) -2;
								 }
	
								then_else = 1;
								if( *prog == 0x01 || *prog == 0xFE)      /*TEST DACA EXISTA ELSE*/
									then_else = 0;
								break;
		case IFM:
								cond = veval_exp(local,port);
								if (!cond)
								 if (*prog++)
								 {
									*(prog-1) = 0;
									prog++; prog++;
								 }
								else
								 {
									prog = (U8_T *)p_buf + mGetPointWord2(*((S16_T *)prog)) -2;
								 }
								else
								 {
									*prog++ = 1;
									prog = (U8_T *)p_buf + mGetPointWord2(*((S16_T *)prog)) -2;
								 }
								then_else = 1;
								if( *prog == 0x01 || *prog == 0xFE)      /*TEST DACA EXISTA ELSE*/
									then_else = 0;
								break;
		case ELSE:
								/*prog++;
								prog = (U8_T *)p_buf + *((S16_T *)prog) -2;*/
								prog++;								
								prog = (U8_T *)p_buf + mGetPointWord2(*((S16_T *)prog)) -2;
								break;
		case WAIT:
								return_pointer = (S8_T *)prog-4;
								if (*prog==0xA1)
								{
									memcpy(&r,++prog,4);
									r = DoulbemGetPointWord2(r);
									prog += 4;
								}
								else
								{
									r = (U32_T)veval_exp(local,port);
								}
	
							    memcpy(&value,prog,4);
								value = DoulbemGetPointWord2(value);
							    value += miliseclast_cur;
							    if (value/1000L >= r)
							    {
									memset(prog,0,4);
									*((S16_T *)(p_buf + nbytes + 1))=0;
		           					timeout = 0;
							    }
							    else
							    {
									 memcpy(prog,&value,4);
									 *((S16_T *)(p_buf + nbytes + 1))=return_pointer-p_buf;
									 return 1;
							    }
							    prog += 4;
							    break;
	 	}
	}
}


void check_totalizers( void )
{
	U8_T i;
	Str_totalizer_point *ptr;
	S32_T ctime;
	S32_T l;
	ctime = time_since_1970+timestart;
	ptr = totalizers;
	for( i=0; i<MAX_TOTALIZERS; i++, ptr++ )
	{
		if( ptr->point.point_type )
		{
			if( GetByteBit(ptr->flag,totalizer_reset,1)/*ptr->reset*/ )
			{
				ptr->start_time = ctime;
			//	ptr->reset = 0;
				SetByteBit(&ptr->flag,0,totalizer_reset,1);
				ptr->value_timeon = 0;
				ptr->ratecount_OFF_ON_transitions = 0;
				ptr->time_of_last_check = ctime;
				ptr->value1 = 0;
				ptr->count  = 0;
			}
			if( GetByteBit(ptr->flag,totalizer_active,1)/*ptr->active*/ )
			{
				if( !(GetByteBit(ptr->flag,totalizer_digital_analog,1))/*ptr->digital_analog*/ )  /* digital*/
				if( GetByteBit(ptr->flag,totalizer_last_state,1)/*ptr->last_state*/ )
				{
					ptr->value_timeon += ( ctime - ptr->time_of_last_check );
				}
        		get_point_value( &ptr->point, &value );
				if( GetByteBit(ptr->flag,totalizer_digital_analog,1)/*ptr->digital_analog*/ )
				{                        /* analog*/
					if( !(GetByteBit(ptr->flag,totalizer_rate,2))/*ptr->rate*/ ) /*sec*/
					{
						ptr->value_timeon += value;
						ptr->ratecount_OFF_ON_transitions++;
					}
					else
					{
						ptr->value1 += value;
						ptr->count++;
						if( GetByteBit(ptr->flag,totalizer_rate,2) == 1 ) l = 60L;     /* min*/
						if( GetByteBit(ptr->flag,totalizer_rate,2) == 2 ) l = 3600L;   /* hour*/
						if( GetByteBit(ptr->flag,totalizer_rate,2) == 3 ) l = 86400L;  /* day*/

						if(	ctime >= ptr->time_of_last_check+l )
						{
							ptr->count *= 1000L;
							ptr->value_timeon += ((ptr->value1/ptr->count)*1000L)+
																	((ptr->value1%ptr->count)*1000L)/ptr->count;
							ptr->ratecount_OFF_ON_transitions++;
							ptr->count  = 0;
							ptr->value1 = 0;
							ptr->time_of_last_check = ctime;
						}
					}
				}
				else
				{                        /* digital*/
				 if( value )
				 {
					if( !(GetByteBit(ptr->flag,totalizer_last_state,1))/*ptr->last_state*/ )
						ptr->ratecount_OFF_ON_transitions++;
					//ptr->last_state = 1;
					SetByteBit(&ptr->flag,1,totalizer_last_state,1);
				 }
				 else
					//ptr->last_state = 0;
					SetByteBit(&ptr->flag,0,totalizer_last_state,1);
				 	ptr->time_of_last_check = ctime;
				}
			}
		}
	}
}


S32_T veval_exp(U8_T *local, S16_T port)
{
	S16_T i, m;
	S8_T *p;
	S32_T n;
	/* S32_T timer;*/
	S32_T temp1,temp2;
	Str_points_ptr sptr;
	
 	if(*prog >= LOCAL_VARIABLE && *prog <= REMOTE_POINT_PRG )
	{		
		push(operand(0,local));
	}
	
	 while( !isdelimit(*prog))         /* && code < )*/
	 {		
		switch (*prog++) {
		case PLUS:			
							push(pop() + pop());
							
							 break;
		case MINUS:
							 push(-pop() + pop());
							 break;
		case MINUSUNAR:
							 push(-pop());
							 break;
		case POW:
							 op2 = pop(); op1 = pop();
							 m = op2/1000L;
							 n = op1;
							 if(m>1)
							 {
								for(i=0;i<m-1;i++)
								 n = (n/1000L)*op1 + (n%1000L)*op1/1000L;
               				 }
							 push( n );
							 break;
		case MUL:
							 op2 = pop(); op1 = pop();
							 push( (op1/1000L)*op2 + (op1%1000L)*op2/1000L );					
							 break;
		case DIV:
							 op2 = pop(); op1 = pop();
							 if(op2==0)
									push(1000L);
							 else
								 push( (op1/op2)*1000L + ((op1%op2)*1000L)/op2 );

							 break;
		case MOD:
							 op2 = pop(); op1 = pop();
							 if(op2==0)
									push(1000L);
							 else
							 {
								 op1 = op1%op2;
								 op1 /=1000L;
								 push( op1*1000L );
							 }
							 break;
		case XOR:	
							 op2 = pop()/1000L; op1 = pop()/1000L;
							 push((op2 ^ op1)*1000L);
							 
							 break;
		case OR:
							 op1 = pop(); op2 = pop();
               				if( op1 || op2 )
								 push( 1000L );
               				else
								 push( 0 );
							 break;
		case AND:
							 op1 = pop(); op2 = pop();
			               if( op1 && op2 )
											 push( 1000L );
			               else
								 push( 0 );
							 break;
		case NOT:
							 op1 = !pop();
							 push(op1);
							 break;
		case GT:
							 op2 = pop(); op1 = pop();
							 push(op1 > op2);
							 break;
		case GE:
							 op2 = pop();
							 push(pop() >= op2);
							 break;
		case LT:
							 op2 = pop(); op1 = pop();
							 push(op1 < op2);
							 break;
		case LE:
							 op2 = pop();
							 push(pop() <= op2);
							 break;
		case EQ:
							push( pop() == pop() );
							 break;
		case NE:
							 push( pop() != pop() );
							 break;
		case ABS:
							 push(labs(pop()));
							 break;
		case LN:
/*
							 push((float)log(pop()));
*/
							 break;
		case LN_1:
/*
							 push((float)exp(pop()));
*/
							 break;
		case SQR:
/*
							 push((float)sqrt(pop()));
*/
							 break;
		case INT:
							 push( pop()/1000L * 1000L );
							 break;
		case SENSOR_ON:
							{
							 sptr.pin = &inputs[*(prog-3)];
							 pop();
							 push(( GetByteBit(sptr.pin->flag1,in_sen_on,1) ) ? 1000L : 0L );  
							 }
							 break;
		case SENSOR_OFF:
							{
							 sptr.pin = &inputs[*(prog-3)];
							 pop();
							 push( ( GetByteBit(sptr.pin->flag1,in_sen_off,1)) ? 1000L : 0L );
							 }
							 break;
		case INTERVAL:
							if(just_load)
							{
							 	n = (U32_T)pop();
							 	push(0);
							}
							else
							{
							 	memcpy(&n,prog,4);
								n= DoulbemGetPointWord2(n);
							 	n -= miliseclast_cur;
								if( n > 0 )
								{
									pop();
									push(0);
								}
							 	else
							 	{
									 if( n+miliseclast_cur == LONGTIMETEST )
									 {
										 n = (U32_T)pop();
										 push(0);
									 }
									 else
									 {
										n = (U32_T)pop();
										push(1);
									 }
								 }
							}
							memcpy(prog,&n,4);
							prog += 4;
							break;
	 	case TIME_ON: // ????????????????????????
						 //pn = (S32_T *)(time_buf+(*(S16_T *)prog));
						pn = (S32_T *)(time_buf + mGetPointWord2(*((S16_T *)prog)));
					//	Test[0] = *(pn);
					//	Test[1] = DoulbemGetPointWord2(*(pn));
					//	Test[2] = DoulbemGetPointWord2(*(pn));
						 if( *((S8_T *)pn - 1) )
							 push(*pn);
						 else
							 push(0);
						 prog += 2;
						 break;
	 	case TIME_OFF:
						 //pn = (S32_T *)(time_buf+(*(S16_T *)prog));
						pn = (S32_T *)(time_buf + mGetPointWord2(*((S16_T *)prog)));
						 if( *((S8_T *)pn - 1) )
							 push(0);
						 else
							 push(*pn);
						 prog += 2;
						 break;
	 	case TIME_FORMAT:
							 break;
		case RUNTIME:
				i = (int)pop()/1000L;
				if(!i)
				{
					push(((S32_T)miliseclast_cur)*1000l);
				}
				else
					push(0l);
				break;
	 	case Status:
				 i = (int)pop()/1000L;
				 if(i==Station_NUM)
				 {
						 if( Port_parameters[0].PTP_reception_state==Station_NUM )  /*OS==Station_NUM?*/
						 {
							push(0l);
						 }
						 else
						 {
							push(1000L);
						 }
				 }
				 else
				 {
    				memcpy(&n,&panel_net_info.active_panels[0],4);
					if( n&(1l<<(i-1)) )
						push(1000L);
					else
						push(0);
				 }
				 break;
	 case AVG:
				m = *prog++;
				value=0;
				for(i=0;i<m;i++)
					value += pop();
				push(value/m);

				
				break;
	 case MAX:
				m = *prog++;
				value=pop();
				for(i=0;i<m-1;i++)
					if((v=pop()) > value) value = v;
				push(value);
				break;
	 case MIN:
				m = *prog++;
				value=pop();
				for(i=0;i<m-1;i++)
					if((v=pop()) < value) value = v;
				push(value);
				break;
	 case CONPROP:		 break;
	 case CONRATE:		 break;
	 case CONRESET:		 break;
	 case Tbl:
				 push(1);
				 break;
	 case WR_ON:
	 case WR_OFF:
				
				 i=pop()/1000;   
				 m = ora_current.dayofweek-1;
				 if (m<0) m = 6;
				 p =(S8_T *)wr_times[(pop()/1000)-1][m].time;

				 if(*(prog-1)==WR_ON)
						 value = (S32_T)p[4*(i-1)+1]*3600L + (S32_T)p[4*(i-1)]*60L;
				 else
						 value = (S32_T)p[4*(i-1)+3]*3600L + (S32_T)p[4*(i-1)+2]*60L;
				 push(value*1000L);				 
				 
				 break;
           
		case DOM:
				value = (ora_current.day)*1000L;
				push(value);
            	break;
		case DOW:
				value = ora_current.dayofweek*1000L;
				push(value);
            	break;
		case DOY:
				value = mGetPointWord2((ora_current.day_of_year + 1)) * 1000L;
				push(value);
            	break;
		case MOY:
				value = (ora_current.month+1)*1000L;
				push(value);
            	break;
/*
					 {
						 if (*(prog-1) == DOM)
								value = (ora_current.day)*1000L;
						 if (*(prog-1) == DOW)
								value = ora_current.dayofweek*1000L;
						 if (*(prog-1) == DOY)
								value = (ora_current.day_of_year+1)*1000L;
						 push(value);
						 break;
						}
*/
		case POWER_LOSS: push(0);				 break;
		case SCANS:		 push(1);  break;  /* nr scanari pe secunda*/						 
		case SUN:		 push(0);						 break;
		case MON:		 push(1000);					 break;
		case TUE:		 push(2000);					 break;
		case WED:		 push(3000);					 break;
		case THU:		 push(4000);					 break;
		case FRI:		 push(5000);					 break;
		case SAT:		 push(6000);					 break;
		case JAN:  		 push(1000);					 break;
		case FEB:		 push(2000);					 break;
		case MAR:		 push(3000);					 break;
		case APR:		 push(4000);					 break;
		case MAYM:		 push(5000);					 break;
		case JUN:		 push(6000);					 break;
		case JUL:		 push(7000);					 break;
		case AUG:		 push(8000);					 break;
		case SEP:		 push(9000);					 break;
		case OCT:		 push(10000);					 break;
		case NOV:		 push(11000);					 break;
		case DEC:		 push(12000);					 break;
		case TIME:						
						value =  ora_current_sec;						
						push((value * 1000L));
						break;
		case USER_A:	 push(1);						 break;
		case USER_B:	 push(0);						 break;
		case UNACK:		 push(0);						 break;
		case INKEYD:
					#if 1
						 i = pop()/1000;   /* offset last S8_T */
						 m = (int)(pop()/1000);   /* nr. of S8_Ts */
						 n = pop()/1000;          /* offset */
	/*
						 if( n >= i )
							 push( -1000l );
						 else
							 push( inkey( local + n, m, i-n, port)*1000l );
	*/
						 push( -1000l );
					#endif
					
						 break;
		case OUTPUTD:	
	 	//	push( outputd( local + (pop()/1000), pop()/1000, port)*1000l );				 
			break;
		case ASSIGNARRAY: /* local var */
						if (*prog >= LOCAL_VARIABLE && *prog <= STRING_TYPE_ARRAY)   
							push( ((S32_T)*((S16_T *)(prog+1)))*1000L );
						//	push( DoulbemGetPointWord2(((S32_T)*((S16_T *)(prog+1)))*1000L ));
						 prog += 3;
						 break;
		case ASSIGNARRAY_1:
						push(getvalelem(1, pop()/1000L, local));
						 break;
		case ASSIGNARRAY_2:
						 push(getvalelem(pop()/1000L, pop()/1000L, local));
						 break;
		default:
								prog--;
				push(operand(0,local));
	}
 }

	if (*prog==0xFF) 		prog++;
	temp1 = pop();
	temp2 = DoulbemGetPointWord2(temp1);
//	Test[2] = temp1;
//	Test[3] = temp2;
	/* add by chelsea */
	return (temp2);

}


/*
 * ----------------------------------------------------------------------------
 * Function Name: operand
 * Purpose: 
 * Params:
 * Returns:
 * Note: this function is called in veval_exp() routions
 * ----------------------------------------------------------------------------
 */
S32_T operand(S8_T **buf,U8_T *local)
{
	S8_T *p;
	S16_T num;
	S32_T tempval = 0;
	value = 0;
	if (*prog >= LOCAL_VARIABLE && *prog <= BYTE_TYPE)    /* local var */
	{
		prog += 3;
		if(buf)			*buf=0;
		
		return localvalue(prog-3, local);
	}
	
	if (*prog == LOCAL_POINT_PRG)
	{		
		if((((Point *)(prog+1))->point_type)-1 == ARRAY )
		{
			++prog;
			get_ay_elem(&value, local);
		}
		else
		{
			get_point_value( ( (Point *)(++prog) ), &value );
			prog += sizeof(Point);
		}
		
		value = DoulbemGetPointWord2(value);		
		
		return value;              /* = read point */
	}
	
	if (*prog == REMOTE_POINT_PRG)
	{
		if( (((Point_Net *)(prog+1))->point_type)-1==ARRAY )
		{
			++prog;
			p = prog;
			prog += sizeof(Point_Net);
			num = veval_exp(local,0)/1000L-1;
			get_net_point_value( (Point_Net *)p, &value );
		}
		else
		{
			get_net_point_value( ( (Point_Net *)(++prog) ), &value );
		value = DoulbemGetPointWord2(value);
			prog += sizeof( Point_Net );
			
		}	
	/*	get_remote_point_value(*((Point_Net *)(++prog)), &value, buf);
	prog += sizeof(Point_Net);*/
		return value;              /* = read point */
	}

	if (*prog == CONST_VALUE_PRG)
	{
		
		prog += 5;
		if(buf)		*buf=0;
		tempval = DoulbemGetPointWord2(*((S32_T *)(prog-4)));
		return (tempval);
	}
	return 0;
}


void push(S32_T value)
{
 	*index_stack++ = value;
	
}


S32_T pop(void)
{
 	return (*(--index_stack));
}

void pushS32_T(U32_T value)
{
 	memcpy(index_stack++, &value, 4);
}


U32_T popS32_T(void)
{
	U32_T value;
	memcpy( &value, --index_stack, 4);
	return (value);
}



S16_T phone(S8_T *message,S16_T i)    /* phone call*/
{
	message[i] = '\r';
	message[i+1] = 0;
	memmove(message+4, message, i+1);
	memcpy(message, "ATDT", 4);
	//outputd( message, i+5, COM2);
}


S16_T print(S8_T *message)  /* print to printer*/
{
/*
	set_semaphore(&print_sem);
	if( print_message_pool.put( message, strlen(message)+1 ) )
	{
	action=1;
	print_flag=1;
	if( tasks[MISCELLANEOUS].status == SUSPENDED )
		 resume(MISCELLANEOUS);
	}
	clear_semaphore(&prS16_T_sem);
	return 0;
*/
}

S16_T	handup()    	/* end phone call*/
{
	Protocol_parameters *ps;
	ps = &Port_parameters[COM2];
//	outputd( "ATH0\r", 5, COM2);
/*	reset_tx_port( ps->port );*/
}





/*---------------------------------------------------------------------------
*	the following funcition is used for DALARM 
* S16_T putmessage(S8_T *mes, S16_T prg, S16_T type, S8_T alarmatall,S8_T indalarmpanel,S8_T *alarmpanel, S16_T j)
* S16_T checkforalarm(S8_T *mes, S16_T prg, S16_T panel, S16_T id, S16_T *free_entry)
* S16_T generatealarm(S8_T *mes, S16_T prg, S16_T panel, S16_T type, S8_T alarmatall,S8_T indalarmpanel,S8_T *alarmpanel,S8_T printalarm)
* void dalarmrestore(S8_T *mes, S16_T prg, S16_T panel)
*---------------------------------------------------------------------------
*/

/*
 * ----------------------------------------------------------------------------
 * Function Name: putmessage
 * Purpose: 
 * Params:
 * Returns:    return:  0 - no space; >=1 - alarm index
 * Note:  it is used in generatealarm
 * ----------------------------------------------------------------------------
 */
S16_T putmessage(S8_T *mes, S16_T prg, S16_T type, S8_T alarmatall,S8_T indalarmpanel,S8_T *alarmpanel, S16_T j)
{
	/* S8_T buf[30],*p;*/
	S16_T k; /*j*/
	S8_T *p;
	Alarm_point *ptr;
	/* j = checkalarmentry();*/
	if(j>=0)
	{
		ptr = &alarms[j];
		memset(ptr,0,sizeof(Alarm_point));
		SetByteBit(&ptr->flag4,2,alarm_change_flag,2);//ptr->change_flag  = 2;
		SetByteBit(&ptr->flag1,1,alarm_alarm,1);//ptr->alarm        = 1;
		ptr->no           = j;
		ptr->alarm_panel  = Station_NUM;
		ptr->alarm_time   = time_since_1970+timestart;
		ptr->alarm_count  = ALARM_MESSAGE_SIZE;

		ptr->prg          = prg;
		ptr->alarm_id     = alarm_id++;
		SetByteBit(&ptr->flag1,type,alarm_type,2);//ptr->type         = type;
		SetByteBit(&ptr->flag3,panel_net_info.panel_type,alarm_panel_type,4);//ptr->panel_type   = panel_net_info.panel_type;
		
		ptr->alarm_count = strlen(mes);
		strcpy(ptr->alarm_message,mes);
		
		if(alarmatall)
		{
			ptr->where1     = 255;
		}
		if( indalarmpanel )
		{
			p = &ptr->where1;
			for(k=0;(k<indalarmpanel)&&(k<5);k++,p++)
			{
			 *p = alarmpanel[k];
			}
		}
		SetByteBit(&ptr->flag4,0,alarm_change_flag,2);//ptr->change_flag  = 0;
		if( ++ind_alarms > MAX_ALARMS) ind_alarms = MAX_ALARMS;
		/*	GAlarm = 1;*/
	}
	else
		j=-1;

 	return j+1;    /* 0 - no space; n - alarm index*/
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: checkforalarm
 * Purpose: 
 * Params:
 * Returns:   
 * Note:  it is used in generatealarm
 * ----------------------------------------------------------------------------
 */
S16_T checkforalarm(S8_T *mes, S16_T prg, S16_T panel, S16_T id, S16_T *free_entry)
{
	Alarm_point *ptr;
	S16_T j;
	ptr = alarms;
	for(j=0;j<MAX_ALARMS;ptr++,j++)
	{
	if( GetByteBit(ptr->flag1,alarm_alarm,1)/*ptr->alarm*/ )
	{
	 	if( ptr->alarm_panel == panel )
			if( ptr->prg==prg )
		 		if( !id )
		 {
			if( !GetByteBit(ptr->flag1,alarm_restored,1)/*ptr->restored*/ )
			 if (ptr->alarm_count == strlen(mes) )
				if( !strcmp(ptr->alarm_message, mes) )
				{
				 return j+1;          /* existing alarm*/
				}
		 }
		 else
		 {
			if( ptr->alarm_id == *((S16_T *)mes) )
				return j+1;           /* existing alarm*/
		 }
	}
	else
	{
	 if( !GetByteBit(ptr->flag1,alarm_ddelete,1)/*ptr->ddelete*/ )   /* ddelete=1; the user delete the alarm*/
	                     /* but it was not sent yet to the destination panels*/
	 *free_entry = j;
	}
	}
	return 0;  /* alarm does not exist*/
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: generatealarm
 * Purpose: 
 * Params:
 * Returns:   0 - no space for alarm, 1 - n alarm index, -1 message already on
 * Note: it is used in excu_program(DALARM)
 * ----------------------------------------------------------------------------
 */
S16_T generatealarm(S8_T *mes, S16_T prg, S16_T panel, S16_T type, S8_T alarmatall,S8_T indalarmpanel,S8_T *alarmpanel,S8_T printalarm)
{
	S16_T j;
	j = -1;
	if( checkforalarm(mes,prg,panel,0,&j)>0 ) return -1;
	if(j>=0)
	{
		putmessage(mes,prg,type,alarmatall,indalarmpanel,alarmpanel,j);    /* alarm*/
		new_alarm_flag |= 0x01;
		/*
		if(	alarms[j].where1==255 )
		{
		 i = sizeof(Alarm_point);
		ClientTransactionStateMachine( UNCONF_SERVrequest,
		          (S8_T *)&alarms[j], &i, &Port_parameters[0], 255, SEND_ALARM_COMMAND+100, 0, 0);
		 alarms[j].where_state1=1;
		}
		*/
 	}
/*
 if ( j > 0 )
 {
	 new_alarm_flag |= 0x01;
	 resume(ALARMTASK);
*/
/*
	 if(printalarm)
	 {
		 printalarmproc(mes,j);
	 }
 }
*/
 	return j+1;
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: dalarmrestore
 * Purpose: 
 * Params:
 * Returns:
 * Note: it is used in excu_program(DALARM)
 * ----------------------------------------------------------------------------
 */
void dalarmrestore(S8_T *mes, S16_T prg, S16_T panel)
{
	S16_T j;
	Alarm_point *ptr;
	
	ptr = alarms;
	for(j=0;j<MAX_ALARMS;ptr++,j++)
	{
		if( GetByteBit(ptr->flag1,alarm_alarm,1)/*ptr->alarm*/ )
	 		if( ptr->alarm_panel==panel )
				if( ptr->prg==prg )
		 			if( !GetByteBit(ptr->flag1,alarm_restored,1)/*ptr->restored*/ )
						if (ptr->alarm_count == strlen(mes) )
			 				if( !strcmp(ptr->alarm_message, mes) )
			 				{
								SetByteBit(&ptr->flag1,0,alarm_restored,1);//ptr->restored = 1;
								SetByteBit(&ptr->flag4,0,alarm_where_state1,1);//ptr->where_state1 = 0;
								SetByteBit(&ptr->flag4,0,alarm_where_state2,1);//ptr->where_state2 = 0;
								SetByteBit(&ptr->flag4,0,alarm_where_state3,1);//ptr->where_state3 = 0;
								SetByteBit(&ptr->flag4,0,alarm_where_state4,1);//ptr->where_state4 = 0;
								SetByteBit(&ptr->flag4,0,alarm_where_state5,1);//ptr->where_state5 = 0;
								if( !GetByteBit(ptr->flag1,alarm_acknowledged,1)/*ptr->acknowledged*/ )
								{
								 if(!ind_alarms--)  ind_alarms = 0;
								}
	    						new_alarm_flag |= 0x02;
								return;
			 				}
	}
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: get_ay_elem
 * Purpose: get the element of arrays[]
 * Params:
 * Returns:
 * Note: it is used in operand()
 * ----------------------------------------------------------------------------
 */
S16_T get_ay_elem(S32_T *value, S8_T *local)
{
	S16_T num;
	U8_T point_type,num_point;
	S32_T *p;
	
	point_type = (((Point *)(prog))->point_type)-1;
	num_point = ((Point *)(prog))->number;
	prog += sizeof(Point);
	num = veval_exp(local, 0 )/1000L-1;
	if( ( num < arrays[num_point].length ) & ( num >= 0 ) )
	{
		 *p =  arrays_data[num_point];
		 *value = *(p + num);
	}
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: getvalelem
 * Purpose: get the value from the current array
 * Params:
 * Returns:
 * Note: it is used in excu_program(ASSIGNARRAY_1,ASSIGNARRAY_2)
 * ----------------------------------------------------------------------------
 */
S32_T getvalelem(S32_T l, S32_T c, unsigned S8_T *local)
{
	S8_T *p;
	S32_T i;
	S16_T j;
	i=0;
	if( *prog == ASSIGNARRAY)
	{
		prog++;
		i = *((S16_T *)(prog+1));
	}
	if (*prog >= STRING_TYPE && *prog <= STRING_TYPE_ARRAY )    /* local var*/
	{
		p = local + *((S16_T *)(prog+1));
		j = ( (*((S16_T *)(p-2)))-1 );
		prog += 3;
		switch(*(prog-3))
		{
			case FLOAT_TYPE_ARRAY:
			case LONG_TYPE_ARRAY:
					if(!i)
						return ( *((S32_T *)&p[( (l-1)*j + c-1 ) * 4 ]) );
					else     /*address*/
						return ( (S32_T)(i + ( (l-1)*j + c-1 ) * 4)*1000L  );
					break;
			case INTEGER_TYPE_ARRAY:
					if(!i)
						return ( (S32_T)(*((S16_T *)&p[( (l-1)*j + c-1 ) * 2 ]))*1000L );
					else
						return ( (S32_T)(i+(( (l-1)*j + c-1 ) * 2 ))*1000L );
					break;
			case BYTE_TYPE_ARRAY:
					if(!i)
						return ( (S32_T)(p[( (l-1)*j + c-1 ) ])*1000L );
					else
						return ( (S32_T)(i+(( (l-1)*j + c-1 ) ))*1000L );
					break;
			case STRING_TYPE:
					if(!i)
						return ( (S32_T)(p[ c-1 ])*1000L );
					else
						return ( (S32_T)(i+c-1)*1000L );
					break;
		}
	 }
	 return 0;
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: put_local_array
 * Purpose: put the value to the array
 * Params:
 * Returns:
 * Note: it is used in excu_program(ASSIGNARRAY_1,ASSIGNARRAY_2)
 * ----------------------------------------------------------------------------
 */
S16_T put_local_array(unsigned S8_T *p, S32_T value, S32_T v1, S32_T v2, unsigned S8_T *local )
{
	S16_T k, i, j;

  	j = *((S16_T *)(p+1));
	if( *((S16_T *)&local[ j - 4]) )
	{
		if ( v1<=0 || v1 > *((S16_T *)&local[ j - 4]) || v2<=0 || v2 > *((S16_T *)&local[ j - 2]))
			return 1;
	}
	else
	{
	 	if ( v2<=0 || v2 > *((S16_T *)&local[ j - 2]))
			return 1;
	}
	switch(*p)
	{
		case FLOAT_TYPE_ARRAY:
		case LONG_TYPE_ARRAY:
				k=4;
				break;
		case INTEGER_TYPE_ARRAY:
				k=2;
				break;
		case BYTE_TYPE_ARRAY:
/*		case STRING_TYPE_ARRAY: */
				k=1;
				break;
	}

	i =  *((S16_T *)&local[((j)-2)]);
	i *= (v1-1);
	i += v2 - 1;
	i *= k;
	k = j + i;

	switch(*p)
	{
		case FLOAT_TYPE_ARRAY:
		case LONG_TYPE_ARRAY:
			*((S32_T *)&local[k])=value;							break;
		case INTEGER_TYPE_ARRAY:
			*((S16_T *)&local[k])=(S16_T)(value/1000L);				break;
		case BYTE_TYPE_ARRAY:
/*		case STRING_TYPE_ARRAY: */
			local[k]=(S8_T)(value/1000L);							break;
	}
	return 0;
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: localvalue
 * Purpose: get the local value when *p is (float long, integer,byte)
 * Params:
 * Returns:
 * Note: it is used in operand()
 * ----------------------------------------------------------------------------
 */
S32_T localvalue(unsigned S8_T *p, unsigned S8_T *local)
{
	S32_T l;
	S16_T i;
	i = *((S16_T *)(p+1));
	switch(*p)
	{
		case FLOAT_TYPE:
		case LONG_TYPE:
				l = *((S32_T *)&local[i]);
				break;
		case INTEGER_TYPE:
				l = (S32_T)(*((S16_T *)&local[i]))*1000L;
				break;
		case BYTE_TYPE:
				l = (S32_T)((signed S8_T)local[i])*1000L;
				break;
	}
	return l;
}



/*
 * ----------------------------------------------------------------------------
 * Function Name: put_local_var
 * Purpose: put the local value when *p is (float long, integer,byte)
 * Params:
 * Returns:
 * Note: it is used in operand()
 * ----------------------------------------------------------------------------
 */
void put_local_var(unsigned S8_T *p, S32_T value, unsigned S8_T *local)
{
	S16_T i;
	i = *((S16_T *)(p+1));
	switch(*p)
	{
		case FLOAT_TYPE:
		case LONG_TYPE:
				*((S32_T *)&local[i])=value;
				break;
		case INTEGER_TYPE:
				*((S16_T *)&local[i])=(S16_T)(value/1000L);
				break;
		case BYTE_TYPE:
				local[i]=(S8_T)(value/1000L);
				break;
	}
}



#endif


