/***************************************************************/
/*                                                             */
/* Includes all the global data declarations 								   */
/*                                                             */
/***************************************************************/
#define _DATA_DOT_C

#include "main.h"

#ifdef BACNET

MiscFlags         far       misc_flags;

/*	U8_T                      wantpointsentry;*/

U8_T		far									present_monitors;

U8_T          far            tswitch;         	/* task index			*/

U8_T	      far      run_break = 0;

U8_T	      far      need_task_switch;

U8_T	     far       need_check_sleepers;

Protocol_parameters    far   Port_parameters[2];
U8_T			   far            	Station_NUM;
U32_T 			far		 	timestart;
//U32_T 					 	ora_current_sec;
U32_T 			far			time_since_1970;
                        /* seconds since the beginning of 1970 */
U8_T            far          second_count;

S16_T            far           miliseclast;

S16_T             far          miliseclast_cur;
				  
//Date_block					ora_current;	   // define it in clock.c   MDY by chelsea

U8_T       far      timer_S16_T_count;

UNITDATA_PARAMETERS  	far		NL_PARAMETERS[2];

U8_T      far       password_needed;

U8_T       far      password_OK;
U16_T       far       work_word;

S8_T          far            timeout;

FlashFlags      far          flash_flags;

U8_T   far		channel_desc;
U8_T    far    cards_type;
S8_T         far			 	temp_buffer[MAXAPDUSIZE];


//U8_T month_length[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };


U8_T far table_bank[TABLE_BANK_LENGTH] =
{
	 MAX_OUTS,     	/*OUT*/
	 MAX_INS,     	/*IN*/
	 MAX_VARS,      /*VAR*/
	 MAX_CONS,     	/*CON*/
	 MAX_WR,        /*WR*/
	 MAX_AR,        /*AR*/
	 MAX_PRGS,     	/*PRG*/
	 MAX_TBLS,      /*TBL*/
	 MAX_TOTALIZERS, /*TOTAL*/
	 MAX_MONITORS,	/*AMON*/
	 MAX_GRPS,      /*GRP*/
	 MAX_ARRAYS,    /*AY*/
	 MAX_ALARMS,
	 MAX_UNITS,
	 MAX_PASSW
};

/*  add by Adi oct 21/97                     */

S8_T          far               panelconnected;

S8_T           far              netpointsflag;  /*iamnewonnet;*/

S8_T          far      				 sendinfoflag;

/*  end                                      */

U16_T 		far			       power_down_count;

S8_T         far                power_pattern[18];

U8_T 		far										 already_initialized;

U16_T       far                  char_period[2];

//Task_struct                  tasks[NUM_TASKS];

S8_T       far                  just_load;

U8_T      far          use_virtual;

U8_T      far          monitor_flag;

SystemFlags 		far			       system_flags_2;
SystemFlags 	far				system_flags_3c;

FlashFlags      far             flash_flags_2;

U8_T        far        cards_status_AB;

U8_T      far          cards_status_CD;

Routing_Table     far           Routing_table[MAX_Routing_table];

TSMTable         far    				 Server_TSM_table[MAXServerTSMTable];
TSMTable         far    				 Client_TSM_table[MAXClientTSMTable];

S8_T 		   far         				 VendorID;

U8_T 		   far         				 STSMremoveflag;

S16_T      	   far       			   ServerTSM_flag;
/*S16_T      	          			   ClientTSM_flag = -1;*/
FRAME_ENTRY 			far				SendFrame[MAX_SEND_FRAMES] _at_ 0x1000;

S8_T            far     			send_frame_buffer0[550];
S8_T 			far				send_frame_buffer1[550];

U8_T          far               Using_send_frame;
U8_T          far               no_of_send_frame_used;

FRAME_ENTRY 	far							 ReceiveFrame_0;
FRAME_ENTRY 	far				       ReceiveFrame_1;

S8_T 					far							 work_buffer[40];

U8_T				 far								 lock[MAX_INFO_TYPE];

U8_T				far								 in_out_data[MAX_IO_POINTS];


S16_T            far              MAX_MONITOR_BLOCKS = FLASH_BUFFER_LENGTH /
																								 sizeof( Monitor_Block );

/*S16_T                          MAX_MONITOR_BLOCKS = 3;*/

U8_T           far              free_mon_blocks;

MiniInfo2 		far							 cards_info;

Info_Table			far						 info[18];

S32_T			    far							 arrays_data[MAX_ARRAYS_DATA];

U8_T            far             *Flash_PRG_address;

/** Header for writting S16_To Flash **/

S32_T          far               PRG_start_address;

S32_T          far               PRG_length;

/**** { These will be saved S16_To Flash ****/

U16_T            far             Flash_PRG_length;
Panel_Net_Info       far				 panel_net_info; /* PanelInfo1 */

MiniCommInfo 		far		         comm_info[2];



S8_T          far               default_panel[13];
//S8_T					far								 in_out_pool[MAX_IO_POINTS*sizeof(Str_out_point)];
S8_T far   Input[2432 ]_at_ 0x3000;
S8_T  far	Output[2560]/* _at_ 0x3000*/;
//S8_T  far	Input[MAX_IO_POINTS*sizeof(Str_in_point)];
//S8_T  far	Output[MAX_IO_POINTS*sizeof(Str_out_point)];
//Str_in_point  far Input[MAX_IO_POINTS] _at_ 0x1200;
//Str_out_point  far Output[MAX_IO_POINTS] _at_ 0x3000 ;

Str_out_point    	far				 *outputs;
U8_T				far				 no_outs;
Str_in_point    	far				*inputs;
U8_T				far				 no_ins;

//U32_T far test1[10000];



#if 1
In_aux					far						 in_aux[MAX_IO_POINTS];
Con_aux				far							 con_aux[MAX_CONS];

Mon_aux           far           mon_aux[MAX_MONITORS];
Monitor_Block		far					   *mon_block;



Alarm_point 		    far				 alarms[MAX_ALARMS];
U8_T 			    far							 ind_alarms;
Alarm_set_point 	far    			 alarms_set[MAX_ALARMS_SET];
U8_T 			    far							 ind_alarms_set;
Units_element		    far				 units[MAX_UNITS];
Password_struct 	    far			 passwords;

Str_variable_point			far		 vars[MAX_VARS]/* _at_ 0x4000*/;

Str_controller_point 	far			 controllers[MAX_CONS];

Str_totalizer_point     far     totalizers[MAX_TOTALIZERS];

Str_monitor_point		far				 monitors[MAX_MONITORS];
Aux_group_point        far 		 aux_groups[MAX_GRPS]/* _at_ 0x4000*/;
S8_T                    far		 Icon_names[MAX_ICONS][14];
Control_group_point  	far 		 control_groups[MAX_GRPS]/* _at_ 0x4000*/;
Str_grp_element		far	    		 group_data[MAX_ELEMENTS]/* _at_ 0x6500*/;
S16_T 					far							 total_elements;
S16_T 					far							 group_data_length;


Str_weekly_routine_point far		 weekly_routines[MAX_WR] /*_at_ 0x7000*/;
Wr_one_day				far		wr_times[MAX_WR][MAX_SCHEDULES_PER_WEEK]/* _at_ 0x7500*/;
Str_annual_routine_point	far	 annual_routines[MAX_AR];
U8_T                   far      ar_dates[MAX_AR][AR_DATES_SIZE];	

												 /* Assume bit0 from octet0 = Jan 1st */
Str_program_point	    far			 programs[MAX_PRGS];
S8_T 			    	far			*program_address[MAX_PRGS]; /*pointer to code*/
S8_T    	    	far				_code[MAX_PRGS][640]/* _at_ 0x4000*/;
U16_T 			    far				code_length;
Str_array_point 	    far			 arrays[MAX_ARRAYS];
S32_T  			    				*arrays_address[MAX_ARRAYS];
Str_table_point			far				 custom_tab[MAX_TBLS];
U16_T                far         PRG_crc;

#endif
/****** } End block stored S16_To Flash ********/

NETWORK_POINTS	far	network_points_list[MAXNETWORKPOINTS];		 /* points wanted by others */
U8_T                 far				 number_of_network_points;

REMOTE_POINTS	far	remote_points_list[MAXREMOTEPOINTS]; 		/* points from other panels used localy */
U8_T                far				 number_of_remote_points;

SystemFlags 	far		system_flags;
FlashFlags      far        flash_flags_3c;


Station_point far	 station_list[MAX_STATIONS];

/* data for Virt */


S32_T far stack[50];
S32_T *index_stack;
S8_T far message[ALARM_MESSAGE_SIZE+26+10];

S8_T far called_program, end_program;

U8_T *prog;

U8_T far alarm_flag, error_flag;

S16_T far portA_printer, portB_printer;
S32_T far cond;  // S16    changed by chelsea  

S8_T far alarm_at_all;
S8_T far print_at_all;
S8_T far alarm_panel[5];
S8_T far print_panel[5];
S8_T far ind_alarm_panel;
S8_T far ind_print_panel;


S32_T far v, value;

S32_T far op1,op2;
S32_T n,*pn;

S16_T far g_ind_remote_local_list;

//Program_remote_points	*g_remote_local_list;

S8_T *time_buf;

/*  add by Adi oct 21/97                     */

S32_T           far              timereadclock;

U16_T           far      alarm_id;

S8_T                 far        new_alarm_flag;

Point_Net            far        localopenscreen;

S8_T                 far			 	 npci_buffer[MAXAPCI];

FRAME_ENTRY          far			 	 sendinfo_buffer;
FRAME_ENTRY 		far			       ReceiveFrame_1_1;

S8_T           far              mstp_activity;
/*  end Adi                                  */

/* data for Flash */
U8_T     far    no_updates;
S16_T      far             current_sector;
S8_T                 *chip_start_address;
U8_T      far   device_code, manu_code;

S16_T         far          FlashCRC;
S32_T         far         flash_data_length;
S16_T         far          flash_write_status;


//SectorInfo     far       flash_info[7];

//S8_T                  RAM_code;
//U16_T    far      RAM_code_length;


//S8_T   far               flash_data1[ FLASH_BUFFER1_LENGTH ];

U8_T far port; // Serial port 0 / 1

/* data for task */
xTaskHandle xHandleMSTP;		//  PTP_transmission_sm
xTaskHandle xHandlePTPconnection; 		// 	connection
xTaskHandle xHandlePTPreception;		//	reception
xTaskHandle xHandlePTPtransmission;		//  PTP_transmission_sm
//xTaskHandle xHandleControl;	
xTaskHandle xHandleSeverTSM; 		// 	connection
//xTaskHandle xHandleTcp;
xTaskHandle xHandleBACnetCommon;
xTaskHandle xHandleMSTPTimer;
//xTaskHandle xHandleSPI;
//xTaskHandle xHandleClk;
//xTaskHandle xHandleCommon;
//xTaskHandle xSoftWatchTask;


UN_ID  far ID_Config[MAX_ID];

#endif

