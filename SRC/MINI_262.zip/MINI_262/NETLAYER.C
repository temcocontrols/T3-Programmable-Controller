#define _NETLAYER_DOT_C


#include "main.h" 

#ifdef BACNET




#define ON   	1
#define OFF  	0
#define FALSE   0
#define TRUE   1

//bit f_test = 0;

/*
 * ----------------------------------------------------------------------------
 * Function Name: NL_unitdata_ind
 * Purpose: Network Layer(N-UNITDATA.indicate ) primitive
 * Params:   
 * Returns:
 * Note: convey npdu data to NL_PARAMETERS
 *		1. convey APUD
 *		2. convey the managemnet and control message of newwork layer, incluing intiail router_table
 
 * ----------------------------------------------------------------------------
 */
S16_T NL_unitdata_ind( Protocol_parameters *ps, S8_T *npdu, U16_T length_npdu, U8_T Source )
{
/*	U8_T direct;*/
	U8_T HopCount;
	S8_T dnet, snet, n;
	S16_T MessageType, i;
	FRAME_ENTRY  *pframe;
	UNITDATA_PARAMETERS *NL_parameters;
	TSMTable *PTRtable; 
 
	NL_parameters = &NL_PARAMETERS[ps->port];
//	PTRtable = Server_TSM_table;
//	pframe = Port_parameters->rec_frame;
	snet = 0;
	dnet = 0;
	n = 0;
	memset( NL_parameters, 0, sizeof(UNITDATA_PARAMETERS) );
/* NPDU frame */
/*	version  1 byte
	control 	1 byte
	DNET		2 BYTE
	DADR		1 BYTE
	...
	please refer to NPDU frame
*/
	/* npdu[1] -- control , decide DNET, DLEN, and HopCount and so on*/
	switch( npdu[1] & 0x60 )
	{
		case 0x00: dnet = ABSENT;                /* this panel */
				n = 2;
				break;
		case 0x40: memcpy( &NL_parameters->DNET, &npdu[2], 2);   /* DNET, HopCount, DADR one octet */
				NL_parameters->D_MAC_ADR[0] = npdu[4];
				NL_parameters->DLEN = 1;
				n = 5;
				break;
		case 0x60: memcpy( &NL_parameters->DNET, &npdu[2], 2);   /* DNET, DLEN, HopCount */
				NL_parameters->DLEN = npdu[4];                      /* DLEN=0 broadcast MAC DADR */
				if (!NL_parameters->DLEN) NL_parameters->D_MAC_ADR[0]=0x0FF;             /* DLEN>0 length DADR */
				else memcpy( NL_parameters->D_MAC_ADR, &npdu[5], NL_parameters->DLEN);
				n = 5+NL_parameters->DLEN;
				break;
	}
	switch (npdu[1] & 0x18)
	{
		case 0x00: snet = ABSENT;
				break;
		case 0x10: memcpy( &NL_parameters->SNET, &npdu[n], 2);
				NL_parameters->S_MAC_ADR[0] = npdu[n+2];
				NL_parameters->SLEN = 1;
				n += 3;
				break;
		case 0x18: memcpy( &NL_parameters->SNET, &npdu[n], 2 );
				NL_parameters->SLEN = npdu[n+2];
				memcpy( NL_parameters->S_MAC_ADR, &npdu[n+3], NL_parameters->SLEN );
				n += ( 3 +  NL_parameters->SLEN);
				break;
	}
	if ( dnet != ABSENT ) HopCount = npdu[n++];
	if ( snet == ABSENT )
	{
		NL_parameters->SNET = Routing_table[ps->port].Port.network;
		NL_parameters->S_MAC_ADR[0] = Source;
	}
	/* Bit 7: 	1 indicates that the NSDU conveys a network layer message. Message Type field is present.
				0 indicates that the NSDU contains a BACnet APDU. Message Type field is absent. */
	if( npdu[1] & 0x80 )
	{ /* Network layer message */
		MessageType = (U8_T)npdu[n++];
		if( MessageType >= 0x80 && MessageType <= 0x0FF )
			i = npdu[n++];  /*VendorID*/
/*		direct = 0;*/
		if( dnet == ABSENT || NL_parameters->DNET == 0x0FFFF )
		{  /* global broadcast */
			 /* S16_Terpret & send */
			router( DL_UNITDATAindication, MessageType, &npdu[n], length_npdu-n, ps, 0); /* &npdu[n] -- the header of apdu*/
		}
/*
		--HopCount;
		if( dnet != ABSENT )
		{
			for(i=0; i<MAX_Routing_table; i++)
			{
				if( ( Routing_table[i].status & PORT_ACTIVE ) == PORT_ACTIVE )
				{
					if( NL_parameters->DNET == BROADCAST )
					{
           ;
					}
					else
					{
						if( Routing_table[i].Port.network == NL_parameters->DNET )
						{
							if( !( Routing_table[i].status ^ PTP_ACTIVE ) )
							{
                pframe = SendFreeEntry( ps->port, 0 );
								if( !pframe ) return 0;

								pframe->Buffer[0] = 0x01;
								pframe->Buffer[1] = 0x90;
								memcpy( &pframe->Buffer[2], &NL_parameters->SNET, 2 );
								pframe->Buffer[4] = NL_parameters->S_MAC_ADR[0];
								pframe->Buffer[5] = MessageType;
								pframe->Length = 6;
								pframe->FrameType = DATA_0;
                pframe->locked = 0;
								resume( ps->base_task + PTP_TRANSMISSION );
							}
							break;
						}
						else
						{
							if( HopCount )
							{
								for( j=0; j<MAX_reachable_networks; j++ )
								 if( Routing_table[i].Port.networks_list[j].status == 0x03 )
									if(	Routing_table[i].Port.networks_list[j].network == NL_parameters->DNET )
									{
										if( !( Routing_table[i].status ^ PTP_ACTIVE ) )
										{
				    	        pframe = SendFreeEntry( ps->port, 0 );
      								if( !pframe ) return 0;

											pframe->Buffer[1] = 0xD0;
											memcpy( &pframe->Buffer[5], &NL_parameters->SNET, 2);
											pframe->Buffer[7] = NL_parameters->S_MAC_ADR[0];
											pframe->Buffer[8] = HopCount;
											pframe->Buffer[9] = MessageType;
											pframe->Length = 10;
											pframe->FrameType = DATA_0;
			                pframe->locked = 0;
											resume( ps->base_task + PTP_TRANSMISSION );
										}
										break;
									}
								}
							}
						}
					}
				}
			}
			else
			{
        pframe = SendFreeEntry( ps->port, 0 );
      	if( !pframe ) return 0;

				pframe->Buffer[1] = 0x90;
				memcpy( &pframe->Buffer[2], &NL_parameters->SNET, 2);
				pframe->Buffer[4] = NL_parameters->S_MAC_ADR[0];
				pframe->Buffer[5] = MessageType;
				pframe->Length = 6;
				pframe->FrameType = DATA_0;
				for( j=0; j<MAX_Routing_table; j++)
				{
					if( !( Routing_table[i].status ^ PTP_ACTIVE ) && j != ps->port )
					{
            pframe->locked = 0;
						resume( ps->base_task + PTP_TRANSMISSION );
					}
				}
        if(pframe->locked == 1)
					RemoveSentEntry( pframe );
			}
*/
		}
		else
		{
			/* Application layer message */
			/* request on local panel */
			i = 0;
			if( dnet==ABSENT || ( dnet !=ABSENT &&	NL_parameters->DNET == panel_net_info.network_number &&
				( NL_parameters->D_MAC_ADR[0] == Station_NUM ||	NL_parameters->D_MAC_ADR[0] == 0x0FF ) ) )
			{
/*
				if( clientserver == CLIENT )
				{
					ClientTSMTable.received(destination, SADR[0], &asdu_npdu[n], length_asdu_npdu-n);
				}
				else
*/
				{
/*
					if( dnet == ABSENT )
						memset( NL_parameters->D_MAC_ADR, '\0', 6 );
*/
		          	if( STSMremoveflag ) return 0;	
					ServerTransactionStateMachine( -1, npdu+n, length_npdu-n, ps );
				}
				i=1;
			}
			/* request on remote panel */

			if ( !i && dnet!=ABSENT )
			{
		        if(ps->port)
		        {
				/* message comming from PTP port routed to a RS485 port */
		
		/*
		              j = Port_parameters[0].ResponseTimer;
		              if( j==0x0FFFF ) j = 0;
		              while( Port_parameters[0].ResponseTimer < j+3 );
		*/
		/*              msleep(2);*/
				    pframe = SendFreeEntry( 0, 0 );
      				if( !pframe ) {   return 0;}
					
					pframe->Buffer[0] = 0x01;  /* */
					pframe->Buffer[1] = 0x10;  /* */
					memcpy(&pframe->Buffer[2], &NL_parameters->SNET, 2 );
					pframe->Buffer[4] = NL_parameters->S_MAC_ADR[0];
					pframe->Length = 5;
					
					/* build frame */
					memcpy( pframe->Buffer+pframe->Length, npdu+n, length_npdu-n );
					pframe->Length = pframe->Length + length_npdu - n;
					
					pframe->FrameType = ( NL_parameters->D_MAC_ADR[0]==255?BACnetDataNotExpectingReply:BACnetDataExpectingReply);
		/*
									if( ps->link_type == RS485_LINK )
									{
										if( ps->FrameType != BACnetDataExpectingReply )
											pframe->FrameType = ps->FrameType;
									}
		*/
					switch (pframe->Buffer[5]>>4)
					{    /*0+5*/
						case BACnetUnconfirmedRequestPDU:
						case BACnetAbortPDU:
								pframe->FrameType = BACnetDataNotExpectingReply;
								break;
						case BACnetSegmentACKPDU:
								if(pframe->Buffer[14]==BACnetDataNotExpectingReply)  /*9+5*/
									pframe->FrameType = BACnetDataNotExpectingReply;
								break;
					}

					pframe->Destination = NL_parameters->D_MAC_ADR[0];
					pframe->Source = Station_NUM;
      				pframe->locked = 0;
				//	SetByteBit(&pframe->flag,0,1,1);
/*							Unlockhead( pframe );*/
/*  							resume( Port_parameters[1-ps->port].base_task );*/
		        }
		        else
		        {
					#if 0  
			    	pframe = SendFreeEntry( 1, 0 );
  				  	if( !pframe ) return 0;

				/* message comming from one port routed to a PTP port */
					
					pframe->Buffer[0] = 0x01;  /* */
					pframe->Buffer[1] = 0x50;
					memcpy(&pframe->Buffer[2], &NL_parameters->DNET, 2);
					pframe->Buffer[4] = NL_parameters->D_MAC_ADR[0];
					memcpy(&pframe->Buffer[5], &NL_parameters->SNET, 2);
					pframe->Buffer[7] = NL_parameters->S_MAC_ADR[0];
					pframe->Buffer[8] = HopCount;
					memcpy( pframe->Buffer+9, npdu+n, length_npdu-n );
					pframe->Length = 9 + length_npdu - n;
					pframe->FrameType = DATA_0;
    				pframe->locked = 0;

					#endif
				
					if( STSMremoveflag ) return 0;	
				   	ServerTransactionStateMachine( -1, npdu+n, length_npdu-n, ps );
					

/*								Unlockhead( pframe );*/
				//			resume( Port_parameters[1-ps->port].base_task + PTP_TRANSMISSION );   TBD:
        	}
/*
				if( (Routing_table[ps->port].status&RS485_ACTIVE)==RS485_ACTIVE )
				{
					if(ps->replyflag==1)
					{
		    	  pframe = SendFreeEntry( ps->port, 1, 0 );
   					if( !pframe ) return 0;

						pframe->FrameType = ReplyPostponed;
						pframe->Destination = NL_parameters->S_MAC_ADR[0];
						pframe->Source = Station_NUM;
						pframe->Length = 0;
            pframe->locked = 0;
					  ps->replyflag=2;
          }
				}
*/
			}
		}
 	return 1;
}

/*
 * ----------------------------------------------------------------------------
 * Function Name: NL_unitdata_req
 * Purpose: Network Layer(N-UNITDATA.request ) primitive
 * Params:   
 * Returns:
 * Note: 
 * ----------------------------------------------------------------------------
 */
//U8_T Te[500];
S16_T NL_unitdata_req( Protocol_parameters *ps, TSMTable *PTRtable )
{
	S16_T i, j, k, destination;
	FRAME_ENTRY xdata *pframe;
  	Routing_Table  *prt;	
 	pframe = (FRAME_ENTRY xdata *)SendFreeEntry( ps->port, 0); //   get FRAME_ENTER structure
	if( !pframe )	{	 	return 0;}
	
	destination = (unsigned S8_T)PTRtable->S_MAC_ADR[0];
	PTRtable->apdu = NULL;
	PTRtable->length_apdu = 0;

/* find routing entry*/
    prt = &Routing_table[0];
	for( i=0; i<MAX_Routing_table; i++, prt++ )
	{
	 	j=-1;
	/*		 if( (prt->status&PORT_ACTIVE)==PORT_ACTIVE )*/
		if( prt->Port.network==PTRtable->SNET )
		{
			 break;
		}
		else
		{
			for(j=0; j<MAX_reachable_networks; j++)
			 if( ((prt->Port.networks_list[j].status&0x03) == 0x03) &&  /*REACHABLE*/
					prt->Port.networks_list[j].network==PTRtable->SNET)
			 {
				 destination=prt->Port.networks_list[j].router_address;
				 break;
			 }
			if(j<MAX_reachable_networks) break;
		}
	}
/*  check result*/
	if (i<MAX_Routing_table)
	{
		pframe->Buffer[0] = 0x01;
		if( prt->Port.network==PTRtable->SNET &&( prt->status & RS485_ACTIVE ) == RS485_ACTIVE )
		{    /* local network*/
			pframe->Buffer[1] = 0x00;     /* DNET, DADR, SNET, SADR absent */
			pframe->Length = 2;
		}
		else
		{
			pframe->Buffer[1] = 0x50;
			memcpy( &pframe->Buffer[2], &PTRtable->SNET, 2 );
			pframe->Buffer[4] = PTRtable->S_MAC_ADR[0];  /* destination */
			memcpy( &pframe->Buffer[5], &panel_net_info.network_number, 2 );
			pframe->Buffer[7] = Station_NUM;
			pframe->Buffer[8] = 5;
			pframe->Length = 9;
			
		}
		if( PTRtable->length_apci )
		{
		  	memcpy( pframe->Buffer+pframe->Length , PTRtable->apci, PTRtable->length_apci );
		  	pframe->Length += PTRtable->length_apci;
		}
		
		if( PTRtable->length_asdu )
		{
			memcpy( pframe->Buffer+ pframe->Length, PTRtable->asdu,PTRtable->length_asdu);
		  	pframe->Length += PTRtable->length_asdu;
		  	PTRtable->asdu = NULL;
		  	PTRtable->length_asdu = 0;
		}

		if(!(prt->status^PTP_ACTIVE))
		{
		 	pframe->FrameType = DATA_0;
			/*SetByteBit(&pframe->flag,0,1,1);*/pframe->locked = 0;
		}
     	else
		{
			if( ( prt->status & RS485_ACTIVE ) == RS485_ACTIVE )
			{
				/* build frame */
			/*					if( PTRtable->data_expecting_reply )*/
				{
					pframe->FrameType = PTRtable->data_expecting_reply;
				}
			/*					pframe->Destination = PTRtable->S_MAC_ADR[0];*/
				pframe->Destination = destination;
			/*					pframe->Source = PTRtable->D_MAC_ADR[0];       */
				pframe->Source = Station_NUM;
			/*	SetByteBit(&pframe->flag,0,1,1);*/pframe->locked = 0;
			/*					Unlockhead( pframe ); */
			/*					resume( ps->base_task );*/
			}
			else
				RemoveSentEntry( pframe );
		}
	}
    else
		RemoveSentEntry( pframe );

/*
		if( PTRtable->SNET == BROADCAST )
		{
			pframe->Buffer[1] = 0x70;
			pframe->Buffer[2] = 0xFF;
			pframe->Buffer[3] = 0xFF;
			pframe->Buffer[4] = 0;
			memcpy( &pframe->Buffer[5], &panel_net_info.network_number, 2 );
			pframe->Buffer[7] = Station_NUM;
			pframe->Buffer[8] = 5;
			pframe->Length = 9;
		}
*/
}

S16_T NL_connect_ind( Protocol_parameters *ps, S8_T *npdu, U16_T length_npdu )
{
	return 0;
}

S16_T NL_connect_failed( Protocol_parameters *ps )
{
	return 0;
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: router
 * Purpose: 
 * Params:   service -- NETWORKPrimitive (N_UNITDATArequest, N_UNITDATAindication)
 *			 command -- Network_Layer_Message_Type( )
 * Returns:
 * Note:  NETWORKPrimitive have two primitive : N_UNITDATArequest, N_UNITDATAindication
 * ----------------------------------------------------------------------------
 */
S16_T router( S16_T service, S16_T command, S8_T *dat, U16_T length,Protocol_parameters *ps, S16_T send )
{
	/* S8_T npci[24],s;*/
	S8_T s,*npci;
	S16_T length_npci,i,j, k, t, l;
	FRAME_ENTRY *pframe;
	UNITDATA_PARAMETERS *NL_parameters;
	Routing_Table  *prt,*prt_k;
	Reachable_Networks *rn;
	
	NL_parameters = &NL_PARAMETERS[ps->port];
	npci = &npci_buffer[0];
	prt_k = &Routing_table[ps->port];

	if( service == N_UNITDATArequest )
	{
		if( command == Establish_Connection_To_Network )
		{
/*			if( ps->port >= 0)*/
			{
				if(!(prt_k->status^PTP_ACTIVE) ) return 0;
				NL_parameters->primitive = DL_CONNECT_REQUEST;
/*					Unlockhead( ps );*/
// TBD:				resume( ps->base_task + PTP_CONNECTION );
			}
		}
	}
	if( ( command == I_Am_Router_To_Network ) || ( command == I_Am_Router_To_Network_Prop ) || command == Initialize_Routing_Table )
	{
		 if( service == N_UNITDATArequest )
		 {
			npci[0] = 0x01;   /*VERSION*/
			npci[1] = 0xF0;   /*network message, DNET, DLEN, Hopcount, SNET,SLEN=0*/
			npci[2] = 0xFF;   /*global networks*/
			npci[3] = 0xFF;   /*global networks*/
			npci[4] = 0;      /*broadcast MAC DADR*/
			
		
			memcpy( &npci[5], &panel_net_info.network_number, 2 );  /*SNET*/
			npci[7] = Station_NUM;      /*SADR*/
			npci[8] = 3;                /*HopCount*/
			npci[6] = 0;

			npci[9] = command;       /*I_Am_Router_To_Network;*/
			l = 10;
      	if( command!=Initialize_Routing_Table )
      	{
	     	if(send==2)
	     	{  /* send only PTP in OUTBOUND state*/
				if(!(prt_k->status^PTP_ACTIVE))
				{
            		pframe = SendFreeEntry( Port_parameters[ps->port].port, 0);					
					if( !pframe )	{	 	return 0;}
					memcpy( pframe->Buffer , npci,l );
					pframe->Length = l;
					pframe->FrameType = DATA_0;
        			/*SetByteBit(&pframe->flag,0,1,1);*/pframe->locked = 0;
/*							Unlockhead( pframe );*/
// TBD:						resume( Port_parameters[ps->port].base_task + PTP_TRANSMISSION );
				 }
			}
	     	else
	     	{
				if( command == I_Am_Router_To_Network_Prop )
				{
					npci[l++] = 1/*VendorID*/;
				}
				for(k=0; k<MAX_Routing_table; k++)
				{
					length_npci = l;
					if( (Routing_table[k].status&PORT_ACTIVE)==PORT_ACTIVE )
					{
						t=0;
						prt = &Routing_table[0];
						for(i=0; i<MAX_Routing_table; i++, prt++)
						{
							if( i!=k && ( (prt->status&PORT_ACTIVE)==PORT_ACTIVE) )
							{
								if( prt->Port.network )
								{
									s=0;
									if( prt->Port.network!=Routing_table[k].Port.network )
									{
										memcpy(&npci[length_npci], &prt->Port.network, 2 );
										length_npci += 2;
										if( command==I_Am_Router_To_Network_Prop )
										{
											npci[length_npci]=0;
											npci[length_npci+1]=0;
											if( (prt->status&PTP_ACTIVE)==PTP_ACTIVE )
											npci[length_npci] = prt->Port.address;
											length_npci += 2;
										}
										s=1;
									}
						/* not reachable networks for mini in this version
								for( j=0; j<MAX_reachable_networks; j++ )
					        if( Routing_table[i].Port.networks_list[j].status == 0x03 )
									{
										if( Routing_table[i].Port.networks_list[j].network!=Routing_table[k].Port.network )
										{
											memcpy(&npci[length_npci], &Routing_table[i].Port.networks_list[j].network, 2 );
											length_npci += 2;
											if( command==I_Am_Router_To_Network_Prop )
											{
						           if(Routing_table[i].Port.networks_list[j].half_router_address==0)
							           npci[length_npci] = Routing_table[i].Port.networks_list[j].router_address;
            					 else
						           	 npci[length_npci] = Routing_table[i].Port.networks_list[j].half_router_address;
											 npci[length_npci+1]=0;
											 length_npci += 2;
											}
											s=1;
										}
									}
*/
									if(s) t++;
								}
						 	}
						}
						/* build frame */
            			pframe = SendFreeEntry( Port_parameters[k].port, 0 );
						
						if( !pframe ) {	  return 0;}
						memcpy( pframe->Buffer , npci,length_npci );
						pframe->Length = length_npci;
						if( !(Routing_table[k].status^PTP_ACTIVE) )
						{
							pframe->FrameType = DATA_0;
              				/*SetByteBit(&pframe->flag,0,1,1);*/pframe->locked = 0;
/*							Unlockhead( pframe );*/
//TBD:							resume( Port_parameters[k].base_task + PTP_TRANSMISSION );
						}
						else if( (Routing_table[k].status & RS485_ACTIVE ) == RS485_ACTIVE )
						{
							if(t||send)
							{
								pframe->FrameType = BACnetDataNotExpectingReply;
								pframe->Destination = 255;
								pframe->Source = Station_NUM;
               					/*SetByteBit(&pframe->flag,0,1,1);*/pframe->locked = 0;
/*								Unlockhead( pframe );*/
/*								resume( Port_parameters[k].base_task );*/
							}
							else
							{
								RemoveSentEntry( pframe );	
							}
						}
						else
						{
							RemoveSentEntry( pframe );
						}
						
					}
				}
			}
     	}
		else /*Initialize_Routing_Table)*/
	   	{
/*
   1 byte :  Number of ports
//   2 bytes:  Connected DNET
//   1 byte :  Port ID   :  0  -  purje the DNET from routing table
*/
/*		  m1 = l++;*/
/*
// not enough space. I eliminate it for mini
			length_npci = l+1;
			k=ps->port;
			t=0;
			for(i=0; i<MAX_Routing_table; i++)
			{
			 if( i!=k && ( (Routing_table[i].status&PORT_ACTIVE)==PORT_ACTIVE) )
			 {
				 s=0;
				 if( Routing_table[i].Port.network!=Routing_table[k].Port.network )
				 {
					memcpy(&npci[length_npci], &Routing_table[i].Port.network, 2);
					length_npci += 2;
					npci[length_npci++]=0;
					s=1;
				 }
				 for(j=0; j<MAX_reachable_networks; j++)
					if( Routing_table[i].Port.networks_list[j].status == 0x03 )
					{
					 if( Routing_table[i].Port.networks_list[j].network!=Routing_table[k].Port.network )
					 {
						memcpy(&npci[length_npci], &Routing_table[i].Port.networks_list[j].network, 2);
						length_npci += 2;
						npci[length_npci++]=0;
						s=1;
					 }
					}
				 if(s) t++;
			 }
			}
			npci[l] = t;
			if(t)
			{
			 if(!(Routing_table[k].status^PTP_ACTIVE))
			 {  // do not send on ptp
					;
			 }
			 if( (Routing_table[k].status&RS485_ACTIVE)==RS485_ACTIVE )
			 {
            pframe = SendFreeEntry( Port_parameters[k].port, 0, 0 );
						if( !pframe )
							return 0;
						memcpy( pframe->Buffer , npci,length_npci );
						pframe->Length = length_npci;
						pframe->FrameType = BACnetDataNotExpectingReply;
						pframe->Destination = 255;
						pframe->Source = Station_NUM;
            pframe->locked = 0;
						resume( Port_parameters[k].base_task );
			 }
			}
*/

				k=ps->port;
				length_npci = l+1;
				prt_k = &Routing_table[k];
				memcpy(&npci[length_npci], &prt_k->Port.network, 2);
				length_npci += 2;
				npci[length_npci++]=0;
				t=1;
				for(j=0; j<MAX_reachable_networks; j++)
				if( prt_k->Port.networks_list[j].status == 0x03 ) /*REACHABLE*/
			   	{
					for(i=0; i<MAX_Routing_table; i++)
					{
						if(i!=k && prt_k->Port.networks_list[j].network==Routing_table[i].Port.network) 	break;
					}
					if(i>=MAX_Routing_table)
					{
						memcpy(&npci[length_npci], &prt_k->Port.networks_list[j].network, 2);
						length_npci += 2;
						npci[length_npci++]=0;
						t++;
					}
				}
			  	npci[l] = t;  /*m1*/

				for(i=0; i<MAX_Routing_table; i++)
			  	{
			   		if( i!=k && ( (Routing_table[i].status&PORT_ACTIVE)==PORT_ACTIVE) )
			   		{
							/* build frame */
	            		pframe = SendFreeEntry( Port_parameters[i].port, 0 );
						if( !pframe )			{				return 0;}
						memcpy( pframe->Buffer , npci,length_npci );
						pframe->Length = length_npci;
						if( !(Routing_table[i].status^PTP_ACTIVE) )
						{
							pframe->FrameType = DATA_0;
							/*SetByteBit(&pframe->flag,0,1,1);*/pframe->locked = 0;
							/*							Unlockhead( pframe );*/
							//TBD:							resume( Port_parameters[i].base_task + PTP_TRANSMISSION );
						}
						else if( (Routing_table[i].status & RS485_ACTIVE ) == RS485_ACTIVE )
						{
							if(t||send)
							{
								pframe->FrameType = BACnetDataNotExpectingReply;
								pframe->Destination = 255;
								pframe->Source = Station_NUM;
								/*SetByteBit(&pframe->flag,0,1,1);*/pframe->locked = 0;
								/*								Unlockhead( pframe );*/
								/*								resume( Port_parameters[i].base_task );*/
							}
							else
							{
								RemoveSentEntry( pframe );
							}
						}
						else
						{
							RemoveSentEntry( pframe );
						}
		   			}
		  		}
	   		}
    	}  // end service == N_UNITDATArequest

		else if( service == DL_UNITDATAindication )
		{
		   if( command == Initialize_Routing_Table )
		   {
				i = *dat;
				dat++;
				for(j = 0; j<i; j++)
				{
					l = *((S16_T *)dat);
					dat += 2;
					if(!(*dat))
					{
						for(k=0; k<MAX_reachable_networks; k++)
						if( prt_k->Port.networks_list[k].status == 0x03 )/*REACHABLE*/
						{
							if( prt_k->Port.networks_list[k].network==l )
							{
								memset( &prt_k->Port.networks_list[k], 0, sizeof(Reachable_Networks));
							}
						}
					}
		      		dat++;
				}
			} // end if(command == Initialize_Routing_Table)
			else
			{
				if( ((prt_k->status&PTP_ACTIVE)==PTP_ACTIVE) )
				{
					prt_k->Port.network = NL_parameters->SNET;
					prt_k->Port.address = NL_parameters->S_MAC_ADR[0];
				}
				for(l=0;l<MAX_reachable_networks;l++)
					if(prt_k->Port.networks_list[l].router_address == NL_parameters->S_MAC_ADR[0] )
						memset( &prt_k->Port.networks_list[l], 0, sizeof(Reachable_Networks) );
				
				if( command == I_Am_Router_To_Network_Prop )			k = 4;
				else													k = 2;
				
				for( i=0; i<(length/k); i++)
				{
					j = *((S16_T *)dat);
					if( j != NL_parameters->SNET ||	prt_k->Port.address!=NL_parameters->S_MAC_ADR[0] )
					{
						l=MAX_reachable_networks;
						if( (prt_k->status&PTP_ACTIVE)!=PTP_ACTIVE )
						{
							for(l=0;l<MAX_Routing_table;l++)
							{
	/* if one port that has the same network number as 'j' (another network connection) and that port
	 is active, the 'j' network will not connect properly to this network*/
					    		if( Routing_table[l].Port.network==j && ((Routing_table[l].status&PORT_ACTIVE)==PORT_ACTIVE) ) break;
				     		}
	          			}	
						if(l>=MAX_reachable_networks)
						{
							for(l=0;l<MAX_reachable_networks;l++)
								if(prt_k->Port.networks_list[l].network == j) break;
			
							if(l>=MAX_reachable_networks)
							{
								rn = &prt_k->Port.networks_list[0];
								for(l=0;l<MAX_reachable_networks;l++,rn++)
									if(!rn->network) break;
								if(l<MAX_reachable_networks)
								{
									rn->status = 0x03; /*REACHABLE*/
									rn->network = j;
									rn->router_address = NL_parameters->S_MAC_ADR[0];
									if( command==I_Am_Router_To_Network_Prop )
									{
										rn->half_router_address = *((S16_T *)(dat+2));
									}
									else
										rn->half_router_address = 0;
								}
							}
						}// end if(l>=MAX_reachable_networks)
					}//end if( j != NL_parameters->SNET ||	prt_k->Port.address!=NL_parameters->S_MAC_ADR[0] )
	
					if( command==I_Am_Router_To_Network_Prop )			dat += 4;
					else			dat += 2;
				}//end for...
			}
		} // end if(command != Initialize_Routing_Table)
	} // end service == DL_UNITDATAindication
}


#endif
