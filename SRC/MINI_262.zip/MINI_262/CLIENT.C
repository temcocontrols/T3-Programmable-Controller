#define _CLIENT_DOT_C


#include <string.h>
#include <stdlib.h>
#include "base_str.h"
#include "bacnet.h"
#include "data.h"
#include "const.h"
#include "applayer.h"
#include "netlayer.h"

#define ON   	1
#define OFF  	0
#define FALSE   0
#define TRUE   1

S8_T getID(void)
{
	return ( rand() % 255 );
}


/* decode the apdu form Server application */
void ClietTransactionStateMachine(S8_T* apdu,Protocol_parameters *ps)
{
	TSMTable *PTRtable;
	ServicePrimitive primitive;
	S8_T STSM_SEG, STSM_MOR, STSM_SA, STSM_MaxResp, STSM_InvokeID;
	S8_T STSM_NoSeq=1, STSM_WinSize, STSM_Service, STSM_SRV;
	U16_T n,length_apci,STSM_Event;
    U16_T length_apdu;


	PTRtable = Server_TSM_table;

	STSM_Event = apdu[0]>>4;
	length_apdu = PTRtable->length_apdu;
	/* there are 8 BACnetPDU : */
	/*	apdu[0] apdu data type ,range is 0 ~ 15	 */
	switch ( STSM_Event )
	{			
		case BACnetSimpleACKPDU: // 2 -- dont have user data
			STSM_InvokeID = apdu[1];
			STSM_Service =  apdu[2];
			primitive = CONF_SERVrequest;
			 n=3; 
		case BACnetComplexACKPDU: // 3
			STSM_SEG = (apdu[0]&0x08)?1:0;
			STSM_MOR = (apdu[0]&0x04)?1:0;
			STSM_SA = (apdu[0]&0x02)?1:0;
			STSM_InvokeID = apdu[1];
			 STSM_Service = apdu[1];
			 if( STSM_SEG == TRUE )
			 {
				STSM_NoSeq = apdu[2];
				STSM_WinSize = apdu[3];
				STSM_Service = apdu[4];
				n=5;
			 }
			 else
			 {
				STSM_Service = apdu[2];
				n = 3;	/* n is the length of PCI*/
			 }	
		 	 primitive = CONF_SERVrequest;
			 break;
		case BACnetSegmentACKPDU:  // 4
	/*				7		6		5		4		3		2		1		0
	PCI	  apdu[0]       PDU Type = B'0100'		   0		0		NAK 	SRV		 	
		  apdu[1]			original Invoke ID
		  apdu[2]		sequence Number						
		  apdu[3]		Proposed Window Size
		
	note: this type dont have USER DATA
	*/
			 STSM_SRV      = (apdu[0]&0x01)?1:0;
			 STSM_InvokeID = apdu[1];
			 STSM_NoSeq    = apdu[2];
			 STSM_WinSize  = apdu[3];
			 n=4;
			 if( STSM_SRV == TRUE )
			 {
				/*
				LengthReceivedClientAPDU = NL_parameters.length_apdu;
				PTRReceivedClientAPDU = NL_parameters.apdu;
				*/
				return;
			 }
			 break;
		 case BACnetErrorPDU:
		 	

			break;
		 case BACnetRejectPDU: // 6

			 STSM_SRV      = (apdu[0]&0x01)?1:0;
			 STSM_InvokeID = apdu[1];
			 n=3;
			 break;
		 case BACnetAbortPDU: // 7
			 STSM_SRV      = (apdu[0]&0x01)?1:0;
			 STSM_InvokeID = apdu[1];
			 n=3;
			 break;
		default:
			 return;
	}

	if( PTRtable->state == STSM_ILLEGAL )
	{
		TSM_init( PTRtable, NULL );
      	PTRtable->reply_flag = 0;
	}
	#if 1
	switch (PTRtable->state )
	{
		case CTSM_IDLE: /* In the IDLE state, the device waits for the local application program to request a service */
		if(STSM_Event == CONF_SERVrequest && )
		break;
		case CTSM_SEGMENTING_REQUEST:
		break;
		case CTSM_AWAIT_CONFIRMATION:
		break;
		case CTSM_AE_SEGMENTED_CONFIRMATION:
		break;
		default:
		break;
	}
	#endif
}


/*
void client_task(void)
{
 Protocol_parameters *ps;


}
*/
