/**********************************************************************

						Conversion and initialization routines

**********************************************************************/

#define _CONTROL_DOT_C

#include "main.h"
/*#define TEST_C*/

#ifdef BACNET
#define FILTER_ADJUST 4




S16_T exec_program(S16_T current_prg, U8_T *prog_code, S16_T port);
void control_task( void );


#define DIG1 100
#define SENSOR_DELAY 10




/*
 * ----------------------------------------------------------------------------
 * Function Name: get_no_ins_outs
 * Purpose: 
 * Params:
 * Returns:
 * Note:
 * ----------------------------------------------------------------------------
 */
void get_no_ins_outs( void )
{
	no_ins = 0;
	no_outs = 0;
	memset(in_out_data,'\0',MAX_IO_POINTS );
//	memset(in_aux, 0, MAX_INS*sizeof(In_aux));
	/* cards_status can be set by either get_card_status() or by the user */
	cards_type = 0;
	channel_desc = 0;

	//no_ins = 5;
	//no_outs = 4;
	#if 0
	switch( cards_status_AB & 0x0f)
	{ /* Port 1 */
		case 1: no_ins += 16; channel_desc |= 0x03; cards_type |= 0x01; break;
		case 2: no_outs += 16; cards_type |= 0x02; break;
		case 3: no_ins += 8; no_outs += 8; channel_desc |= 0x01;
						cards_type |= 0x03; break;
	}
	switch( cards_status_AB & 0x0f0 )
	{
		/* Port 2 */
		case 0x10: no_ins += 16; channel_desc |= 0x00C; cards_type |= 0x04; break;
		case 0x20: no_outs += 16; cards_type |= 0x08; break;
		case 0x30: no_ins += 8; no_outs += 8; channel_desc |= 0x04;
						 cards_type |= 0x0C; break;
	}
	switch( cards_status_CD & 0x0f)
	{
		/* Port 3 */
		case 1: no_ins += 16; channel_desc |= 0x030; cards_type |= 0x10; break;
		case 2: no_outs += 16; cards_type |= 0x20; break;
		case 3: no_ins += 8; no_outs += 8; channel_desc |= 0x010;
						cards_type |= 0x30; break;
	}
	switch( cards_status_CD & 0x0f0 )
	{
		/* Port 4 */
		case 0x10: no_ins += 16; channel_desc |= 0x00C0; cards_type |= 0x40; break;
		case 0x20: no_outs += 16; cards_type |= 0x80; break;
		case 0x30: no_ins += 8; no_outs += 8; channel_desc |= 0x040;
						 cards_type |= 0x0C0; break;
	}
	#endif
	
/*	no_outs = MAX_IO_POINTS - no_ins; */
}


/*
 * ----------------------------------------------------------------------------
 * Function Name: init_info_in_out
 * Purpose: 
 * Params:
 * Returns:
 * Note:
 * ----------------------------------------------------------------------------
 */
void init_info_in_out( void )
{
	Info_Table *inf;
	table_bank[0] = no_outs;
	table_bank[1] = no_ins;
	inf = &info[0];
	inf->address = (S8_T *)outputs;
	inf->size = sizeof( Str_out_point );
	inf->max_points = no_outs;
	inf = &info[1];
	inf->address = (S8_T *)inputs;
	inf->size = sizeof( Str_in_point );
	inf->max_points = no_ins;
}

/*char * TEST_IN[5] = {"INPUT1","INPUT2","INPUT3","INPUT4","INPUT5"};
char * TEST_OUT[2] = {"OUTPUT1","OUTPUT2"};
char TEST_VAR[6][20] = {"VAR0","VAR1","VAR2","VAR3","VAR4","VAR5"};*/
//extern U8_T test[500];
/*char TEST_IN[16][20] = {
"AAAAAAAAAAAAAAAAAAAA","BBBBBBBBBBBBBBBBBBBB","CCCCCCCCCCCCCCCCCCCC","DDDDDDDDDDDDDDDDDDDD",
"EEEEEEEEEEEEEEEEEEEE","FFFFFFFFFFFFFFFFFFFF","GGGGGGGGGGGGGGGGGGGG","HHHHHHHHHHHHHHHHHHHH",
"IIIIIIIIIIIIIIIIIIII","JJJJJJJJJJJJJJJJJJJJ","KKKKKKKKKKKKKKKKKKKK","LLLLLLLLLLLLLLLLLLLL",
"MMMMMMMMMMMMMMMMMMMM","NNNNNNNNNNNNNNNNNNNN","OOOOOOOOOOOOOOOOOOOO","PPPPPPPPPPPPPPPPPPPP"
};
*/

void init_in_out( void )
{
	Str_points_ptr ptr;
	int i,j;
	no_ins = 34;
	no_outs = 24;

    memset(Input, '\0', 2432/*MAX_IO_POINTS *sizeof(Str_in_point)*/ );
	memset(Output,'\0', 2560/*MAX_IO_POINTS *sizeof(Str_out_point)*/ );
//	memset( in_aux, '\0', MAX_IO_POINTS*sizeof( In_aux ) );

	inputs = ( Str_in_point * ) Input;
	outputs = ( Str_out_point * ) Output;	

	if( no_ins )
	{
		ptr.pin = inputs;
		for( i=0; i< no_ins; i++, ptr.pin++ )
		{
			ptr.pin->value = 0;  
			memcpy(ptr.pin->description,"test",5);	
			SetByteBit(&ptr.pin->flag1,0,in_auto_manual,1);  // auto
			SetByteBit(&ptr.pin->flag2,1,in_digital_analog,1); // analog
			
		}
	}
	if( no_outs )
	{
		ptr.pout = outputs;
		for( i=0; i<no_outs; i++, ptr.pout++ )
		{
			ptr.pout->value = 0;
			
			if(i < 12)   // digital outputs
			{
				ptr.pout->range = 101;
				SetByteBit(&ptr.pout->flag1,0,out_digital_analog,1);
			}
			else 	
			{			// analog outputs
				ptr.pout->range = 1;
				SetByteBit(&ptr.pout->flag1,1,out_digital_analog,1);

			}

			memcpy(ptr.pout->description,"test1",5);	
			SetByteBit(&ptr.pout->flag1,0,out_auto_manual,1);
		}
	}
/*	cards_info.cards_status_AB = cards_status_AB;
	cards_info.cards_status_CD = cards_status_CD;
	cards_info.channel_descriptor = channel_desc;
	cards_info.cards_type = cards_type;*/
//	cards_info.power_down++;

	

}


void init_panel(void)
{
	int i,j;
	Str_points_ptr ptr;
	U8_T flag_read;

	ind_alarms = 0;
	ind_alarms_set = 0;
	memset(controllers,'\0',MAX_CONS*sizeof(Str_controller_point));
	memset(programs,'\0',MAX_PRGS *sizeof(Str_program_point));
	ptr.pprg = programs;
	for( i=0; i<MAX_PRGS; i++, ptr.pprg++ )
	{
	/*	ptr.pprg->on_off = 1;*/
		SetByteBit(&ptr.pprg->flag1,0,prg_on_off,1); 
		SetByteBit(&ptr.pprg->flag1,0,prg_auto_manual,1); /* auto/manual*/
	} //test by chelsea	
	memset(program_address, '\0',MAX_PRGS *sizeof(S8_T *));
	memset(_code, '\0', MAX_PRGS * 640);
	for(i = 0;i < MAX_PRGS;i++)		program_address[i] = &_code[i]; // program_address pointer to code
	code_length = 0;

	memset(vars,'\0',MAX_VARS*sizeof(Str_variable_point));
	ptr.pvar = vars;
	for( i=0; i<MAX_VARS; i++, ptr.pvar++ )
	{
	//	for(j = 0;j<4;j++)	ptr.pvar->description[j] = TEST_VAR[0][j];
	//	memcpy(ptr.pvar->description,"test2                ",21);	
		ptr.pvar->value = 0;
		SetByteBit(&ptr.pvar->flag,0,var_digital_analog,1);/*ptr.pvar->auto_manual = 1; */
		SetByteBit(&ptr.pvar->flag,1,var_digital_analog,1);/*ptr.pvar->digital_analog = 1; *///analog point 
		SetByteBit(&ptr.pvar->flag,2,var_unused,3);/*ptr.pvar->unused = 2;*/

		ptr.pvar->range = 0;
	}



	memset( control_groups,'\0', MAX_GRPS * sizeof( Control_group_point) );
	memset( aux_groups,'\0', MAX_GRPS * sizeof( Aux_group_point) );
	memset( group_data, '\0', MAX_ELEMENTS * sizeof( Str_grp_element) );
	total_elements = 0;
	group_data_length = 0;
	ptr.pgrp = control_groups;
	for( i=0; i<MAX_GRPS; i++, ptr.pgrp++ )
	{
		ptr.pgrp->update = 15;
	}



	memset(controllers,'\0',MAX_CONS*sizeof(Str_controller_point));
	memset(con_aux,'\0',MAX_CONS*sizeof(Con_aux));
	memset(custom_tab,'\0',MAX_TBLS*16*sizeof(Tbl_point));
	memset(&passwords,'\0',sizeof(Password_struct));

	memset(network_points_list,0,sizeof(network_points_list));
	number_of_network_points=0;
	memset(remote_points_list,0,sizeof(remote_points_list));
	number_of_remote_points=0;
	
#if 0


 	memset(&network_points_list[0],0,(S8_T*)&system_flags_3c-(S8_T*)&network_points_list[0]);


#endif

	memset( weekly_routines,'\0',MAX_WR*sizeof(Str_weekly_routine_point));
	memset( wr_times,'\0',MAX_WR*9*sizeof(Wr_one_day ));
	memset( annual_routines,'\0',MAX_AR*sizeof(Str_annual_routine_point));
	memset( ar_dates,'\0',MAX_AR*46*sizeof(S8_T));
	memset( totalizers,'\0',MAX_TOTALIZERS*sizeof(Str_totalizer_point));

	memset(arrays,'\0',MAX_ARRAYS*sizeof(Str_array_point));
	memset(arrays_data,'\0',MAX_ARRAYS*sizeof(S32_T *));
	memset(units,'\0',MAX_UNITS*sizeof(Units_element));

#if 1
	memset( monitors,'\0',MAX_MONITORS*sizeof(Str_monitor_point));
	memset( mon_aux,'\0',MAX_MONITORS*sizeof(Mon_aux) );
//	mon_block = flash_data;  // tbd: changed by chelsea
	memset( mon_block,'\0',MAX_MONITOR_BLOCKS*sizeof(Monitor_Block) );
	ptr.pmon = monitors;
	for( i=0; i<MAX_MONITORS; i++, ptr.pmon++ )
	{
		ptr.pmon->minute_interval_time = 15;
	/*	monitors[i].data_length = 72;	*/
	/*	monitors[i].unit = 1;*/
		//ptr.pmon->double_flag=1;
		SetByteBit(&ptr.pmon->flag2,1,mon_double_flag,1);
	}
	free_mon_blocks = MAX_MONITOR_BLOCKS;
#endif
	
	memset(alarms,'\0',MAX_ALARMS*sizeof(Alarm_point));
	memset(alarms_set,'\0',MAX_ALARMS_SET*sizeof(Alarm_set_point));

	IntFlashReadByte(0x70000 + 0xfff0,&flag_read);
	Test[48] = flag_read;
	if(flag_read == 0x55)
	{
		//Flash_Read_Mass();	
	}
	memset(network_points_list,0,sizeof(network_points_list));
	number_of_network_points=0;
	memset(remote_points_list,0,sizeof(remote_points_list));
	number_of_remote_points=0;
	init_info_in_out();
	init_info_table();
}


void init_info_table( void )
{
	int i;
	Info_Table *inf;

	inf = &info[2];
	for( i=2; i<MAX_INFO_TYPE; i++, inf++ )
	{
		switch( i )
		{
			case VAR:
				inf->address = (S8_T *)vars;
				inf->size = sizeof( Str_variable_point );
				inf->max_points =  MAX_VARS;
				break;
			case CON:
				inf->address = (S8_T *)controllers;
				inf->size = sizeof( Str_controller_point );
				inf->max_points = MAX_CONS;
				break;
			case WRT:
				inf->address = (S8_T *)weekly_routines;
				inf->size = sizeof( Str_weekly_routine_point );
				inf->max_points = MAX_WR;
				break;
			case AR:
				inf->address = (S8_T *)annual_routines;
				inf->size = sizeof( Str_annual_routine_point );
				inf->max_points = MAX_AR;
				break;
			case PRG:
				inf->address = (S8_T *)programs;
				inf->size = sizeof( Str_program_point );
				inf->max_points = MAX_PRGS;
				break;
			case TBL:
				inf->address = (S8_T *)custom_tab;
				inf->size = sizeof( Str_table_point );
				inf->max_points = MAX_TBLS;
				break;
			case TZ:
				inf->address = (S8_T *)totalizers;
				inf->size = sizeof( Str_totalizer_point );
				inf->max_points = MAX_TOTALIZERS;
				break;
			case AMON:
				inf->address = (S8_T *)monitors;
				inf->size = sizeof( Str_monitor_point );
				inf->max_points = MAX_MONITORS;
				break;
			case GRP:
				inf->address = (S8_T *)control_groups;
				inf->size = sizeof( Control_group_point );
				inf->max_points = MAX_GRPS;
				break;
			case ARRAY:
				inf->address = (S8_T *)arrays;
				inf->size = sizeof( Str_array_point );
				inf->max_points = MAX_ARRAYS;
				break;
			case ALARMM:          // 12
				inf->address = (S8_T *)alarms;
				inf->size = sizeof( Alarm_point );
				inf->max_points = MAX_ALARMS;
				break;
			case ALARM_SET:         //15
				inf->address = (S8_T *)alarms_set;
				inf->size = sizeof( Alarm_set_point );
				inf->max_points = MAX_ALARMS_SET;
				break;
			case UNIT:
				inf->address = (S8_T *)units;
				inf->size = sizeof( Units_element );
				inf->max_points = MAX_UNITS;
				break;
			case USER_NAME:
				inf->address = (S8_T *)&passwords;
				inf->size = sizeof( Password_point );
				inf->max_points = MAX_PASSW;
				break;
			case WR_TIME:
				inf->address = (S8_T *)wr_times;
				inf->size = 9*sizeof( Wr_one_day );
				inf->max_points = MAX_SCHEDULES_PER_WEEK;
				break;
			case AR_DATA:               // 17 ar_dates[MAX_AR][AR_DATES_SIZE];
				inf->address = (S8_T *)ar_dates;
				inf->size = AR_DATES_SIZE;
				inf->max_points = MAX_AR;
				break;
		}
	}
}


#if  1
void Controller( S16_T p_number )
{
 /* The setpoint and input point can only be local to the panel even
		though the structure would allow for points from the network segment
		to which the local panel is connected */
	S32_T op, oi, od, err, erp, out_sum;
/*  err = percent of error = ( input_value - setpoint_value ) * 100 /
					proportional_band	*/
/*	sample_time = 10L;        seconds */

#if 1
	U16_T prop;
	S32_T l1;
	Str_controller_point *con;
	Con_aux *conx;
	S32_T temp_input_value,temp_setpoint_value;
	
	con = &controllers[p_number];
	conx = &con_aux[p_number];
	get_point_value( (Point*)&con->input, &con->input_value );
	get_point_value( (Point*)&con->setpoint, &con->setpoint_value );

	od = oi = op = 0;


	prop = GetByteBit(con->flag,con_prop_high,4);//con->prop_high;	
	prop <<= 8;
	prop += con->proportional;

	temp_input_value = DoulbemGetPointWord2(con->input_value);
	temp_setpoint_value = DoulbemGetPointWord2(con->setpoint_value); 

	err = temp_input_value - temp_setpoint_value;  /* absolute error */
	
	erp = 0L;
/* proportional term*/
	if( prop )
		erp = 100L * err / prop;
	if( erp > 100000L ) erp = 100000L;
	if( !/*(bit)*/GetByteBit(con->flag,con_action,1)/*con->action */)
		op = erp; /* + */
	else
		op = -erp; /* - */

	erp = 0L;
/* integral term	*/

	l1 = ( conx->old_err + err ) * 5; /* 5 = sample_time / 2 */
	l1 += conx->error_area;
	if( conx->error_area >= 0 )
	{
		 if( l1 > 8388607L )
				l1 = 8388607L;
	}
	else
	{
		 if( l1 < -8388607L )
				l1 = -8388607L;
	}
	conx->error_area = l1;

	if( con->reset )
	{
		if( !/*(bit)*/GetByteBit(con->flag,con_action,1))
			oi = con->reset * conx->error_area;
		else
			oi -= con->reset * conx->error_area;
		if(/*(bit)*/GetByteBit(con->flag,con_repeats_per_min,1) )
			oi /= 60L;
		else
			oi /= 3600L;
	}
/* differential term	*/
	if( con->rate )
	{
		od = conx->old_err * 100;
		od /= prop;
		od = erp - od;
		if(!/*(bit)*/GetByteBit(con->flag,con_action,1))
		{
/*			od = ( erp - conx->old_err * 100 / prop ) * con->rate / 600L;
																						/* 600 = sample_time * 60  */
			od *= con->rate;
		}
		else
		{
/*			od = -con->rate * ( erp - conx->old_err
						* 100 / prop ) / 600L; /* 600 = sample_time * 60  */
			od *= ( -con->rate );
		}
		od /= 600L; 	/* 600 = sample_time * 60  */
	}

	out_sum = op + con->bias + od;

	if( out_sum > 100000L ) out_sum = 100000L;
	if( out_sum < 0 ) out_sum = 0;
	if( con->reset )
	{
		 out_sum += oi;
		 if( out_sum > 100000L )
		 {
				out_sum = 100000L;
		 }
		 if( out_sum < 0 )
		 {
			out_sum = 0;
		 }
	}
	conx->old_err = err;
	
	con->value = DoulbemGetPointWord2(out_sum);
#endif

}

#if 0
S32_T test_match( S16_T range, U8_T raw )
{
	int index;
	S32_T val;
	int work_var;
	int ran_in;
	int delta = MIDDLE_RANGE;
	U8_T *def_tbl;
	S8_T end = 0;
	range--;
	
	ran_in = (U8_T)range;
//	range /= 2;
	range >>= 1;
	def_tbl = ( U8_T * )&def_tab[(U8_T)range];
	
	if( raw <= (U8_T)def_tbl[NO_TABLE_RANGES])
		return limit[ran_in][1];
	if( raw >= (U8_T)def_tbl[0])
		return limit[ran_in][0];
	index = MIDDLE_RANGE;

	while( !end )
	{
		if( ( raw >= def_tbl[index] ) && ( raw <= def_tbl[index-1] ) )
		{
			index--;
			delta = def_tbl[index] - def_tbl[index+1];

			if( delta )
			{
				work_var = (int)( ( def_tbl[index] - raw ) * 100 );
				work_var /= delta;
				work_var += ( index * 100 );
				val = tab_int[ran_in];
				val *= work_var;
				val /= 100;
				val += limit[ran_in][0];
			}
			
			return val;
		}
		else
		{
			if( !delta )
				end = 1;
			delta /= 2;
			if( raw < def_tbl[index] )
				index += delta;
			else
				index -= delta;
			if( index <= 0 )
				return limit[ran_in][0];
			if( index >= NO_TABLE_RANGES )
				return limit[ran_in][1];
		}
	}
}
#endif

#if 1
S32_T test_match( S16_T range, S16_T raw )
{
	int index;
	S32_T val;
	int work_var;
	int ran_in;
	int delta = MIDDLE_RANGE;
	U8_T *def_tbl;
	S8_T end = 0;
	range--;
	
	ran_in = (U8_T)range;
//	range /= 2;
	range >>= 1;
	
	def_tbl = &bac_def_tab[range];

/*	uart1_PutChar(' ');
	print_dat(range);
	uart1_PutChar(' ');
	uart1_PutChar(' ');
	print_dat(def_tbl[NO_TABLE_RANGES]);
	uart1_PutChar(' ');
*/									
	if( raw <= (U16_T)def_tbl[NO_TABLE_RANGES])
		return limit[ran_in][1];
	if( raw >= (U16_T)def_tbl[0])
		return limit[ran_in][0];
	index = MIDDLE_RANGE;

	while( !end )
	{
		if( ( raw >= def_tbl[index] ) && ( raw <= def_tbl[index-1] ) )
		{
			index--;
			delta = def_tbl[index] - def_tbl[index+1];

			if( delta )
			{
				work_var = (int)( ( def_tbl[index] - raw ) * 100 );
				work_var /= delta;
				work_var += ( index * 100 );
				val = tab_int[ran_in];
				val *= work_var;
				val /= 100;
				val += limit[ran_in][0];
			}
			
			return val;
		}
		else
		{
			if( !delta )
				end = 1;
			delta /= 2;
			if( raw < def_tbl[index] )
				index += delta;
			else
				index -= delta;
			if( index <= 0 )
				return limit[ran_in][0];
			if( index >= NO_TABLE_RANGES )
				return limit[ran_in][1];
		}
	}
}
#endif


S32_T test_match_custom( S16_T range, S16_T raw )
{   /* custom tables */

	Tbl_point *table_point;
	int index = 1;
	S32_T val, diff;
	range -= table1;
	do
	{
		 table_point = &custom_tab[range].dat[index];
		 if( ( raw == table_point->value ) )
		 {
				return table_point->unit;
		 }
		 if( ( raw < table_point->value ) &&
				( raw > (table_point-1)->value ) )
			{ index--; break; }
		 else
			index++;
	}
	while( index <= 14 );

	table_point = &custom_tab[range].dat[index];
	index = (table_point+1)->value - table_point->value;
	if( index )
	{
/*		val = ( raw - table_point->value ) * 1000 /
			( (table_point+1)->value - table_point->value );*/
		val = ( raw - table_point->value );
		val *= 1000;
		val /= index;
	}
	diff = (table_point+1)->unit - table_point->unit;
	if( diff )
	{
/*		val = table_point->unit + val *
			( (table_point+1)->unit - table_point->unit );*/
		val *= diff;
		val /= 1000;
		val += table_point->unit;
	}
	return val;
}



void Control_Output(U16_T value, U8_T index);
signed int RangeConverter(unsigned char function, signed int para,unsigned int cal);

void convert_in()
{
	Str_in_point *ins;
	In_aux *inx;
	S32_T val = 0;
	int point;
	U32_T sample;
	S8_T in_data_index;
//	S8_T mask;
	U8_T  temp;
	U32_T tempvalue;

	if( !no_ins ) return;
	ins = inputs;
	inx = in_aux;

//	mask = 1;
	in_data_index = 0;

	point=0;

	
#if 0
	/* find the first group of input channels */
	while( !( mask & channel_desc ) )
	{
		mask <<= 1;
		in_data_index += 8;
	}
#endif

	while( point < no_ins )
	{
		
		tempvalue = Modbus.INPUT[point * 2 + 1] * 256 + Modbus.INPUT[point * 2];
	//	tempvalue = (U32_T)DoulbemGetPointWord2(ins->value) / 1000;  

#if 1
		
// debug input value now.
		if( !/*(bit)*/GetByteBit(ins->flag1,in_auto_manual,1)/*ins->auto_manual*/ )
		{
			sample = tempvalue/*ins->value;// in_out_data[in_data_index]*/;			
			if( ins->range != not_used_input )
			{
					
				if( !/*(bit)*/GetByteBit(ins->flag2,in_digital_analog,1)/*ins->digital_analog*/ )
				{
					if( ins->range >= ON_OFF  && ins->range <= HIGH_LOW )  // control 0=OFF 1=ON
					{
							temp = (sample >128 ) ? 0 : 1;
							SetByteBit(&ins->flag1,temp,in_control,1);
					}
					else
					{
							temp = (sample < 128 ) ? 0 : 1;
							SetByteBit(&ins->flag1,temp,in_control,1);							
					}
					if( ins->range >= custom_digital1 && ins->range <= custom_digital8 )
					{
							temp = (sample < 128 ) ? 0 : 1;
							SetByteBit(&ins->flag1,temp,in_control,1);
					}
					ins->value = /*(bit)*/GetByteBit(ins->flag1,in_control,1) ? 1000L : 0;
				}
				else
				{
				
					if( system_flags.start )
						inx->last = sample;
					if( ins->range != N0_2_32counts && ins->range != P0_255p_min )
					{
						if( inx->last > ( sample + 31 ) && sample < 25 ) /* 10% of the total range */
						{
							if( !/*(bit)*/GetByteBit(ins->flag1,in_sen_on,1) )
							{
								SetByteBit(&ins->flag1,1,in_sen_on,1);
								inx->ticks = 0;
							}
							else
							{
								if( inx->ticks < SENSOR_DELAY )
									inx->ticks++;
							}
						}
						else
						{
							SetByteBit(&ins->flag1,0,in_sen_on,1);
						}
						if( sample > ( inx->last + 31 ) && sample > 225 ) /* 10% of the total range */
						{
							if( !/*(bit)*/GetByteBit(ins->flag1,in_sen_off,1) )
							{
								SetByteBit(&ins->flag1,1,in_sen_off,1);
								inx->ticks = 0;
							}
							else
							{
								if( inx->ticks < SENSOR_DELAY )
									inx->ticks++;
							}
						}
						else
						{
							SetByteBit(&ins->flag1,0,in_sen_off,1);
						}
						
						if( !/*(bit)*/GetByteBit(ins->flag1,in_sen_off,1) || (/*(bit)*/GetByteBit(ins->flag1,in_sen_on,1)) || ( inx->ticks >= SENSOR_DELAY ) )
						{
							#if 0
							
							if( inx->ticks >= SENSOR_DELAY )
								SetByteBit(&ins->flag1,1,in_decom,1);
							/* The filtering part */
							
						//	if(GetByteBit(ins->flag1,in_filter,3) )
							{
								if( system_flags.start )
								{
									inx->average = sample;
								}
								if( GetByteBit(ins->flag1,in_filter,3) != inx->filter_last || system_flags.start )
								{
									inx->filter_sum = ( (U32_T)inx->average ) <<( GetByteBit(ins->flag1,in_filter,3) + FILTER_ADJUST );
									inx->filter_last = GetByteBit(ins->flag1,in_filter,3);
								}

								if( ( (U16_T)sample > ( (U16_T)inx->average + 50 ) ) ||
										( (U16_T)inx->average > ( (U16_T)sample + 50 ) )    )
								{
									inx->filter_sum = (U16_T)inx->average + ( (U16_T)sample ) * 7;
									inx->filter_sum <<= ( GetByteBit(ins->flag1,in_filter,3) + FILTER_ADJUST - 3 );
								}
								else
								{
									inx->filter_sum += (U16_T)sample;
									inx->filter_sum -= (U16_T)inx->average;
								}

								inx->average = ( ( inx->filter_sum >>(GetByteBit(ins->flag1,in_filter,3) + FILTER_ADJUST ) ) & 0x00ff );
							}
/*								else inx->average = sample;*/
							
							sample = inx->average;
							#endif
						//	print_dat(sample);
						
							switch( ins->range )
							{
								case Y3K_40_150DegC:
								case Y3K_40_300DegF:
								case R3K_40_150DegC:
								case R3K_40_300DegF:
								case R10K_40_120DegC:
								case R10K_40_250DegF:
								case KM10K_40_120DegC:
								case KM10K_40_250DegF:
								case A10K_50_110DegC:
								case A10K_60_200DegF:
								//	if(ins->range == 2)	
								//	print_dat(tempvalue);
									val = (S16_T)test_match( ins->range, (S16_T)sample);
								//	val = (S16_T)RangeConverter(ins->range,tempvalue,128) ;
								//	print_dat(val);
									
									break;
								case V0_5:
									val =  ( sample * 5000L ) >> 8;
									break;
								case I0_100Amps:
									val = ( 100000L * sample ) >> 8;
									break;
								case I0_20ma:
									val = ( 20000L * sample ) >> 8;
									break;
								case I0_20psi:
									val = ( 20000L * sample ) >> 8;
									break;
								case N0_3000FPM_0_5V:
									val = ( 3000000L * sample ) >> 8;
									break;
								case P0_100_0_5V:
									val = ( 100000L * sample ) >> 8;
									break;
								case P0_100_4_20ma:
									val = 100000L * ( sample - 51 ) / 204;
									break;
								case table1:
								case table2:
								case table3:
								case table4:
								case table5:
									val = sample;
									val <<= 4;
									val = test_match_custom( (int)ins->range, (int)val );
									break;
								default:
									val = 0;
							}
							inx->last = sample;
						}
						else
							val = ins->value;
					}
					else
					{
						val = ins->value;
						switch( ins->range )
						{
							case N0_2_32counts:
								if( ( sample - inx->last ) > 151 )
									val += 1000;
								break;
							case P0_255p_min:
								if( ( sample - inx->last ) > 151 )
									inx->ticks++;
								break;
						}
						inx->last = sample;
					}

					if( /*(bit)*/GetByteBit(ins->flag2,in_calibration_increment,1) )
					{
						if( !/*(bit)*/GetByteBit(ins->flag2,in_calibration_sign,1) )
							val += 1000L * ins->calibration;
						else
							val += -1000L * ins->calibration;
					}
					else
					{
						if( !/*(bit)*/GetByteBit(ins->flag2,in_calibration_sign,1) )
							val += 100L * ins->calibration;
						else
							val += -100L * ins->calibration;
					}
				}
				//ins->value = val;
				ins->value = (U32_T)DoulbemGetPointWord2(val /** 1000*/);
			}
			else
			{
				//ins->value = 0;
				ins->value = (U32_T)DoulbemGetPointWord2(tempvalue * 1000);	
				inx->last = sample;
			}
		}
#endif
		in_data_index++;
		point++;
		ins++;
		inx++;
#if 0
		if( ( in_data_index & 0x07 ) == 0 )
		{
			/* find the next group of input channels */
			mask <<= 1;
			while( !( mask & channel_desc ) )
			{
				mask <<= 1;
				in_data_index += 8;
				if( in_data_index >= MAX_IO_POINTS )  /* MAX_IO_POINTS */
					break;
			}
		}
		if( in_data_index >= MAX_IO_POINTS )  /* MAX_IO_POINTS */
			break;
#endif
	}
	system_flags.start = 0;
}



void convert_out()
{
	Str_out_point *outs;
	U16_T point;
	U16_T delta;
	U32_T val;
	S32_T value;
	S8_T out_data_index;
//	S8_T mask, cards_type_copy;

	if( !no_outs ) return;

//	cards_type_copy = cards_type;
	outs = outputs;  // changed by chelsea 
//	memcpy(outs,Output,no_outs * 40);
//	mask = 1;
	out_data_index = 0;
	point = 0;

#if 0
	/* find the first group of output channels */
	while( mask & channel_desc )
	{
		mask <<= 1;
		out_data_index += 8;
		if( ( out_data_index & 0x0F ) == 0 )
			cards_type_copy >>= 2;
	}
#endif
	
	while( point < no_outs )
	{
		/*if( !( cards_type_copy & 0x03 ) )
		{
			val = 0;
		}
		else*/
		{
			if( outs->range == not_used_output )
			{
				outs->value = 0L;
				val = 0;
			}
			else
			{
				if( !/*(bit)*/GetByteBit(outs->flag1,out_digital_analog,1) ) // digital_analog 0=digital 1=analog
				{ // digtal input range 
					if( outs->range >= OFF_ON && outs->range <= LOW_HIGH )
						if( /*(bit)*/GetByteBit(outs->flag1,out_control,1) ) val = 255;
						else val = 0;
					if( outs->range >= ON_OFF && outs->range <= HIGH_LOW )
						if( /*(bit)*/GetByteBit(outs->flag1,out_control,1) ) val = 0;
						else val = 255;
					if( outs->range >= custom_digital1 && outs->range <= custom_digital8 )
						if( /*(bit)*/GetByteBit(outs->flag1,out_control,1) ) val = 255;
						else val = 0;
				}
				else  
				{ // analog output range
				//	value =	(DoulbemGetPointWord2(outs->value)) / 1000;
					value = outs->value;
					switch( outs->range )
					{
						case V0_10:
							val = (S8_T)( value * 213 / 10000L );
							break;
						case P0_100_Open:
						case P0_100_Close:
						case P0_100:
							if( outs->m_del_low < outs->s_del_high )
							{
								delta = outs->s_del_high - outs->m_del_low;
								value *= delta;
								value += (S32_T)( outs->m_del_low * 100000L );
							}
							else
							{
								delta =  outs->m_del_low - outs->s_del_high;
								value *= delta;
								value += (S32_T)( outs->s_del_high * 100000L );
							}
							val = (S8_T)( value * 213 / 10000000L );
							break;
	/*					case I_0_20psi:*/
						case P0_20psi:
						case I_0_20ma:
							val = (S8_T)( value * 213 / 20000L );
							break;
						default:
							val = 0;
              				outs->range = not_used_output;
							break;
							/*	printf("Range error !!! " ); break;*/
					}
				}
			}
			point++;
			outs++;
		}

		in_out_data[out_data_index] = val;
		
				
		/* control output */
//		Control_Output(val,out_data_index);
		if(out_data_index <= 12)	Control_Output(val,out_data_index);
		else 
			Control_Output((DoulbemGetPointWord2(outs->value)) / 1000,out_data_index);
	
		out_data_index++;

		
#if 0
		if( ( out_data_index & 0x07 ) == 0 )
		{
			mask <<= 1;
			if( ( out_data_index & 0x0F ) == 0 )
				cards_type_copy >>= 2;
		/* find the next group of output channels */
			while( mask & channel_desc )
			{
				out_data_index += 8;
				mask <<= 1;
				if( ( out_data_index & 0x0F ) == 0 )
					cards_type_copy >>= 2;
				if( out_data_index >= MAX_IO_POINTS ) /**/
					break;
			}
		}
		if( out_data_index >= MAX_IO_POINTS ) /**/
			break;
#endif
	}
	
}



void check_weekly_routines(void)
{
 /* Override points can only be local to the panel even though the
		structure would allow for points from the network segment to which
		the local panel is connected */
	S8_T w, i, j;
	S32_T value;
	Str_weekly_routine_point *pw;
	Time_on_off *pt;
	
#if 1
	pw = &weekly_routines[0];
	for( i=0; i<MAX_WR; pw++, i++ )
	{
		w = ora_current.dayofweek - 1;
		if( w < 0 ) w = 6;
		if( !/*(bit)*/GetByteBit(pw->flag,weekly_auto_manual,1)/*pw->auto_manual*/ )
		{
			if( pw->override_2.point_type )
			{
				get_point_value( (Point*)&pw->override_2, &value );
				if(value)
				{
					SetByteBit(&pw->flag,1,weekly_override_2_value,1);
				}
				else
				{
					SetByteBit(&pw->flag,0,weekly_override_2_value,1);
				}
				//pw->override_2_value = value?1:0;
				if( value )		w = 8;
			}
			else
			// pw->override_2_value = OFF;
				SetByteBit(&pw->flag,0,weekly_override_2_value,1);
		
			if(pw->override_1.point_type)
			{
				get_point_value( (Point*)&pw->override_1, &value );
				if(value)
				{
					SetByteBit(&pw->flag,1,weekly_override_1_value,1);
				}
				else
				{
					SetByteBit(&pw->flag,0,weekly_override_1_value,1);
				}
				//pw->override_1_value = value?1:0;
				if( value )
					w = 7;
			}
			else
			 //pw->override_1_value = OFF;
				SetByteBit(&pw->flag,0,weekly_override_1_value,1);
		
			pt = &wr_times[i][w].time[2*MAX_INTERVALS_PER_DAY-1];
			j = 2 * MAX_INTERVALS_PER_DAY - 1;
		/*		for( j=2*MAX_INTERVALS_PER_DAY-1; j>=0; j-- )*/

			do
			{
				if( pt->hours || pt->minutes )
				{
					if( ora_current.hour > pt->hours ) break;
					if( ora_current.hour == pt->hours )
						if( ora_current.minute >= pt->minutes )
							break;
				}
				pt--;
			}
			while( --j >= 0 );
			
			if( j < 0)		//pw->value = OFF;
				SetByteBit(&pw->flag,0,weekly_value,1);
			else
			{
				if( j & 1 ) /* j % 2 */
					SetByteBit(&pw->flag,0,weekly_value,1);
				else
					SetByteBit(&pw->flag,1,weekly_value,1);    
			}
		}
	}
#endif
}


void check_annual_routines( void )
{
	S8_T i;
	S8_T mask;
	S8_T octet_index;
	Str_annual_routine_point *pr;

	pr = &annual_routines[0];
	for( i=0; i<MAX_AR; i++, pr++ )
	{
   		if( !/*(bit)*/GetByteBit(pr->flag,annual_auto_manual,1)/*pr->auto_manual*/ )
	 	{
			mask = 0x01;
			/* Assume bit0 from octet0 = Jan 1st */
			/* octet_index = ora_current.day_of_year / 8;*/
			 octet_index = mGetPointWord2(ora_current.day_of_year) >> 3;
			/* bit_index = ora_current.day_of_year % 8;*/    // ????????????????????????????
	/*		bit_index = ora_current.day_of_year & 0x07;*/
			mask = mask << (mGetPointWord2(ora_current.day_of_year) & 0x07 );

			if( ar_dates[i][octet_index] & mask )
			//	pr->value = 1;
				SetByteBit(&pr->flag,1,annual_value,1);
			else
			//	pr->value = 0;
				SetByteBit(&pr->flag,0,annual_value,1);
	   	}
	}
  	misc_flags.check_ar=0;


}


void update_timers( void )
{
	Set_Clock(0,0);
	Set_Clock(1,0);
	Set_Clock(PCF_SEC,ora_current.second);
	Set_Clock(PCF_MIN,ora_current.minute);
	Set_Clock(PCF_HOUR,ora_current.hour);
	Set_Clock(PCF_DAY,ora_current.day);
	Set_Clock(PCF_WEEK,ora_current.dayofweek);
	Set_Clock(PCF_MON,ora_current.month);
	Set_Clock(PCF_YEAR,ora_current.year);




#if 0
	int i, year;

	year = ora_current.year;
	if( ( year & '\x03' ) == '\x0' )
		month_length[1] = 29;
	else
		month_length[1] = 28;

	/* seconds since the beginning of the day */
	ora_current_sec = 3600L * ora_current.hour;
	ora_current_sec += 60 * ora_current.minute;
	ora_current_sec += ora_current.second;

	ora_current.day_of_year = 0;
	for( i=0; i<ora_current.month; i++ )
	{
		ora_current.day_of_year += month_length[i];
	}
	ora_current.day_of_year += ( ora_current.day - 1 );

/*	timestart = 0;*/ /* seconds since the beginning of the year */
	timestart = 86400L * ora_current.day_of_year; /* 86400L = 3600L * 24;*/
	timestart += ora_current_sec;

	time_since_1970 = 0; /* seconds since 1970 */
	if( ora_current.year < 70 )
		year = 100 + ora_current.year;
	for( i=70; i<year; i++ )
	{
		time_since_1970 += 31536000L;
		if( !( i & 3 ) )
			time_since_1970 += 86400L;
	}
  	time_since_1970 += timestart;	timestart = 0; /* seconds since the beginning */
#endif
}


void convert_T3000_time( T3000_Date_block *ptr_time )
{
	ora_current.second      = ptr_time->sec;			 /* 0-59	*/
	ora_current.minute      = ptr_time->min;    	 /* 0-59	*/
	ora_current.hour        = ptr_time->hour;      /* 0-23	*/
	ora_current.day         = ptr_time->mday;      /* 1-31	*/
	ora_current.month       = ptr_time->mon;     	 /* 0-11	*/
	ora_current.year        = ptr_time->year;      /* 0-99	*/
	ora_current.dayofweek   = ptr_time->wday;  		 /* 0-6, 0=Sunday	*/
	ora_current.day_of_year = ptr_time->yday; 	   /* 0-365	*/
	ora_current.is_dst      = ptr_time->is_dst;    /* daylight saving time on / off */

}


void convert_mini_time( T3000_Date_block *ptr_time )
{
	ptr_time->sec    = ora_current.second;			 /* 0-59	*/
	ptr_time->min    = ora_current.minute;    	 /* 0-59	*/
	ptr_time->hour   = ora_current.hour;         /* 0-23	*/
	ptr_time->mday   = ora_current.day;          /* 1-31	*/
	ptr_time->mon    = ora_current.month;     	 /* 0-11	*/
	ptr_time->year   = ora_current.year;         /* 0-99	*/
	ptr_time->wday   = ora_current.dayofweek;  	 /* 0-6, 0=Sunday	*/
	ptr_time->yday   = ora_current.day_of_year;  /* 0-365	*/
	ptr_time->is_dst = ora_current.is_dst;       /* daylight saving time on/off */
}


void set_clock()
{
	DS1202_date  calendar;

	calendar.sec        = ora_current.second;
	calendar.clock_halt = 0;
	calendar.min        = ora_current.minute;
	calendar.hour       = ora_current.hour;
	calendar.h12_24     = 0;
	calendar.date       = ora_current.day;
	calendar.month      = ora_current.month + 1 ;
	calendar.day        = ora_current.dayofweek + 1;
	if( ora_current.year > 100 )
		ora_current.year -= 100;
	calendar.year       = ora_current.year;
	calendar.alw_zero   = 0;
	calendar.write_prot = 0;

//	E2prom_Write_Byte();	

//	write_calendar( &calendar, 8, 0x0BE );
	// tbd: write calendar to flash   changed by chelsea

/*
write_calendar already enabled the interrupts

	EI();
*/
}
/*	int tm_sec;      /* Seconds */
/*	int tm_min;      /* Minutes */
/*	int tm_hour;     /* Hour (0--23) */
/*	int tm_mday;     /* Day of month (1--31) */
/*	int tm_mon;      /* Month (0--11) */
/*	int tm_year;     /* Year (calendar year minus 1900) */
/*	int tm_wday;     /* Weekday (0--6; Sunday = 0) */
/*	int tm_yday;     /* Day of year (0--365) */
/*	int tm_isdst;    /* 0 if daylight savings time is not in effect) */
int read_clock( void )
{

	DS1202_date  calendar;
	int halted;

	halted = 0;

//	read_calendar( &calendar, 8, 0x0BF );
// tbd: read calendar from flash changed by chelsea
/*
	if( calendar.write_prot )
		write_calendar( "\x0", 1, 0x8e );

	if( calendar.clock_halt )
	{
		write_calendar( "\x0", 1, 0x80 );
		halted = 1;
	}

	read_calendar( &calendar, 8, 0x0BF );
*/

	ora_current.second = calendar.sec;
	ora_current.minute = calendar.min;
	ora_current.hour = calendar.hour;
	ora_current.day = calendar.date;
	ora_current.month = calendar.month - 1;
	if( calendar.day <= 7 )
		ora_current.dayofweek = calendar.day - 1;

  	ora_current.year=0;
/*	if( calendar.ten_year < 7 )
		ora_current.year = 100;

	ora_current.year += ( calendar.ten_year * 10 + calendar.year );*/
	
	ora_current.year = calendar.year;

	if( ( ora_current.year & '\x03' ) == '\x0' )
		month_length[1] = 29;
	else
		month_length[1] = 28;

	update_timers();

	return halted;
}

/* 
implement control_logic per 1s 
*/
void CheckIdRoutines(void);

void control_logic(void)
{
	static U8_T count_10s = 0;
	static U8_T count_1min = 0;	
	static U8_T count_3s = 0;
	U8_T current_day;
	U16_T i;
	Str_program_point *ptr;
	Str_points_ptr sptr, xptr;

	if(Modbus.PROTOCAL == BACNET_PTP || Modbus.PROTOCAL == BACNET_MSTP)
	{
		ptr = programs;	

		/* deal with exec_program roution per 1s */	
		convert_in();
		ptr = programs;
		for( i = 0; i < MAX_PRGS; i++, ptr++ )
		{
			if( ptr->bytes )
				if( program_address[i] )
					if( (bit)GetByteBit( ptr->flag1,prg_on_off,1) )  // ptr->on_off		 
					{
						exec_program( i, program_address[i], 0 );
					}
		}
		convert_out();

	
	   // dealwith controller roution per 10 sec		
		if(count_10s < 10) 	count_10s++;
		else
		{
			count_10s = 0;
			sptr.pcon = controllers;
			for( i=0; i<MAX_CONS; i++, sptr.pcon++  )
			{
				if( sptr.pcon->input.point_type && sptr.pcon->setpoint.point_type )
					Controller( i );
			}
		}
	}

	// dealwith check_weekly_routines per 1 min
	if(count_1min < 30) 	count_1min++;
	else
	{		
		count_1min = 0;
		check_weekly_routines();
	/*	if( no_ins )   // disable it now by chelsea
		{
			sptr.pin = inputs;
			xptr.pinx = in_aux;
			for( i=0; i<no_ins; i++, sptr.pin++, xptr.pinx++ )
			{
				if( sptr.pin->range == P0_255p_min )
				{
						sptr.pin->value = 1000L * xptr.pinx->ticks;
						xptr.pinx->ticks= 0;
				}
			}
		}*/
	}

	// dealwith check_annual_routines per 1 day
	if(ora_current.day != current_day || misc_flags.check_ar)
	{
		check_annual_routines();
		current_day = ora_current.day;
	}

// TBD:   
#if 0
	if(count_3s < 3) 	count_3s++;
	else
	{
		count_3s = 0;
		CheckIdRoutines();
	}
#endif
}


#if 0
/* add this roution for schedule,
if the current protocal is not bacnet, implement this logic programming 
else implement exec_program roution
*/
unsigned char bdata               ID_FLAG = 0 ;
sbit  		ID_A_M				= ID_FLAG^7 ; 
sbit  		ID_OUTPUT			= ID_FLAG^6 ;  
sbit  		ID_STATE1			= ID_FLAG^5 ;
sbit  		ID_STATE2			= ID_FLAG^4 ;

void CheckIdRoutines(void)
{
	unsigned char i;
//    unsigned char code *base_address;
	Str_points_ptr sptr;

    bit wr1_value=0;
    bit wr2_value=0;
	bit output_value=0;
	bit temp_bit;
	bit wr1_valid;
	bit wr2_valid;
	for(i = 250;i < 252/*MAX_ID*/;i++)
	{
		if(ID_Config[i].all != NO_DEFINE_ADDRESS)
		{
			ID_FLAG = ID_Config[i].Str.flag;
			
			wr1_valid = 0;
			wr2_valid = 0;

			sptr.pwr = &weekly_routines[ID_Config[i].Str.schedule1 - 1];
			if(ID_Config[i].Str.schedule1 > 0 && ID_Config[i].Str.schedule1 <= MAX_WR)
			{				
				if(GetByteBit(sptr.pwr->flag,weekly_value,1))  // value
				{ 
					wr1_value=1;
					if(GetByteBit(sptr.pwr->flag,override_1_value,1) == 0)  // override_1_value or holiday
					{
						//SetBit( i & 0x07,&schedual1_state_index[ i >> 3 ]);
						SetByteBit(&sptr.pwr->flag,1,override_1_value,1);
					//	ID_CHANGED = 0;
					}
				}
				else
				{
					wr1_value=0;
					if(GetByteBit(sptr.pwr->flag,override_1_value,1) == 1)
					{
						SetByteBit(&sptr.pwr->flag,0,override_1_value,1);
					//	ID_CHANGED = 0;
					}
				}
				wr1_valid = 1;
			}
			else
				SetByteBit(&sptr.pwr->flag,0,override_1_value,1);

			if(ID_Config[i].Str.schedule2 > 0 && ID_Config[i].Str.schedule2 <= MAX_WR)
			{
				if(GetByteBit(sptr.pwr->flag,weekly_value,1))
				{ 
					wr2_value = 1;
					if(GetByteBit(sptr.pwr->flag,override_2_value,1) == 0)  // override_2_value or holiday
					{
						SetByteBit(&sptr.pwr->flag,1,override_2_value,1);
					//	ID_CHANGED = 0;
					}
				}
				else
				{
					wr2_value = 0;
					if(GetByteBit(sptr.pwr->flag,override_2_value,1) == 1)
					{
						SetByteBit(&sptr.pwr->flag,0,override_2_value,1);
					//	ID_CHANGED = 0;
					}
				}
				wr2_valid = 1;
			}
			else
				SetByteBit(&sptr.pwr->flag,0,override_2_value,1);


			if(!ID_A_M)  // AUTO
			{				
 				if(wr1_valid || wr2_valid )
				{
				//	test0 = 5;
				//	SendSchedualData(i,wr1_value | wr2_value);  
			#if 0
					output_value = GetBit(i,output_state_index); 
	 				temp_bit = GetBit(i,first_time_schedual);
					if(output_value != (wr1_value | wr2_value) || temp_bit == 0 )
					{ 
						if(temp_bit == 0)
						SetBit(i & 0x07 ,&first_time_schedual[ i >> 3 ]);					 
 		 				
						SendSchedualData(i,wr1_value | wr2_value);  
					}
					else if(cycle_minutes_timeout == 1)
					{
						SendSchedualData(i,wr1_value | wr2_value);  
						if(i == MAX_ID - 1)
						cycle_minutes_timeout = 0;
					}
			#endif
				}
			}
			else  // MAN
			{
				if(ID_FLAG != 0xff)
				{
				//	SendSchedualData(i,ID_OUTPUT);  
				//	test0 = 7;
					#if 0
					temp_bit = GetBit(i,first_time_schedual);
					if(ID_OUTPUT != GetBit(i,output_state_index) || temp_bit == 0)
					{ 
					//	test0 = 8;
						if(temp_bit == 0)
						SetBit(i & 0x07 ,&first_time_schedual[ i >> 3 ]);					 
						SendSchedualData(i,ID_OUTPUT);
					}
					else if(cycle_minutes_timeout == 1)
					{
					//	test0 = 9;
						SendSchedualData(i,ID_OUTPUT);
						if(i == MAX_ID -1)
						cycle_minutes_timeout = 0;
					}
					#endif
				}
			}
		}//check if the correspond ID has been used
	}//for 
}//main function

#endif


#endif

#endif
