/*
 *********************************************************************************
 *     Copyright (c) 2005   ASIX Electronic Corporation      All rights reserved.
 *
 *     This is unpublished proprietary source code of ASIX Electronic Corporation
 *
 *     The copyright notice above does not evidence any actual or intended
 *     publication of such source code.
 *********************************************************************************
 */
/*================================================================================
 * Module Name : hsuart.c
 * Purpose     : The High Speed UART module driver. It manages the character
 *               buffer and handles the ISR.
 * Author      : Robin Lee
 * Date        : 2006-01-09
 * Notes       : None.
 * $Log: hsuart.c,v $
 * Revision 1.1  2006/04/07 11:38:18  robin6633
 * no message
 *
 *================================================================================
 */

/* INCLUDE FILE DECLARATIONS */
#include	"reg80390.h"
#include	"types.h"
#include	"hsuart.h"
#include	<stdio.h>


/* STATIC VARIABLE DECLARATIONS */
static U8_T		hsurIntrBusyType = 0;
static U8_T		hsurRxBuffer[UR2_MAX_RX_SIZE];
static U8_T		hsurTxBuffer[UR2_MAX_TX_SIZE];
static U16_T	hsurRxBufNum = 0;
static U16_T	hsurTxBufNum = 0;
static U8_T		hsurRxTrigLvl = 0;
static U16_T	hsurRxCount = 0;
static U16_T	hsurTxCount = 0;
static U16_T	hsurGetPtr = 0;
static U16_T	hsurPutPtr = 0;


/* LOCAL SUBPROGRAM DECLARATIONS */
static void		hsur_ReadLsr(void);
static void		hsur_RcvrTrig(void);
static void		hsur_Rcvr(void);
static void		hsur_Xmit(void);
static void		hsur_ReadMsr(void);


/* LOCAL SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * static void hsur_ReadLsr(void)
 * Purpose : Read Line Status Register and display.
 * Params  : None
 * Returns : None
 * Note    : None
 *--------------------------------------------------------------------------------
 */
static void hsur_ReadLsr(void)
{
	U8_T	lineStatus = 0;

	lineStatus = UR2_LSR;

	if (lineStatus & UR2_OE)
	{
		// Overrun Error
		P3 = 0xE1;
	}
	else if (lineStatus & UR2_PE)
	{
		// Parity Error
		P3 = 0xE2;
	}
	else if (lineStatus & UR2_FE)
	{
		// Framing Error
		P3 = 0xE3;
	}
	else if (lineStatus & UR2_BI)
	{
		// Break Interrupt Occured
		P3 = 0xE4;
	}
	else if (lineStatus & UR2_FRAME_ERR)
	{
		// Mixing Error
		P3 = 0xE5;
	}
}

/*
 *--------------------------------------------------------------------------------
 * static void hsur_RcvrTrig(void)
 * Purpose : Get data and put into the receiver buffer continuously until trigger bytes
 * Params  : None
 * Returns : None
 * Note    : None
 *--------------------------------------------------------------------------------
 */
static void hsur_RcvrTrig(void)
{
	U16_T	i;

//	EA = 0;
	for (i=0 ; i<hsurRxTrigLvl ; i++)
	{
		hsurRxBuffer[hsurRxBufNum] = UR2_RBR;
		hsurRxBufNum ++;
		hsurRxCount ++;
		if (hsurRxBufNum == UR2_MAX_RX_SIZE)
			hsurRxBufNum = 0;
	}
//	EA = 1;
}

/*
 *--------------------------------------------------------------------------------
 * static void hsur_Rcvr(void)
 * Purpose : Receiving the byte data from hardware register into software buffer.
 * Params  : None
 * Returns : None
 * Note    : None
 *--------------------------------------------------------------------------------
 */
static void hsur_Rcvr(void)
{
	U8_T	lineStatus = 0;

	while (1)
	{
		lineStatus = UR2_LSR;
		if (lineStatus & UR2_DR)
		{
			hsurRxBuffer[hsurRxBufNum] = UR2_RBR;
			hsurRxBufNum ++;
			hsurRxCount ++;
			if (hsurRxBufNum == UR2_MAX_RX_SIZE)
				hsurRxBufNum = 0;
		}
		else
			break;
	}
}

/*
 *--------------------------------------------------------------------------------
 * static void hsur_Xmit(void)
 * Purpose : Transmitting the byte data from software buffer into hardware register.
 * Params  : None
 * Returns : None
 * Note    : None
 *--------------------------------------------------------------------------------
 */
static void hsur_Xmit(void)
{
	U8_T	lineStatus = 0;

	lineStatus = UR2_LSR;
	if (lineStatus & UR2_THRE)
	{
		if (hsurTxCount > 0)
		{
			UR2_THR = hsurTxBuffer[hsurTxBufNum];
			hsurTxBufNum ++;
			hsurTxCount --;
		}
		else
		{
			UR2_IER &= ~UR2_THRI_ENB;
		}
		if (hsurTxBufNum == UR2_MAX_TX_SIZE)
			hsurTxBufNum = 0;
		if (hsurTxCount == 0)
			UR2_IER &= ~UR2_THRI_ENB;
	}
}

/*
 *--------------------------------------------------------------------------------
 * static void hsur_ReadMsr(void)
 * Purpose : Reading the modem status register.
 * Params  : None
 * Returns : None
 * Note    : None
 *--------------------------------------------------------------------------------
 */
static void hsur_ReadMsr(void)
{
	U8_T	modemStatus = 0;

	modemStatus = UR2_MSR;

	printf("%lx\n\r", (U32_T)modemStatus);

	if (modemStatus & UR2_CTS)
	{
		P3 = modemStatus;
	}
	else if (modemStatus & UR2_DSR)
	{
		P3 = modemStatus;
	}
	else if (modemStatus & UR2_RI)
	{
		P3 = modemStatus;
	}
	else if (modemStatus & UR2_DCD)
	{
		P3 = modemStatus;
	}
}


/* EXPORTED SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * void HSUR_Func(void)
 * Purpose : HSUR interrupt function which checks interrupt status.
 * Params  : None.
 * Returns : None.
 * Note    : None.
 *--------------------------------------------------------------------------------
 */
void HSUR_Func(void)
{
	U8_T	intrStatus = 0;

	intrStatus = UR2_IIR & 0x0F;

	if (intrStatus == UR2_RLS_INTR)
	{
		hsur_ReadLsr();
	}
	else if (intrStatus == UR2_RD_TRIG_INTR)
	{
		if (hsurRxCount >= (UR2_MAX_RX_SIZE - 16))
			UR2_MCR |= UR2_RTS;
		hsurIntrBusyType = UR2_RD_TRIG_INTR;
		hsur_RcvrTrig();
	}
	else if (intrStatus == UR2_RD_TI_INTR)
	{
		hsurIntrBusyType = UR2_RD_TRIG_INTR;
		hsur_Rcvr();
	}
	else if (intrStatus == UR2_THRE_INTR)
	{
		if (hsurTxCount)
		{
			hsurIntrBusyType = UR2_THRE_INTR;
			hsur_Xmit();
		}
	}
	else if (intrStatus == UR2_MS_INTR)
	{
		hsurIntrBusyType = UR2_THRE_INTR;
		hsur_ReadMsr();
	}
}

/*
 *--------------------------------------------------------------------------------
 * void HSUR_Setup(U16_T divisor, U8_T lCtrl, U8_T intEnb, U8_T fCtrl, U8_T mCtrl)
 * Purpose : Setup the HSUR mode. Before using the HSUR of AX11000, this function
 *           must be executed to initiate.
 * Params  : divisor - A divisor value used to calculate the baud rate of HSUR.
 *           lCtrl - Line control register value.
 *           intEnb - Interrupt enable register value.
 *           fCtrl - FIFO control register value.
 *           mCtrl - Modem control register value.
 * Returns : None.
 * Note    : None.
 *--------------------------------------------------------------------------------
 */
void HSUR_Setup(U16_T divisor, U8_T lCtrl, U8_T intEnb, U8_T fCtrl, U8_T mCtrl)
{
	U16_T	i;

	UR2_LCR = UR2_DLAB_ENB;
	UR2_DLL = (U8_T)(divisor & 0x00FF);
	UR2_DLH = (U8_T)((divisor & 0xFF00) >> 8);
	UR2_LCR &= ~UR2_DLAB_ENB;
	UR2_LCR = lCtrl;
	UR2_IER = intEnb;
	UR2_FCR = fCtrl;
	UR2_MCR = mCtrl;

	for (i=0 ; i<UR2_MAX_RX_SIZE ; i++)
	{
		hsurRxBuffer[i] = 0;
		hsurTxBuffer[i] = 0;
	}
	hsurIntrBusyType = 0;
	hsurRxBufNum = 0;
	hsurTxBufNum = 0;
	hsurRxCount = 0;
	hsurTxCount = 0;
	hsurGetPtr = 0;
	hsurPutPtr = 0;

	switch (fCtrl & 0xC0)
	{
		case UR2_TRIG_01 :
			hsurRxTrigLvl = 1;
			break;
		case UR2_TRIG_04 :
			hsurRxTrigLvl = 4;
			break;
		case UR2_TRIG_08 :
			hsurRxTrigLvl = 8;
			break;
		case UR2_TRIG_14 :
			hsurRxTrigLvl = 14;
			break;
	}
}

/*
 *--------------------------------------------------------------------------------
 * S8_T HSUR_GetChar(void)
 * Purpose : Getting one byte data from the software receiver buffer,
 *           which stores data received from a serial bus.
 * Params  : None.
 * Returns : ch - one byte character in buffer.
 * Note    : None.
 *--------------------------------------------------------------------------------
 */
S8_T HSUR_GetChar(void)
{
	S8_T	ch = 0;
    
	while (hsurRxCount == 0) ;
	
	ch = hsurRxBuffer[hsurGetPtr];
	hsurGetPtr ++;
	hsurRxCount --;
	if (hsurGetPtr == UR2_MAX_RX_SIZE)
		hsurGetPtr = 0;

	return ch;
}

/*
 *--------------------------------------------------------------------------------
 * S8_T HSUR_PutChar(S8_T ch)
 * Purpose : Putting  one byte data into the software transmitter buffer,
 *           which stores data that be sent to a serial bus.
 * Params  : ch - one byte data will be put into buffer.
 * Returns : ch - the same data value will be returned.
 * Note    : None.
 *--------------------------------------------------------------------------------
 */
S8_T HSUR_PutChar(S8_T ch)
{
	if (ch == 0x0A)
	{
		while (hsurTxCount == UR2_MAX_TX_SIZE) ;
		
		hsurTxBuffer[hsurPutPtr] = 0x0D;
		hsurPutPtr ++;
		hsurTxCount ++;
		if (hsurPutPtr == UR2_MAX_TX_SIZE)
			hsurPutPtr = 0;
	}
	while (hsurTxCount == UR2_MAX_TX_SIZE) ;
	
	hsurTxBuffer[hsurPutPtr] = ch;
	hsurPutPtr ++;
	hsurTxCount ++;
	if (hsurPutPtr == UR2_MAX_TX_SIZE)
		hsurPutPtr = 0;

	if (hsurTxCount == 0)
	{
		UR2_THR = hsurTxBuffer[hsurTxBufNum];
		hsurTxBufNum ++;
	}
	UR2_IER |= UR2_THRI_ENB;

	return ch;
}

/*
* -----------------------------------------------------------------------------
 * void HSUR_InitValue(void)
 * Purpose : Initiating all globe value in this driver function.
 * Params  : None.
 * Returns : None.
 * Note    : None.
 * ----------------------------------------------------------------------------
 */
void HSUR_InitValue(void)
{
	U8_T	sysClk = 0;
	U16_T	i;

	for (i=0 ; i<UR2_MAX_RX_SIZE ; i++)
	{
		hsurRxBuffer[i] = 0;
		hsurTxBuffer[i] = 0;
	}
	hsurIntrBusyType = 0;
	hsurRxBufNum = 0;
	hsurTxBufNum = 0;
	hsurRxTrigLvl = 0;
	hsurRxCount = 0;
	hsurTxCount = 0;
	hsurGetPtr = 0;
	hsurPutPtr = 0;

	sysClk = CSREPR & 0xC0;
	switch (sysClk)
	{
		case SCS_100M :
			P3 = 0x10;
			break;
		case SCS_50M :
			P3 = 0x50;
			break;
		case SCS_25M :
			P3 = 0x25;
			break;
		default :
			P3 = 0xAA;
			break;
	}

} /* End of UART_Init */

/*
 *--------------------------------------------------------------------------------
 * S8_T HSUR_GetCharNb(void)
 * Purpose : Getting data from the software receiver buffer, which stores data 
 *           received from a serial bus. This function is similar to HSUR_GetChar,
 *           but this function only check buffer one time.
 * Params  : None.
 * Returns : ch - one byte data in buffer will be returned if having.
 * Note    : None.
 *--------------------------------------------------------------------------------
 */
S8_T HSUR_GetCharNb(void)
{
	S8_T ch = 0;
    
	if (hsurRxCount != 0)
	{

		ch = hsurRxBuffer[hsurGetPtr];
		hsurGetPtr ++;
		hsurRxCount --;
		if (hsurGetPtr == UR2_MAX_RX_SIZE)
			hsurGetPtr = 0;
	
		return ch;
	}
	else
	{
		return FALSE;
	}
}


/* End of hsuart.c */
