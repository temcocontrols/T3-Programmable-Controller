/*
 *********************************************************************************
 *     Copyright (c) 2005	ASIX Electronic Corporation      All rights reserved.
 *
 *     This is unpublished proprietary source code of ASIX Electronic Corporation
 *
 *     The copyright notice above does not evidence any actual or intended
 *     publication of such source code.
 *********************************************************************************
 */
/*================================================================================
 * Module Name : spiapi.c
 * Purpose     : 
 * Author      : Robin Lee
 * Date        : 2006-01-10
 * Notes       :
 * $Log$
 *================================================================================
 */

/* INCLUDE FILE DECLARATIONS */
#include	"reg80390.h"
#include	"types.h"
#include	"spi.h"
#include	"spiapi.h"


/* STATIC VARIABLE DECLARATIONS */


/* LOCAL SUBPROGRAM DECLARATIONS */


/* LOCAL SUBPROGRAM BODIES */


/* EXPORTED SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_WriteEnable(void)
 * Purpose : Enable a write process before sending a packet to write.
 * Params  : none
 * Returns : TRUE - successful
 * Note    : Write Enable must be initial when executing all write function.
 *--------------------------------------------------------------------------------
 */
BOOL SPI_WriteEnable(void)
{
	U8_T	xmitbyte = 0;
	
	xmitbyte = SPI_WREN;
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&xmitbyte, 8, SPI_NORMAL_LEN|SPI_GO_BSY);

	while (SPI_FlagChk(SPI_BUSY)) {}

	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_WriteDisable(void)
 * Purpose : Disable a write process.
 * Params  : none
 * Returns : TRUE - successful
 * Note    : After WriteDisable executed, all writing function will be fail.
 *--------------------------------------------------------------------------------
 */
BOOL SPI_WriteDisable(void)
{
	U8_T	xmitbyte = 0;
	
	xmitbyte = SPI_WRDI;
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&xmitbyte, 8, SPI_NORMAL_LEN|SPI_GO_BSY);

	while (SPI_FlagChk(SPI_BUSY)) {}

	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_WriteStatus(U8_T status)
 * Purpose : Change a device status register.
 * Params  : status - changed value.
 * Returns : TRUE - successful.
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL SPI_WriteStatus(U8_T status)
{
	U8_T	writestatus[2];
	
	writestatus[1] = SPI_WRSR;
	writestatus[0] = status;

	if (!SPI_WriteEnable())
		return FALSE;
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&writestatus, 16, SPI_NORMAL_LEN|SPI_GO_BSY);
	while (SPI_FlagChk(SPI_BUSY)) {}
	
	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_ReadStatus(U8_T *status)
 * Purpose : Read a device status register.
 * Params  : *status - a pointer of status value.
 * Returns : TRUE - successful
 * Note    : 
 *--------------------------------------------------------------------------------
 */
BOOL SPI_ReadStatus(U8_T *status)
{
	U8_T	readstatus[2];
	
	readstatus[1] = SPI_RDSR;
	readstatus[0] = 0;
	
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&readstatus, 16, SPI_NORMAL_LEN|SPI_GO_BSY);

	while (SPI_FlagChk(SPI_BUSY)) {}
	SPI_GetData(&readstatus);
	*status = readstatus[0];
	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_ByteWrite(U16_T addrofmem, U8_T bytedata)
 * Purpose : Write one byte data into spi devices.
 * Params  : addrofmem - address of accessing.
 *           bytedata - data to be written.
 * Returns : TRUE - successful.
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL SPI_ByteWrite(U16_T addrofmem, U8_T bytedata)
{
	U8_T	bytewrite[4];
	U8_T	status = 0;
	
	bytewrite[3] = SPI_WRITE;
	bytewrite[2] = (U8_T)(addrofmem >> 8);
	bytewrite[1] = (U8_T)(addrofmem);
	bytewrite[0] = bytedata;

	if (!SPI_WriteEnable())
	{
		return FALSE;
	}
	do
	{
		SPI_ReadStatus(&status);
	} while (status & SPI_WIP);
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&bytewrite, 32, SPI_NORMAL_LEN|SPI_GO_BSY);
	while (SPI_FlagChk(SPI_BUSY)) {}
	
	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_PageWrite(U16_T addrofmem, U8_T *ptbytedata, U16_T wrlen)
 * Purpose : Write a data string into spi devices.
 * Params  : addrofmem - address of accessing.
 *           *ptbytedata - pointer of data string to be written.
 *           wrlen - write data length.
 * Returns : TRUE - successful.
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL SPI_PageWrite(U16_T addrofmem, U8_T *ptbytedata, U16_T wrlen)
{
	U8_T		pagewrite[35];
	U8_T		status = 0;
	U16_T		i;
	
	pagewrite[2] = SPI_WRITE;
	pagewrite[1] = (U8_T)(addrofmem >> 8);
	pagewrite[0] = (U8_T)(addrofmem);
	for (i=0 ; i<wrlen ; i++)
	{
		pagewrite[3+i] = *(ptbytedata+i);
	}

	if (!SPI_WriteEnable())
		return FALSE;
	do
	{
		SPI_ReadStatus(&status);
	}
	while (status & SPI_WIP) ;
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&pagewrite[0], 24, SPI_LONG_LEN|SPI_GO_BSY);

	while (SPI_FlagChk(SPI_BUSY)) {}

	for (i=0 ; i<wrlen ; i++)
	{
		SPI_FlagEnb(SPI_BUSY);
		if (i == (wrlen-1))
			SPI_MstXmit(&pagewrite[3+i], 8, SPI_NORMAL_LEN|SPI_GO_BSY);
		else
			SPI_MstXmit(&pagewrite[3+i], 8, SPI_LONG_LEN|SPI_GO_BSY);
		while (SPI_FlagChk(SPI_BUSY)) {}
	}

	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_ByteRead(U16_T addrofmem, U8_T *ptbytedata)
 * Purpose : Read one byte data from spi devices.
 * Params  : addrofmem - address of accessing.
 *           *ptbytedata - pointer of data which be read.
 * Returns : TRUE - successful.
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL SPI_ByteRead(U16_T addrofmem, U8_T *ptbytedata)
{
	U8_T	byteread[4];
	U8_T	status = 0;
	
	byteread[3] = SPI_READ;
	byteread[2] = (U8_T)(addrofmem >> 8);
	byteread[1] = (U8_T)(addrofmem);
	byteread[0] = *ptbytedata;

	do
	{
		SPI_ReadStatus(&status);
	} while (status & SPI_WIP) ;
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&byteread[0], 32, SPI_NORMAL_LEN|SPI_GO_BSY);
	while (SPI_FlagChk(SPI_BUSY)) {}
	SPI_GetData(&byteread);
	*ptbytedata = byteread[0];

	return TRUE;
}

/*
 *--------------------------------------------------------------------------------
 * BOOL MCP25C320_PageRead(U16_T addrofmem, U8_T *ptbytedata, U16_T rdlen)
 * Purpose : read a data string from spi devices.
 * Params  : addrofmem - address of accessing.
 *           *ptbytedata - pointer of data string which be read.
 *           rdlen - read data length.
 * Returns : TRUE - successful.
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL SPI_PageRead(U16_T addrofmem, U8_T *ptbytedata, U16_T rdlen)
{
	U8_T	pageread[4], temp[4];
	U8_T	status = 0;
	U16_T	i;
	
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	temp[3] = 0;
	pageread[3] = 0;
	pageread[2] = SPI_READ;
	pageread[1] = (U8_T)(addrofmem >> 8);
	pageread[0] = (U8_T)(addrofmem);

	do
	{
		SPI_ReadStatus(&status);
	}
	while (status & SPI_WIP) ;
	SPI_FlagEnb(SPI_BUSY);
	SPI_MstXmit(&pageread[0], 24, SPI_LONG_LEN|SPI_GO_BSY);
	
	while (SPI_FlagChk(SPI_BUSY)) {}

	for (i=0 ; i<rdlen ; i++)
	{
		SPI_FlagEnb(SPI_BUSY);
		if (i==rdlen-1)
			SPI_MstXmit(&pageread[3], 8, SPI_NORMAL_LEN|SPI_GO_BSY);
		else
			SPI_MstXmit(&pageread[3], 8, SPI_LONG_LEN|SPI_GO_BSY);
		while (SPI_FlagChk(SPI_BUSY)) {}
		SPI_GetData(&temp);
		*(ptbytedata + i) = temp[0];
	}
	
	return TRUE;
	
}

 
/* End of spiapi.c */
