/*
 *********************************************************************************
 *     Copyright (c) 2005   ASIX Electronic Corporation      All rights reserved.
 *
 *     This is unpublished proprietary source code of ASIX Electronic Corporation
 *
 *     The copyright notice above does not evidence any actual or intended
 *     publication of such source code.
 *********************************************************************************
 */
/*================================================================================
 * Module Name : spi.c
 * Purpose     : This file handles the I2C serial interface driver.
 * Author      : Robin Lee
 * Date        : 2005-03-31
 * Notes       :
 * $Log: spi.c,v $
 * Revision 1.10  2005/11/24 12:51:51  robin6633
 * initiate values of use.
 *
 * Revision 1.9  2005/08/17 06:48:22  robin6633
 * no message
 *
 * Revision 1.8  2005/08/11 09:00:06  borbin
 * no message
 *
 * Revision 1.7  2005/08/03 03:41:39  robin6633
 * Extended the spi receive length.
 *
 * Revision 1.6  2005/07/27 05:18:30  robin6633
 * Re-order the burst read/write command address byte of slave mode.
 *
 * Revision 1.5  2005/07/21 12:14:14  robin6633
 * Fixed the software receive buffer of single write/read SFR command process.
 *
 * Revision 1.4  2005/07/21 02:56:48  robin6633
 * Change the opcode definition of slave mode instruction set.
 *
 * Revision 1.3  2005/07/16 02:58:07  robin6633
 * Add Slave mode function
 *
 * Revision 1.2  2005/06/14 02:50:12  arthur
 * changed interrupt.h include
 *
 * Revision 1.1.1.1  2005/06/06 05:55:57  robin6633
 * no message
 *
 *================================================================================
 */

/* INCLUDE FILE DECLARATIONS */
#include	"reg80390.h"
#include	"types.h"
#include	"spi.h"

#if SPI_SLAVE_ENABLE
#include	"console_debug.h"
#endif


/* STATIC VARIABLE DECLARATIONS */
static U8_T		spiactf = 0;
static U8_T		spictrl = 0;
static U8_T		spipktdir = 0;
static U8_T		spipktlen = 0;
static U16_T	spilencnt = 0;
static U16_T	spitransloop = 0;
static U16_T	spitransloopcnt = 0;
static U8_T		spirxbuf[4] = {0,0,0,0};
static U8_T		spislvtxbuf[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static U8_T		spislvrxbuf[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


/* LOCAL SUBPROGRAM DECLARATIONS */
static void	SPI_MstRcvr(void);
static void SPI_SlvRcvr(void);

#if SPI_SLAVE_ENABLE
static void SPI_SlvProcess(void);
#endif


/* LOCAL SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * static void SPI_MstRcvr(void)
 * Purpose : SPI master get data from receive queue in one transfer.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
static void SPI_MstRcvr(void)
{
	U8_T	i;

	SPICIR = SPIRBR;
	for (i = 0 ; i < 4; i++ )
	{
		spirxbuf[i] = SPIDR;
	}
}

/*
 *--------------------------------------------------------------------------------
 * static void SPI_SlvRcvr(void)
 * Purpose : SPI receive function for one transfer smaller than 32 bits.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
#if SPI_SLAVE_ENABLE
static void SPI_SlvRcvr(void)
{
	U8_T	i;
	U8_T	rxlen = 0;
	U8_T	slvcmdtype = 0;
	U8_T	datalen = 0;

	SPICIR = SPISB;
	spislvrxbuf[0] = SPIDR;
	slvcmdtype = spislvrxbuf[0] & 0xF0;
	datalen = (spislvrxbuf[0] & 0x0F) + 1;
	if (slvcmdtype == SPI_SLV_SRSFR)
	{
		rxlen = 1;
	}
	else if (slvcmdtype == SPI_SLV_SWSFR)
	{
		rxlen = datalen + 1;
	}
	else if (slvcmdtype == SPI_SLV_IRSFR)
	{
		rxlen = 2;
	}
	else if (slvcmdtype == SPI_SLV_IWSFR)
	{
		rxlen = datalen + 2;
	}
	else if (slvcmdtype == SPI_SLV_BRMEM)
	{
		rxlen = 3;
	}
	else if (slvcmdtype == SPI_SLV_BWMEM)
	{
		rxlen = datalen + 3;
	}
	for (i = 0 ; i < rxlen ; i ++ )
	{
		spislvrxbuf[1+i] = SPIDR;
	}
	/* Command abort*/
	SPICIR = 0xFF;
}
#endif

/*
 *--------------------------------------------------------------------------------
 * static void SPI_SlvProcess(void)
 * Purpose : SPI transmit function for one transfer smaller than 32 bits.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
#if SPI_SLAVE_ENABLE
static void SPI_SlvProcess(void)
{
	U8_T	slvcmdtype = 0;
	U8_T	sfraddr = 0;
	U8_T	cmdindreg = 0;
	U8_T	realreg = 0;
	U8_T	reallen = 0;
	U32_T	memaddr = 0;
	U32_T	tempdata = 0;
	U16_T	i;

	slvcmdtype = spislvrxbuf[0] & 0xF0;
	if (slvcmdtype == SPI_SLV_SRSFR)
	{
		reallen = (spislvrxbuf[0] & 0x07) + 1;
		sfraddr = spislvrxbuf[1];
		for (i=0 ; i<reallen ; i++)
		{
			CLI_SfrRd((U32_T)sfraddr, &tempdata);
			spislvtxbuf[i] = (U8_T)tempdata;
		}
		SPI_SlvXmit(SPI_SLV_RDY);
	}
	else if (slvcmdtype == SPI_SLV_SWSFR)
	{
		reallen = (spislvrxbuf[0] & 0x07) + 1;
		sfraddr = spislvrxbuf[1];
		for (i=0 ; i<reallen ; i++)
		{
			tempdata = (U32_T)spislvrxbuf[2+i];
			CLI_SfrWr((U32_T)sfraddr, tempdata);
		}
		SPI_SlvXmit(SPI_SLV_RDY);
	}
	else if (slvcmdtype  == SPI_SLV_IRSFR)
	{
		cmdindreg = spislvrxbuf[1];
		realreg = spislvrxbuf[2];
		reallen = (spislvrxbuf[0] & 0x0F) + 1;
		if (cmdindreg == SFR_SPICIR)
		{
			CLI_SpiRd((U32_T)realreg, &spislvtxbuf[0], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_I2CCIR)
		{
			CLI_I2cRd((U32_T)realreg, &spislvtxbuf[0], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_OWCIR)
		{
			CLI_OwRd((U32_T)realreg, &spislvtxbuf[0], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_CANCIR)
		{
			CLI_CanRd((U32_T)realreg, &spislvtxbuf[0], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_TCIR)
		{
			CLI_ToeRd((U32_T)realreg, &spislvtxbuf[0], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_MCIR)
		{
			CLI_MacRd((U32_T)realreg, &spislvtxbuf[0], (U8_T)reallen);
		}
		SPI_SlvXmit(SPI_SLV_RDY);
	}
	else if (slvcmdtype  == SPI_SLV_IWSFR)
	{
		cmdindreg = spislvrxbuf[1];
		realreg = spislvrxbuf[2];
		reallen = (spislvrxbuf[0] & 0x0F) + 1;
		if (cmdindreg == SFR_SPICIR)
		{
			CLI_SpiWr((U32_T)realreg, &spislvrxbuf[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_I2CCIR)
		{
			CLI_I2cWr((U32_T)realreg, &spislvrxbuf[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_OWCIR)
		{
			CLI_OwWr((U32_T)realreg, &spislvrxbuf[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_CANCIR)
		{
			CLI_CanWr((U32_T)realreg, &spislvrxbuf[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_TCIR)
		{
			CLI_ToeWr((U32_T)realreg, &spislvrxbuf[3], (U8_T)reallen);
		}
		else if (cmdindreg == SFR_MCIR)
		{
			CLI_MacWr((U32_T)realreg, &spislvrxbuf[3], (U8_T)reallen);
		}
		SPI_SlvXmit(SPI_SLV_RDY);
	}
	else if (slvcmdtype  == SPI_SLV_BRMEM)
	{
		memaddr = ((U32_T)spislvrxbuf[3] << 16) | ((U32_T)spislvrxbuf[2] << 8) | ((U32_T)spislvrxbuf[1]);
		reallen = (spislvrxbuf[0] & 0x0F) + 1;
		for (i = 0 ; i < reallen ; i ++)
		{
			CLI_ExtMemRd((memaddr + i), &tempdata);
			spislvtxbuf[i] = (U8_T)tempdata;
		}
		SPI_SlvXmit(SPI_SLV_RDY);
	}
	else if (slvcmdtype  == SPI_SLV_BWMEM)
	{
		memaddr = ((U32_T)spislvrxbuf[3] << 16) | ((U32_T)spislvrxbuf[2] << 8) | ((U32_T)spislvrxbuf[1]);
		reallen = (spislvrxbuf[0] & 0x0F) + 1;
		for (i = 0 ; i < reallen ; i ++)
		{
			tempdata = (U32_T)spislvrxbuf[4 + i];
			CLI_ExtMemWr((memaddr + i), tempdata);
		}
		SPI_SlvXmit(SPI_SLV_RDY);
	}
}
#endif


/* EXPORTED SUBPROGRAM BODIES */

/*
 *--------------------------------------------------------------------------------
 * void SPI_Setup(U8_T ctrlcmd, U8_T intrenb, U8_T baudrate, U8_T slvsel)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_Setup(U8_T ctrlcmd, U8_T intrenb, U8_T baudrate, U8_T slvsel)
{
	U8_T	spislvcmd = 0;
	U16_T	i;

	spiactf = 0;
	spictrl = 0;
	spipktdir = 0;
	spipktlen = 0;
	spilencnt = 0;
	spitransloop = 0;
	spitransloopcnt = 0;
	for (i=0 ; i<4 ; i++)
		spirxbuf[i] = 0;
	for (i=0 ; i<16 ; i++)
	{
		spislvtxbuf[i] = 0;
		spislvrxbuf[i] = 0;
	}

	/* Record the SPI control mode */
	spictrl = intrenb;
	/* Setup SPI mode */
	SPI_Cmd(SI_WR, SPICTRLR, &ctrlcmd);
	/* Enable intertupe flag type of SPI */
	SPI_Cmd(SI_WR, SPIIER, &intrenb);
	/* SPI baud rate selection */
	SPI_Cmd(SI_WR, SPIBRR, &baudrate);
	/* SPI slave select */
	SPI_Cmd(SI_WR, SPISSR, &slvsel);
	/* SPI slave is ready to receive */
	spislvcmd = SPI_SLV_RDY;
	SPI_Cmd(SI_WR, SPISCR, &spislvcmd);
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_Func(void)
 * Purpose : Handling serial interface SPI interrupt function.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_Func(void)
{
	U8_T	spistatus = 0;

	/* Take down the interrupt type */

	EA = 0;
	SPI_Cmd(SI_RD, SPIISR, &spistatus);
	EA = 1;

	if ((spictrl & SPI_STCFIE) || (spictrl & SPI_SRCFIE))
	{
		/* Read SPI interrupt status register */
		if (spistatus & SPI_MCF) // when master complete a transfer
		{
			SPI_MstRcvr();
			SPI_FlagClr(SPI_BUSY);
		}

		#if SPI_SLAVE_ENABLE
		else if (spistatus & SPI_SCF) // when slave complete a transfer
		{
			SPI_SlvRcvr();
			SPI_SlvProcess();
		}
		#endif
	}
	else
	{
		if (spistatus & SPI_MCF) // when master complete a transfer
		{
			SPI_MstRcvr();
			SPI_FlagClr(SPI_BUSY);
		}
		#if SPI_SLAVE_ENABLE
		else if (spistatus & SPI_SCF) // when slave complete a transfer
		{
			SPI_SlvRcvr();
			SPI_SlvProcess();
		}
		#endif
	}
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_MstXmit(U8_T *ptspitxpkt, U8_T xmitbit, U8_T cmd)
 * Purpose : SPI transmit function for one transfer smaller than 32 bits.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_MstXmit(U8_T *ptspitxpkt, U8_T xmitbit, U8_T cmd)
{
	U16_T	i;
	U8_T	xmitcmd = 0;
	
	for (i = 0 ; i <= (xmitbit-1)/8 ; i++ )
	{
		SPIDR = *(ptspitxpkt + i);
	}
	SPICIR = SPITBR;
	/* order command */
	xmitcmd = ((xmitbit - 1)|cmd);
	SPI_Cmd(SI_WR, SPICMDR, &xmitcmd);
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_SlvXmit(U8_T spislvcmd)
 * Purpose : SPI transmit function for one transfer smaller than 32 bits.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_SlvXmit(U8_T spislvcmd)
{
	U16_T	i;

	for (i = 0 ; i <16 ; i++ )
	{
		SPIDR = spislvtxbuf[i];
	}
	SPICIR = SPISB;
	/* order command */
	SPI_Cmd(SI_WR, SPISCR, &spislvcmd);
}

/*
 *--------------------------------------------------------------------------------
 * BOOL SPI_FlagChk(U8_T chkbit)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
BOOL SPI_FlagChk(U8_T chkbit)
{
	if (spiactf & chkbit)
		return TRUE;
	else
		return FALSE;
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_FlagEnb(U8_T enbbit)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_FlagEnb(U8_T enbbit)
{
	spiactf = spiactf | enbbit;
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_FlagClr(U8_T clrbit)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_FlagClr(U8_T clrbit)
{
	spiactf = spiactf & ~clrbit;
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_GetData(U8_T *ptbuf)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_GetData(U8_T *ptbuf)
{
	U8_T	i;

	for (i=0 ; i<4 ; i++)
	{
		*(ptbuf + i) = spirxbuf[i];
	}
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_Cmd(U8_T cmdtype, U8_T spicmdindex, U8_T *spidata)
 * Purpose : Accessing the SPI interface indirectly through SPI's SFR.
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_Cmd(U8_T cmdtype, U8_T spicmdindex, U8_T *spidata)
{
	if (cmdtype == SI_WR)
	{
		SPIDR = *spidata;
		SPICIR = spicmdindex;
	}
	else if (cmdtype == SI_RD)
	{
		SPICIR = spicmdindex;
		*spidata = SPIDR;
	}
}

/*
 *--------------------------------------------------------------------------------
 * void SPI_Post(void)
 * Purpose :
 * Params  :
 * Returns :
 * Note    :
 *--------------------------------------------------------------------------------
 */
void SPI_Post(void)
{
}


/* End of spi.c */
